// Basitleştirilmiş çarpma/afet fiziği (Collins vd. 2005 ölçeklemesi + nükleer aşırı basınç ölçekleri).
// Amaç eğitim/simülasyon; kesin tahmin değildir.
export const G = 9.81;
export const MEGATON_J = 4.184e15;

export function meteorKinetikEnerji(capM: number, hizKmS: number, yogunlukKgM3 = 3000): number {
  const kutle = yogunlukKgM3 * (Math.PI / 6) * capM ** 3;
  const v = hizKmS * 1000;
  return 0.5 * kutle * v * v;
}
export const jouleToMegaton = (j: number) => j / MEGATON_J;

export function krater(capM: number, hizKmS: number, aciDerece = 45, yogunlukKgM3 = 3000) {
  const rhoT = 2500;
  const v = hizKmS * 1000;
  const th = (aciDerece * Math.PI) / 180;
  const dtc = 1.161 * Math.cbrt(yogunlukKgM3 / rhoT) * capM ** 0.78 * v ** 0.44 * G ** -0.22 * Math.sin(th) ** (1 / 3);
  const dfinal = dtc * 1.25;
  return { gecici: dtc, final: dfinal, derinlik: dfinal / 5 };
}
export function ates_topu_yaricap(joule: number) { return 0.002 * Math.cbrt(joule); }
export function sismikBuyukluk(joule: number) { return 0.67 * Math.log10(joule) - 5.87; }
export function asiriBasincYaricapKm(megaton: number, psi: 1 | 5 | 20) {
  const kt = megaton * 1000;
  const k = psi === 1 ? 1.1 : psi === 5 ? 0.47 : 0.24;
  return k * Math.cbrt(kt);
}
export function depremEnerji(mw: number) { return 10 ** (1.5 * mw + 4.8); }
export function kirilmaUzunlukKm(mw: number) { return 10 ** (0.59 * mw - 2.44); }
export function tsunamiHiz(derinlikM: number) { return Math.sqrt(G * derinlikM); }
export function tsunamiSureSaat(mesafeKm: number, derinlikM: number) { return (mesafeKm * 1000) / tsunamiHiz(derinlikM) / 3600; }
export function gunesPatlamaAkisi(sinif: "A" | "B" | "C" | "M" | "X", sayi: number) {
  const taban = { A: 1e-8, B: 1e-7, C: 1e-6, M: 1e-5, X: 1e-4 }[sinif];
  return taban * sayi; // W/m^2
}
export function vei_hacim_m3(vei: number) { return 10 ** (vei + 4); }
export function kul_sutunu_km(vei: number) { return 2 + 3.2 * Math.max(0, vei - 1) ** 0.9 + 0.5 * vei; }

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371, r = Math.PI / 180;
  const dLat = (lat2 - lat1) * r, dLon = (lon2 - lon1) * r;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export type Etki = { baslik: string; enerjiJoule: number; megaton: number; etkiYaricapKm: number; satirlar: string[] };

export function senaryoEtkisi(tur: string, p: Record<string, number>): Etki {
  if (tur === "meteor") {
    const E = meteorKinetikEnerji(p.cap, p.hiz, p.yogunluk ?? 3000);
    const Mt = jouleToMegaton(E);
    const k = krater(p.cap, p.hiz, p.aci ?? 45, p.yogunluk ?? 3000);
    const r1 = asiriBasincYaricapKm(Mt, 1);
    return { baslik: "Meteor çarpması", enerjiJoule: E, megaton: Mt, etkiYaricapKm: r1, satirlar: [
      `Enerji: ${Mt.toFixed(Mt < 1 ? 3 : 1)} Mt TNT`, `Krater: ${(k.final / 1000).toFixed(2)} km`,
      `Ateş topu: ${(ates_topu_yaricap(E) / 1000).toFixed(2)} km`, `Sismik: M${sismikBuyukluk(E).toFixed(1)}`,
      `1 psi yarıçapı: ${r1.toFixed(1)} km`] };
  }
  if (tur === "deprem") {
    const E = depremEnerji(p.mw);
    return { baslik: "Deprem", enerjiJoule: E, megaton: jouleToMegaton(E), etkiYaricapKm: kirilmaUzunlukKm(p.mw) * 2, satirlar: [
      `Mw ${p.mw}`, `Enerji: ${jouleToMegaton(E).toFixed(2)} Mt TNT eşdeğeri`, `Kırılma uzunluğu: ${kirilmaUzunlukKm(p.mw).toFixed(1)} km`] };
  }
  if (tur === "tsunami") {
    const h = tsunamiHiz(p.derinlik);
    const E = depremEnerji(p.mw);
    return { baslik: "Tsunami", enerjiJoule: E, megaton: jouleToMegaton(E), etkiYaricapKm: p.mesafe, satirlar: [
      `Dalga hızı: ${(h * 3.6).toFixed(0)} km/s`, `${p.mesafe} km için varış: ${tsunamiSureSaat(p.mesafe, p.derinlik).toFixed(1)} saat`] };
  }
  if (tur === "gunes") {
    const f = gunesPatlamaAkisi(p.sinif === 4 ? "X" : p.sinif === 3 ? "M" : "C", p.sayi);
    return { baslik: "Güneş patlaması", enerjiJoule: f * 1e24, megaton: jouleToMegaton(f * 1e24), etkiYaricapKm: 150000, satirlar: [
      `Akı: ${f.toExponential(2)} W/m²`, `Radyo kesintisi riski: ${f > 5e-5 ? "yüksek" : f > 1e-5 ? "orta" : "düşük"}`] };
  }
  if (tur === "volkan") {
    const V = vei_hacim_m3(p.vei);
    const E = V * 2500 * 1e6; // kaba termal/kinetik
    return { baslik: "Volkanik patlama", enerjiJoule: E, megaton: jouleToMegaton(E), etkiYaricapKm: kul_sutunu_km(p.vei) * 8, satirlar: [
      `VEI ${p.vei}`, `Hacim: ${V.toExponential(1)} m³`, `Kül sütunu: ${kul_sutunu_km(p.vei).toFixed(1)} km`] };
  }
  throw new Error("bilinmeyen senaryo türü: " + tur);
}

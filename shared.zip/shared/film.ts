// "Film" = zaman çizelgeli sinematik senaryo (30 sn veya 60 sn). Yapay zekalar bu şemada JSON üretir.
export const TURLER = ["meteor", "deprem", "gunes", "tsunami", "volkan"] as const;
export const EFEKT_ADLARI = ["sarsinti", "simsek", "aurora", "parlama", "glitch", "kivilcim", "sok_dalgasi", "kor", "tarama", "yagmur", "kuyruklu"] as const;
export type Tur = (typeof TURLER)[number];
export type EfektAdi = (typeof EFEKT_ADLARI)[number];

export type FilmOlay =
  | { t: number; tip: "anlat"; metin: string }
  | { t: number; tip: "kamera"; lat: number; lon: number; zoom: number }
  | { t: number; tip: "senaryo"; tur: Tur; lat: number; lon: number; parametreler: Record<string, number> }
  | { t: number; tip: "efekt"; ad: EfektAdi; siddet: number }
  | { t: number; tip: "tema"; tema: "mavi" | "kirmizi" };

export type Film = { baslik: string; sure: number; olaylar: FilmOlay[]; kaynaklar: string[] };

// Parametre başına makul aralıklar (yapay zekanın absürt değer üretmesini engeller)
export const PARAM_ARALIK: Record<string, [number, number]> = {
  cap: [5, 20000], hiz: [11, 72], aci: [10, 90], yogunluk: [500, 8000],
  mw: [4, 9.5], derinlik: [100, 11000], mesafe: [10, 20000], sinif: [1, 4], sayi: [1, 30], vei: [1, 8],
};
const sinirla = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const sayi = (v: unknown, yedek: number) => (typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && Number.isFinite(parseFloat(v)) ? parseFloat(v) : yedek);

export function olayDogrula(o: any, sure: number): FilmOlay | null {
  if (!o || typeof o !== "object") return null;
  const t = sinirla(sayi(o.t, NaN), 0, sure); if (!Number.isFinite(t)) return null;
  switch (o.tip) {
    case "anlat": { const m = String(o.metin ?? "").replace(/\s+/g, " ").trim().slice(0, 220); return m ? { t, tip: "anlat", metin: m } : null; }
    case "kamera": return { t, tip: "kamera", lat: sinirla(sayi(o.lat, 0), -85, 85), lon: sinirla(sayi(o.lon, 0), -180, 180), zoom: sinirla(sayi(o.zoom, 1.5), 0.6, 4.4) };
    case "senaryo": {
      if (!TURLER.includes(o.tur)) return null;
      const p: Record<string, number> = {};
      for (const [k, v] of Object.entries(o.parametreler ?? {})) { const r = PARAM_ARALIK[k]; if (r) p[k] = sinirla(sayi(v, r[0]), r[0], r[1]); }
      return { t, tip: "senaryo", tur: o.tur, lat: sinirla(sayi(o.lat, 0), -85, 85), lon: sinirla(sayi(o.lon, 0), -180, 180), parametreler: p };
    }
    case "efekt": return EFEKT_ADLARI.includes(o.ad) ? { t, tip: "efekt", ad: o.ad, siddet: sinirla(sayi(o.siddet, 1), 0.1, 2) } : null;
    case "tema": return o.tema === "mavi" || o.tema === "kirmizi" ? { t, tip: "tema", tema: o.tema } : null;
    default: return null;
  }
}

/** Ham (yapay zeka) çıktısını güvenli, sıralı, sınırlı bir Film'e çevirir; geçerli olay yoksa null. */
export function filmDogrula(ham: any, sure: 30 | 60, kaynak = "?"): Film | null {
  if (!ham || typeof ham !== "object" || !Array.isArray(ham.olaylar)) return null;
  const olaylar = ham.olaylar.map((o: any) => olayDogrula(o, sure)).filter(Boolean) as FilmOlay[];
  if (!olaylar.length) return null;
  olaylar.sort((a, b) => a.t - b.t);
  return { baslik: String(ham.baslik ?? "Adsız senaryo").slice(0, 80), sure, olaylar: olaylar.slice(0, 80), kaynaklar: [kaynak] };
}

/** Modelin cevabından JSON'u çıkarır (``` çitleri, önsöz/sonsöz toleranslı). */
export function jsonCikar(metin: string): any | null {
  const t = metin.trim();
  try { return JSON.parse(t); } catch { /* devam */ }
  const cit = /```(?:json)?\s*([\s\S]*?)```/i.exec(t);
  if (cit) { try { return JSON.parse(cit[1]); } catch { /* devam */ } }
  const a = t.indexOf("{"), b = t.lastIndexOf("}");
  if (a >= 0 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch { /* yok */ } }
  return null;
}

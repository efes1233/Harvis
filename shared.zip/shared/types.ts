export type Niyet = { ad: string; guven: number; varliklar: Record<string, string> };
export type AracSonuc = { ok: boolean; metin: string; veri?: unknown };
export type Arac = {
  ad: string;
  aciklama: string;
  anahtarlar: string[];
  calistir: (girdi: string, varliklar: Record<string, string>) => AracSonuc | Promise<AracSonuc>;
  ornek: { girdi: string; beklenen: string };
};
export type Senaryo = {
  id: string;
  ad: string;
  tur: "meteor" | "deprem" | "gunes" | "tsunami" | "volkan";
  lat: number;
  lon: number;
  parametreler: Record<string, number>;
  aciklama: string;
};

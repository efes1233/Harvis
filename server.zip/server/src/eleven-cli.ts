// Kullanım: node --experimental-strip-types server/src/eleven-cli.ts "Metin" [cikti.mp3]
import { writeFileSync } from "node:fs";
import { elevenSentez, elevenHazirMi } from "./eleven.ts";

export async function main(argv: string[]) {
  const metin = argv[0];
  if (!metin) { console.log('Kullanım: eleven-cli "Metin" [cikti.mp3]'); return 1; }
  if (!elevenHazirMi()) { console.log("ELEVEN_API_KEY tanımlı değil."); return 2; }
  const s = await elevenSentez(metin);
  if (!s.ok) { console.log(s.hata); return 3; }
  const dosya = argv[1] ?? "jarvis.mp3";
  writeFileSync(dosya, s.ses);
  console.log(`Yazıldı: ${dosya} (${s.ses.length} bayt)`);
  return 0;
}
if (process.argv[1]?.endsWith("eleven-cli.ts")) main(process.argv.slice(2)).then((c) => process.exit(c));

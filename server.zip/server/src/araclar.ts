import type { Arac, AracSonuc } from "../../shared/types.ts";
import { TUM_ARACLAR } from "./araclar/_index.ts";
import { tokenler, tokenEsle } from "./araclar/_yardimci.ts";

export const aracListesi: Arac[] = TUM_ARACLAR;

export function aracBul(ad: string): Arac | undefined {
  return aracListesi.find((a) => a.ad === ad);
}

export async function aracCalistir(ad: string, girdi: string, varliklar: Record<string, string> = {}): Promise<AracSonuc> {
  const a = aracBul(ad);
  if (!a) return { ok: false, metin: `Araç bulunamadı: ${ad}` };
  try {
    return await a.calistir(girdi, varliklar);
  } catch (e) {
    return { ok: false, metin: `Araç hatası (${ad}): ${(e as Error).message}` };
  }
}

export function aracEsle(metin: string): Arac | undefined {
  const tok = tokenler(metin);
  let en: Arac | undefined;
  let puan = 0;
  for (const a of aracListesi) {
    let p = 0;
    for (const k of a.anahtarlar) if (tokenEsle(tok, k)) p += k.length;
    if (p > puan) { puan = p; en = a; }
  }
  return en;
}

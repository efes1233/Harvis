// Merkezi beyin: niyet tanıma (Türkçe + İngilizce kural tabanlı), varlık çıkarma, isteğe bağlı LLM yedeği.
import type { Niyet } from "../../shared/types.ts";
import { sehirleriYukle } from "./veri.ts";
import { aracEsle } from "./araclar.ts";

const sehirler = sehirleriYukle();
const norm = (s: string) => s.toLocaleLowerCase("tr-TR").replace(/[’']/g, "").normalize("NFC");
const ascii = (s: string) => norm(s).replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c");

const TURLER: [string, string[]][] = [
  ["meteor", ["meteor", "asteroit", "göktaşı", "gokTasi", "meteorit", "asteroid"]],
  ["deprem", ["deprem", "earthquake", "sarsıntı"]],
  ["tsunami", ["tsunami", "dev dalga"]],
  ["gunes", ["güneş patlaması", "gunes patlamasi", "solar flare", "güneş fırtınası"]],
  ["volkan", ["volkan", "yanardağ", "volcano"]],
];

export function sehirBul(metin: string) {
  const m = ascii(metin);
  return sehirler.find((s) => m.includes(ascii(s.ad)));
}
export function sayiBul(metin: string, birim: RegExp): number | undefined {
  const r = metin.toLocaleLowerCase("tr-TR").match(new RegExp(`(\\d+(?:[.,]\\d+)?)\\s*${birim.source}`));
  return r ? parseFloat(r[1].replace(",", ".")) : undefined;
}

export function niyetCoz(metinHam: string): Niyet {
  const m = norm(metinHam);
  const v: Record<string, string> = {};

  // Senaryo yazdırma (yapay zekalar birleşir)
  if (/(senaryo\p{L}*\s+(yaz|üret|hazırla|oluştur)|film\p{L}*\s+(yap|üret|çek|hazırla)|sinematik|hikaye\p{L}*\s+(yaz|anlat))/u.test(m)) {
    v.istek = metinHam.trim();
    v.sure = /(1 dakika|bir dakika|60 saniye|altmış saniye|1 dk)/.test(m) ? "60" : "30";
    return { ad: "film_uret", guven: 0.95, varliklar: v };
  }
  // Senaryo
  for (const [tur, anahtarlar] of TURLER) {
    if (anahtarlar.some((k) => m.includes(norm(k)))) {
      const s = sehirBul(m);
      if (s) v.sehir = s.ad;
      v.tur = tur;
      const cap = sayiBul(m, /(?:m|metre|metrelik)\b/); if (cap) v.cap = String(cap);
      const km = sayiBul(m, /(?:km|kilometre)\b/); if (km && !v.cap) v.cap = String(km * 1000);
      const mw = m.match(/(\d(?:[.,]\d)?)\s*(?:büyüklüğünde|şiddetinde|mw)/); if (mw) v.mw = mw[1].replace(",", ".");
      return { ad: "senaryo_baslat", guven: s ? 0.95 : 0.8, varliklar: v };
    }
  }
  // Dünya kontrolü
  if (/(yaklaş|zoom in|büyüt)/.test(m)) return { ad: "dunya_yakinlas", guven: 0.9, varliklar: {} };
  if (/(uzaklaş|zoom out|küçült)/.test(m)) return { ad: "dunya_uzaklas", guven: 0.9, varliklar: {} };
  if (/(döndür|çevir|rotate|spin)/.test(m)) return { ad: "dunya_dondur", guven: 0.85, varliklar: {} };
  if (/(durdur|dur\b|stop|sıfırla|reset|temizle)/.test(m)) return { ad: "dunya_sifirla", guven: 0.85, varliklar: {} };
  if (/(göster|odaklan|git|focus|show)/.test(m) && sehirBul(m)) return { ad: "sehre_odaklan", guven: 0.9, varliklar: { sehir: sehirBul(m)!.ad } };
  // HUD
  if (/(kamera|el takibi|hand tracking).*(aç|başlat|etkinleştir|on)/.test(m)) return { ad: "kamera_ac", guven: 0.9, varliklar: {} };
  if (/(kamera|el takibi).*(kapat|durdur|off)/.test(m)) return { ad: "kamera_kapat", guven: 0.9, varliklar: {} };
  if (/(kırmızı|red|alarm).*(mod|protokol)/.test(m)) return { ad: "hud_tema", guven: 0.9, varliklar: { tema: "kirmizi" } };
  if (/(mavi|cyan|normal).*(mod|tema)/.test(m)) return { ad: "hud_tema", guven: 0.9, varliklar: { tema: "mavi" } };
  // Sosyal
  if (/^(merhaba|selam|hey|hello|günaydın|iyi akşamlar)/.test(m) || /\b(nasılsın)\b/.test(m)) return { ad: "selam", guven: 0.9, varliklar: {} };
  if (/(teşekkür|sağ ol|thanks)/.test(m)) return { ad: "tesekkur", guven: 0.9, varliklar: {} };
  // Araç
  const a = aracEsle(m);
  if (a) return { ad: "arac", guven: 0.7, varliklar: { arac: a.ad } };
  return { ad: "bilinmiyor", guven: 0.1, varliklar: {} };
}

/** Bağlı yapay zekâlardan serbest yanıt alır (anahtar yoksa null). */
export async function llmYanit(metin: string): Promise<string | null> {
  const { sohbet } = await import("./sohbet.ts");
  return (await sohbet(metin))?.yanit ?? null;
}

// Uyanma kelimesi: transkript akışında "jarvis" (ve yaygın yanlış duyulmaları) aranır.
const VARYANTLAR = ["jarvis", "jarvıs", "carvis", "çarvis", "carvıs", "jarvi", "cervis", "jarwis", "harvis"];

export function lev(a: string, b: string): number {
  const d: number[][] = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

export function uyanmaKelimesiVarMi(metin: string, kelime = "jarvis"): boolean {
  return uyanmaSonrasi(metin, kelime) !== null;
}

/** Uyanma kelimesinden sonraki komut metnini döndürür; kelime yoksa null. */
export function uyanmaSonrasi(metin: string, kelime = "jarvis"): string | null {
  const parcalar = metin.toLocaleLowerCase("tr-TR").replace(/[,.!?;:]/g, " ").split(/\s+/).filter(Boolean);
  for (let i = 0; i < parcalar.length; i++) {
    const p = parcalar[i];
    if (VARYANTLAR.includes(p) || p === kelime || lev(p, kelime) <= 1) return parcalar.slice(i + 1).join(" ");
  }
  return null;
}

export class UyanmaDinleyici {
  aktif = false;
  son = 0;
  pencereMs: number;
  kelime: string;
  constructor(pencereMs = 8000, kelime = "jarvis") { this.pencereMs = pencereMs; this.kelime = kelime; }
  isle(metin: string, simdi = Date.now()): { aktif: boolean; komut: string | null } {
    const sonrasi = uyanmaSonrasi(metin, this.kelime);
    if (sonrasi !== null) { this.aktif = true; this.son = simdi; return { aktif: true, komut: sonrasi || null }; }
    if (this.aktif && simdi - this.son <= this.pencereMs) { this.son = simdi; return { aktif: true, komut: metin.trim() || null }; }
    this.aktif = false;
    return { aktif: false, komut: null };
  }
}

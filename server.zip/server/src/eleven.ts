// ElevenLabs entegrasyonu. ELEVEN_API_KEY gerekir; yoksa temiz hata döner (istemci tarayıcı sesine düşer).
export type ElevenAyar = { sesId: string; model: string; kararlilik: number; benzerlik: number };
export const VARSAYILAN: ElevenAyar = { sesId: process.env.ELEVEN_VOICE_ID ?? "JBFqnCBsd6RMkjVDRZzb", model: "eleven_multilingual_v2", kararlilik: 0.55, benzerlik: 0.8 };

export function elevenHazirMi() { return Boolean(process.env.ELEVEN_API_KEY); }

export function istekGovdesi(metin: string, a: ElevenAyar = VARSAYILAN) {
  return { text: metin, model_id: a.model, voice_settings: { stability: a.kararlilik, similarity_boost: a.benzerlik } };
}

export async function elevenSentez(metin: string, a: ElevenAyar = VARSAYILAN): Promise<{ ok: true; ses: Buffer } | { ok: false; hata: string }> {
  const key = process.env.ELEVEN_API_KEY;
  if (!key) return { ok: false, hata: "ELEVEN_API_KEY tanımlı değil" };
  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${a.sesId}`, {
    method: "POST", headers: { "xi-api-key": key, "Content-Type": "application/json", Accept: "audio/mpeg" }, body: JSON.stringify(istekGovdesi(metin, a)),
  });
  if (!r.ok) return { ok: false, hata: `ElevenLabs HTTP ${r.status}` };
  return { ok: true, ses: Buffer.from(await r.arrayBuffer()) };
}

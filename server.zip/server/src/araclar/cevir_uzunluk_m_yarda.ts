import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_m_yarda",
  aciklama: "uzunluk: metre ↔ yarda çevirir",
  anahtarlar: ["metre","yarda","yard","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["yarda","yard"]) < idx(["metre"]);
    const fa = 1, fb = 0.9144;
    const [kaynak, hedef, f1, f2] = ters ? ["yarda", "metre", fb, fa] : ["metre", "yarda", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metre kaç yarda çevir", beklenen: "10.93613" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_b_kb",
  aciklama: "veri: bayt ↔ kilobayt çevirir",
  anahtarlar: ["bayt","byte","kilobayt","kb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilobayt","kb"]) < idx(["bayt","byte"]);
    const fa = 1, fb = 1024;
    const [kaynak, hedef, f1, f2] = ters ? ["kilobayt", "bayt", fb, fa] : ["bayt", "kilobayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 bayt kaç kilobayt çevir", beklenen: "0.009765625" },
};
export default arac;

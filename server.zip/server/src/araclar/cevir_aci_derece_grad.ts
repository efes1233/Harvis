import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_aci_derece_grad",
  aciklama: "aci: derece ↔ grad çevirir",
  anahtarlar: ["derece","grad","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["grad"]) < idx(["derece"]);
    const fa = 1, fb = 0.9;
    const [kaynak, hedef, f1, f2] = ters ? ["grad", "derece", fb, fa] : ["derece", "grad", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 derece kaç grad çevir", beklenen: "11.11111" },
};
export default arac;

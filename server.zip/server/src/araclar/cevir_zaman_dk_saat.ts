import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_dk_saat",
  aciklama: "zaman: dakika ↔ saat çevirir",
  anahtarlar: ["dakika","dk","saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["saat"]) < idx(["dakika","dk"]);
    const fa = 60, fb = 3600;
    const [kaynak, hedef, f1, f2] = ters ? ["saat", "dakika", fb, fa] : ["dakika", "saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 dakika kaç saat çevir", beklenen: "0.1666667" },
};
export default arac;

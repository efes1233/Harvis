import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_kmh_mph",
  aciklama: "hiz: km/s ↔ mil/saat çevirir",
  anahtarlar: ["km/s","km/h","kilometre/saat","mph","mil/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mph","mil/saat"]) < idx(["km/s","km/h","kilometre/saat"]);
    const fa = 0.2777777777777778, fb = 0.44704;
    const [kaynak, hedef, f1, f2] = ters ? ["mil/saat", "km/s", fb, fa] : ["km/s", "mil/saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 km/s kaç mph çevir", beklenen: "6.213712" },
};
export default arac;

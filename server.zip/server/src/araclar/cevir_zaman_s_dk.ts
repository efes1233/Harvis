import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_s_dk",
  aciklama: "zaman: saniye ↔ dakika çevirir",
  anahtarlar: ["saniye","dakika","dk","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["dakika","dk"]) < idx(["saniye"]);
    const fa = 1, fb = 60;
    const [kaynak, hedef, f1, f2] = ters ? ["dakika", "saniye", fb, fa] : ["saniye", "dakika", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 saniye kaç dakika çevir", beklenen: "0.1666667" },
};
export default arac;

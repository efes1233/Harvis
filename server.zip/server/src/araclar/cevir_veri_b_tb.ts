import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_b_tb",
  aciklama: "veri: bayt ↔ terabayt çevirir",
  anahtarlar: ["bayt","byte","terabayt","tb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["terabayt","tb"]) < idx(["bayt","byte"]);
    const fa = 1, fb = 1099511627776;
    const [kaynak, hedef, f1, f2] = ters ? ["terabayt", "bayt", fb, fa] : ["bayt", "terabayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 bayt kaç terabayt çevir", beklenen: "9.094947e-12" },
};
export default arac;

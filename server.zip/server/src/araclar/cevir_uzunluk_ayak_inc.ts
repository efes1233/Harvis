import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_ayak_inc",
  aciklama: "uzunluk: ayak ↔ inç çevirir",
  anahtarlar: ["ayak","feet","ft","inç","inch","inc","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["inç","inch","inc"]) < idx(["ayak","feet","ft"]);
    const fa = 0.3048, fb = 0.0254;
    const [kaynak, hedef, f1, f2] = ters ? ["inç", "ayak", fb, fa] : ["ayak", "inç", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 ayak kaç inç çevir", beklenen: "120" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_kg_libre",
  aciklama: "kutle: kilogram ↔ libre çevirir",
  anahtarlar: ["kilogram","kilo","kg","libre","pound","lb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["libre","pound","lb"]) < idx(["kilogram","kilo","kg"]);
    const fa = 1, fb = 0.45359237;
    const [kaynak, hedef, f1, f2] = ters ? ["libre", "kilogram", fb, fa] : ["kilogram", "libre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilogram kaç libre çevir", beklenen: "22.04623" },
};
export default arac;

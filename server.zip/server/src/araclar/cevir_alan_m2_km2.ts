import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_alan_m2_km2",
  aciklama: "alan: metrekare ↔ kilometrekare çevirir",
  anahtarlar: ["metrekare","m2","kilometrekare","km2","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilometrekare","km2"]) < idx(["metrekare","m2"]);
    const fa = 1, fb = 1000000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilometrekare", "metrekare", fb, fa] : ["metrekare", "kilometrekare", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metrekare kaç kilometrekare çevir", beklenen: "0.00001" },
};
export default arac;

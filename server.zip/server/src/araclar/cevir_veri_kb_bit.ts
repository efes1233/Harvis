import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_kb_bit",
  aciklama: "veri: kilobayt ↔ bit çevirir",
  anahtarlar: ["kilobayt","kb","bit","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["bit"]) < idx(["kilobayt","kb"]);
    const fa = 1024, fb = 0.125;
    const [kaynak, hedef, f1, f2] = ters ? ["bit", "kilobayt", fb, fa] : ["kilobayt", "bit", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilobayt kaç bit çevir", beklenen: "81920" },
};
export default arac;

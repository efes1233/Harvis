import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_pa_atm",
  aciklama: "basinc: pascal ↔ atmosfer çevirir",
  anahtarlar: ["pascal","pa","atmosfer","atm","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["atmosfer","atm"]) < idx(["pascal","pa"]);
    const fa = 1, fb = 101325;
    const [kaynak, hedef, f1, f2] = ters ? ["atmosfer", "pascal", fb, fa] : ["pascal", "atmosfer", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 pascal kaç atmosfer çevir", beklenen: "0.00009869233" },
};
export default arac;

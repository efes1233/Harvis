import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "base64_coz",
  aciklama: "Base64 metni çözer",
  anahtarlar: ["base64 çöz","base64 decode"],
  calistir: (girdi) => {
    const m = girdi.replace(/base64\s*(çöz|decode)/gi, "").trim();
    return { ok: true, metin: "Metin: " + Buffer.from(m, "base64").toString("utf-8") };
  },
  ornek: { girdi: "base64 çöz bWVyaGFiYQ==", beklenen: "merhaba" },
};
export default arac;

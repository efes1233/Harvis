import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_kw_mw",
  aciklama: "guc: kilowatt ↔ megawatt çevirir",
  anahtarlar: ["kilowatt","kw","megawatt","mw","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megawatt","mw"]) < idx(["kilowatt","kw"]);
    const fa = 1000, fb = 1000000;
    const [kaynak, hedef, f1, f2] = ters ? ["megawatt", "kilowatt", fb, fa] : ["kilowatt", "megawatt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilowatt kaç megawatt çevir", beklenen: "0.01" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_km_denizmili",
  aciklama: "uzunluk: kilometre ↔ deniz mili çevirir",
  anahtarlar: ["kilometre","km","deniz mili","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["deniz mili"]) < idx(["kilometre","km"]);
    const fa = 1000, fb = 1852;
    const [kaynak, hedef, f1, f2] = ters ? ["deniz mili", "kilometre", fb, fa] : ["kilometre", "deniz mili", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilometre kaç deniz mili çevir", beklenen: "5.399568" },
};
export default arac;

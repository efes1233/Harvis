import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_km_inc",
  aciklama: "uzunluk: kilometre ↔ inç çevirir",
  anahtarlar: ["kilometre","km","inç","inch","inc","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["inç","inch","inc"]) < idx(["kilometre","km"]);
    const fa = 1000, fb = 0.0254;
    const [kaynak, hedef, f1, f2] = ters ? ["inç", "kilometre", fb, fa] : ["kilometre", "inç", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilometre kaç inç çevir", beklenen: "393700.8" },
};
export default arac;

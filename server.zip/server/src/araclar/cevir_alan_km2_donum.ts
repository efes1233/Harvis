import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_alan_km2_donum",
  aciklama: "alan: kilometrekare ↔ dönüm çevirir",
  anahtarlar: ["kilometrekare","km2","dönüm","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["dönüm"]) < idx(["kilometrekare","km2"]);
    const fa = 1000000, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["dönüm", "kilometrekare", fb, fa] : ["kilometrekare", "dönüm", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilometrekare kaç dönüm çevir", beklenen: "10000" },
};
export default arac;

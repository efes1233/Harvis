import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_cm_ayak",
  aciklama: "uzunluk: santimetre ↔ ayak çevirir",
  anahtarlar: ["santimetre","cm","ayak","feet","ft","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["ayak","feet","ft"]) < idx(["santimetre","cm"]);
    const fa = 0.01, fb = 0.3048;
    const [kaynak, hedef, f1, f2] = ters ? ["ayak", "santimetre", fb, fa] : ["santimetre", "ayak", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 santimetre kaç ayak çevir", beklenen: "0.328084" },
};
export default arac;

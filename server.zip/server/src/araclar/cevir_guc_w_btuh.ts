import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_w_btuh",
  aciklama: "guc: watt ↔ BTU/saat çevirir",
  anahtarlar: ["watt","vat","btu/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu/saat"]) < idx(["watt","vat"]);
    const fa = 1, fb = 0.29307107;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU/saat", "watt", fb, fa] : ["watt", "BTU/saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 watt kaç btu/saat çevir", beklenen: "34.12142" },
};
export default arac;

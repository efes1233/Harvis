import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_mg_ton",
  aciklama: "kutle: miligram ↔ ton çevirir",
  anahtarlar: ["miligram","mg","ton","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["ton"]) < idx(["miligram","mg"]);
    const fa = 0.000001, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["ton", "miligram", fb, fa] : ["miligram", "ton", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 miligram kaç ton çevir", beklenen: "1e-8" },
};
export default arac;

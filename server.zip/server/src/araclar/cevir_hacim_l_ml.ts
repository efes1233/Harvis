import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_l_ml",
  aciklama: "hacim: litre ↔ mililitre çevirir",
  anahtarlar: ["litre","mililitre","ml","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mililitre","ml"]) < idx(["litre"]);
    const fa = 1, fb = 0.001;
    const [kaynak, hedef, f1, f2] = ters ? ["mililitre", "litre", fb, fa] : ["litre", "mililitre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 litre kaç mililitre çevir", beklenen: "10000" },
};
export default arac;

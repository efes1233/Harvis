import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kal_mt",
  aciklama: "enerji: kalori ↔ megaton TNT çevirir",
  anahtarlar: ["kalori","megaton","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megaton"]) < idx(["kalori"]);
    const fa = 4.184, fb = 4184000000000000;
    const [kaynak, hedef, f1, f2] = ters ? ["megaton TNT", "kalori", fb, fa] : ["kalori", "megaton TNT", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kalori kaç megaton çevir", beklenen: "1e-14" },
};
export default arac;

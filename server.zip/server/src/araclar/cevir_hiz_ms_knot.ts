import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_ms_knot",
  aciklama: "hiz: m/s ↔ knot çevirir",
  anahtarlar: ["m/s","metre/saniye","knot","düğüm","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["knot","düğüm"]) < idx(["m/s","metre/saniye"]);
    const fa = 1, fb = 0.5144444444444445;
    const [kaynak, hedef, f1, f2] = ters ? ["knot", "m/s", fb, fa] : ["m/s", "knot", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 m/s kaç knot çevir", beklenen: "19.43844" },
};
export default arac;

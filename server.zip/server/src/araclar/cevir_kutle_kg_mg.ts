import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_kg_mg",
  aciklama: "kutle: kilogram ↔ miligram çevirir",
  anahtarlar: ["kilogram","kilo","kg","miligram","mg","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["miligram","mg"]) < idx(["kilogram","kilo","kg"]);
    const fa = 1, fb = 0.000001;
    const [kaynak, hedef, f1, f2] = ters ? ["miligram", "kilogram", fb, fa] : ["kilogram", "miligram", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilogram kaç miligram çevir", beklenen: "10000000" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_mw_hp",
  aciklama: "guc: megawatt ↔ beygir gücü çevirir",
  anahtarlar: ["megawatt","mw","beygir","hp","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["beygir","hp"]) < idx(["megawatt","mw"]);
    const fa = 1000000, fb = 735.49875;
    const [kaynak, hedef, f1, f2] = ters ? ["beygir gücü", "megawatt", fb, fa] : ["megawatt", "beygir gücü", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 megawatt kaç beygir çevir", beklenen: "13596.22" },
};
export default arac;

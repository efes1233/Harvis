import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_kb_gb",
  aciklama: "veri: kilobayt ↔ gigabayt çevirir",
  anahtarlar: ["kilobayt","kb","gigabayt","gb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["gigabayt","gb"]) < idx(["kilobayt","kb"]);
    const fa = 1024, fb = 1073741824;
    const [kaynak, hedef, f1, f2] = ters ? ["gigabayt", "kilobayt", fb, fa] : ["kilobayt", "gigabayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilobayt kaç gigabayt çevir", beklenen: "0.000009536743" },
};
export default arac;

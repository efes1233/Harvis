import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_ml_galon",
  aciklama: "hacim: mililitre ↔ galon çevirir",
  anahtarlar: ["mililitre","ml","galon","gallon","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["galon","gallon"]) < idx(["mililitre","ml"]);
    const fa = 0.001, fb = 3.785411784;
    const [kaynak, hedef, f1, f2] = ters ? ["galon", "mililitre", fb, fa] : ["mililitre", "galon", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 mililitre kaç galon çevir", beklenen: "0.002641721" },
};
export default arac;

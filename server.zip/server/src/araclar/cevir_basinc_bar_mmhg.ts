import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_bar_mmhg",
  aciklama: "basinc: bar ↔ mmHg çevirir",
  anahtarlar: ["bar","mmhg","cıva","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mmhg","cıva"]) < idx(["bar"]);
    const fa = 100000, fb = 133.322387415;
    const [kaynak, hedef, f1, f2] = ters ? ["mmHg", "bar", fb, fa] : ["bar", "mmHg", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 bar kaç mmhg çevir", beklenen: "7500.616" },
};
export default arac;

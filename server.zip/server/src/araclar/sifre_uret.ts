import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
import { randomBytes } from "node:crypto";
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "sifre_uret",
  aciklama: "Güçlü rastgele parola üretir",
  anahtarlar: ["şifre üret","parola üret","şifre oluştur"],
  calistir: (girdi) => {
    const n = Math.min(64, Math.max(8, sayilar(girdi)[0] ?? 16));
    const cs = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*";
    const b = randomBytes(n); let s = "";
    for (let i = 0; i < n; i++) s += cs[b[i] % cs.length];
    return { ok: true, metin: "Parola: " + s, veri: s };
  },
  ornek: { girdi: "16 karakterli şifre üret", beklenen: "Parola: " },
};
export default arac;

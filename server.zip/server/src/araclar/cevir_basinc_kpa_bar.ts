import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_kpa_bar",
  aciklama: "basinc: kilopascal ↔ bar çevirir",
  anahtarlar: ["kilopascal","kpa","bar","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["bar"]) < idx(["kilopascal","kpa"]);
    const fa = 1000, fb = 100000;
    const [kaynak, hedef, f1, f2] = ters ? ["bar", "kilopascal", fb, fa] : ["kilopascal", "bar", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilopascal kaç bar çevir", beklenen: "0.1" },
};
export default arac;

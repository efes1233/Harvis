import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_kb_mb",
  aciklama: "veri: kilobayt ↔ megabayt çevirir",
  anahtarlar: ["kilobayt","kb","megabayt","mb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megabayt","mb"]) < idx(["kilobayt","kb"]);
    const fa = 1024, fb = 1048576;
    const [kaynak, hedef, f1, f2] = ters ? ["megabayt", "kilobayt", fb, fa] : ["kilobayt", "megabayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilobayt kaç megabayt çevir", beklenen: "0.009765625" },
};
export default arac;

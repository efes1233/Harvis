import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_atm_psi",
  aciklama: "basinc: atmosfer ↔ psi çevirir",
  anahtarlar: ["atmosfer","atm","psi","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["psi"]) < idx(["atmosfer","atm"]);
    const fa = 101325, fb = 6894.757293168;
    const [kaynak, hedef, f1, f2] = ters ? ["psi", "atmosfer", fb, fa] : ["atmosfer", "psi", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 atmosfer kaç psi çevir", beklenen: "146.9595" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_knot_mach",
  aciklama: "hiz: knot ↔ mach çevirir",
  anahtarlar: ["knot","düğüm","mach","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mach"]) < idx(["knot","düğüm"]);
    const fa = 0.5144444444444445, fb = 343;
    const [kaynak, hedef, f1, f2] = ters ? ["mach", "knot", fb, fa] : ["knot", "mach", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 knot kaç mach çevir", beklenen: "0.01499838" },
};
export default arac;

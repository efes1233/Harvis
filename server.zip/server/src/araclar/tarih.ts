import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "tarih",
  aciklama: "Bugünün tarihini söyler",
  anahtarlar: ["tarih","bugün ne","günlerden ne","bugün günlerden"],
  calistir: (girdi) => {
    const d = new Date();
    return { ok: true, metin: "Bugün " + d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) };
  },
  ornek: { girdi: "bugün günlerden ne", beklenen: "Bugün " },
};
export default arac;

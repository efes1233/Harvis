import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_yarda_denizmili",
  aciklama: "uzunluk: yarda ↔ deniz mili çevirir",
  anahtarlar: ["yarda","yard","deniz mili","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["deniz mili"]) < idx(["yarda","yard"]);
    const fa = 0.9144, fb = 1852;
    const [kaynak, hedef, f1, f2] = ters ? ["deniz mili", "yarda", fb, fa] : ["yarda", "deniz mili", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 yarda kaç deniz mili çevir", beklenen: "0.004937365" },
};
export default arac;

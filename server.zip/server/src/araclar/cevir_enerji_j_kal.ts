import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_j_kal",
  aciklama: "enerji: joule ↔ kalori çevirir",
  anahtarlar: ["joule","jul","kalori","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kalori"]) < idx(["joule","jul"]);
    const fa = 1, fb = 4.184;
    const [kaynak, hedef, f1, f2] = ters ? ["kalori", "joule", fb, fa] : ["joule", "kalori", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 joule kaç kalori çevir", beklenen: "2.390057" },
};
export default arac;

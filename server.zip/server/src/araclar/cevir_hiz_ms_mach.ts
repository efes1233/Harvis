import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_ms_mach",
  aciklama: "hiz: m/s ↔ mach çevirir",
  anahtarlar: ["m/s","metre/saniye","mach","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mach"]) < idx(["m/s","metre/saniye"]);
    const fa = 1, fb = 343;
    const [kaynak, hedef, f1, f2] = ters ? ["mach", "m/s", fb, fa] : ["m/s", "mach", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 m/s kaç mach çevir", beklenen: "0.02915452" },
};
export default arac;

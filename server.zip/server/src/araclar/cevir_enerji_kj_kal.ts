import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kj_kal",
  aciklama: "enerji: kilojoule ↔ kalori çevirir",
  anahtarlar: ["kilojoule","kj","kalori","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kalori"]) < idx(["kilojoule","kj"]);
    const fa = 1000, fb = 4.184;
    const [kaynak, hedef, f1, f2] = ters ? ["kalori", "kilojoule", fb, fa] : ["kilojoule", "kalori", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilojoule kaç kalori çevir", beklenen: "2390.057" },
};
export default arac;

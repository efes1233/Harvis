import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_l_bardak",
  aciklama: "hacim: litre ↔ su bardağı çevirir",
  anahtarlar: ["litre","bardak","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["bardak"]) < idx(["litre"]);
    const fa = 1, fb = 0.25;
    const [kaynak, hedef, f1, f2] = ters ? ["su bardağı", "litre", fb, fa] : ["litre", "su bardağı", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 litre kaç bardak çevir", beklenen: "40" },
};
export default arac;

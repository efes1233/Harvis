import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "carpim_tablosu",
  aciklama: "Bir sayının çarpım tablosunu verir",
  anahtarlar: ["çarpım tablosu","carpim tablosu"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (n === undefined) return { ok: false, metin: "Sayı verin." };
    return { ok: true, metin: Array.from({ length: 10 }, (_, i) => n + "x" + (i + 1) + "=" + fmt(n * (i + 1))).join(", ") };
  },
  ornek: { girdi: "7 çarpım tablosu", beklenen: "7x10=70" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_kw_btuh",
  aciklama: "guc: kilowatt ↔ BTU/saat çevirir",
  anahtarlar: ["kilowatt","kw","btu/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu/saat"]) < idx(["kilowatt","kw"]);
    const fa = 1000, fb = 0.29307107;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU/saat", "kilowatt", fb, fa] : ["kilowatt", "BTU/saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilowatt kaç btu/saat çevir", beklenen: "34121.42" },
};
export default arac;

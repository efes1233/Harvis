import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_ms_mph",
  aciklama: "hiz: m/s ↔ mil/saat çevirir",
  anahtarlar: ["m/s","metre/saniye","mph","mil/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mph","mil/saat"]) < idx(["m/s","metre/saniye"]);
    const fa = 1, fb = 0.44704;
    const [kaynak, hedef, f1, f2] = ters ? ["mil/saat", "m/s", fb, fa] : ["m/s", "mil/saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 m/s kaç mph çevir", beklenen: "22.36936" },
};
export default arac;

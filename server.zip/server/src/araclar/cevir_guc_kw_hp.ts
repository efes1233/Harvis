import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_kw_hp",
  aciklama: "guc: kilowatt ↔ beygir gücü çevirir",
  anahtarlar: ["kilowatt","kw","beygir","hp","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["beygir","hp"]) < idx(["kilowatt","kw"]);
    const fa = 1000, fb = 735.49875;
    const [kaynak, hedef, f1, f2] = ters ? ["beygir gücü", "kilowatt", fb, fa] : ["kilowatt", "beygir gücü", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilowatt kaç beygir çevir", beklenen: "13.59622" },
};
export default arac;

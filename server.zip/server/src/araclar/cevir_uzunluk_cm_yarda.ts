import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_cm_yarda",
  aciklama: "uzunluk: santimetre ↔ yarda çevirir",
  anahtarlar: ["santimetre","cm","yarda","yard","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["yarda","yard"]) < idx(["santimetre","cm"]);
    const fa = 0.01, fb = 0.9144;
    const [kaynak, hedef, f1, f2] = ters ? ["yarda", "santimetre", fb, fa] : ["santimetre", "yarda", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 santimetre kaç yarda çevir", beklenen: "0.1093613" },
};
export default arac;

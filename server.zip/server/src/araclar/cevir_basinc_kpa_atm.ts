import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_kpa_atm",
  aciklama: "basinc: kilopascal ↔ atmosfer çevirir",
  anahtarlar: ["kilopascal","kpa","atmosfer","atm","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["atmosfer","atm"]) < idx(["kilopascal","kpa"]);
    const fa = 1000, fb = 101325;
    const [kaynak, hedef, f1, f2] = ters ? ["atmosfer", "kilopascal", fb, fa] : ["kilopascal", "atmosfer", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilopascal kaç atmosfer çevir", beklenen: "0.09869233" },
};
export default arac;

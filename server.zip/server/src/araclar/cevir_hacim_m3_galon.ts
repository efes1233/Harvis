import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_m3_galon",
  aciklama: "hacim: metreküp ↔ galon çevirir",
  anahtarlar: ["metreküp","m3","galon","gallon","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["galon","gallon"]) < idx(["metreküp","m3"]);
    const fa = 1000, fb = 3.785411784;
    const [kaynak, hedef, f1, f2] = ters ? ["galon", "metreküp", fb, fa] : ["metreküp", "galon", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metreküp kaç galon çevir", beklenen: "2641.721" },
};
export default arac;

export const trNorm = (s: string) => s.toLocaleLowerCase("tr-TR").replace(/[’']/g, "");
export function tokenler(m: string): string[] { return trNorm(m).split(/[^\p{L}\p{N}.,/]+/u).filter(Boolean); }
export function tokenEsle(tok: string[], anahtar: string): boolean {
  if (anahtar.includes(" ")) return (" " + tok.join(" ") + " ").includes(" " + anahtar + " ") || tok.join(" ").includes(anahtar);
  return tok.some((t) => t === anahtar || (anahtar.length >= 4 && t.startsWith(anahtar)));
}
export function sayilar(m: string): number[] {
  return (m.match(/-?\d+(?:[.,]\d+)?/g) ?? []).map((x) => parseFloat(x.replace(",", ".")));
}
export const fmt = (n: number) => (Number.isInteger(n) && Math.abs(n) < 1e15 ? String(n) : String(Number(n.toPrecision(7))));

/** Güvenli ifade hesaplayıcı (eval yok): + - * / ^ % ve parantez, Türkçe sözcük işleçleri. */
export function hesapla(ifade: string): number {
  const SOZ: Record<string, string> = { artı: "+", eksi: "-", çarpı: "*", bölü: "/", kere: "*", x: "*", üssü: "^", üs: "^" };
  let s = trNorm(ifade).replace(/,/g, ".").replace(/×/g, "*").replace(/÷/g, "/")
    .replace(/\p{L}+/gu, (w) => SOZ[w] ?? " ");
  s = s.replace(/[^0-9+\-*/^%().\s]/g, " ");
  let i = 0;
  const bosluk = () => { while (s[i] === " ") i++; };
  function sayi(): number {
    bosluk();
    if (s[i] === "(") { i++; const v = toplam(); bosluk(); if (s[i] !== ")") throw new Error("parantez kapanmadı"); i++; return v; }
    if (s[i] === "-") { i++; return -us(); }
    if (s[i] === "+") { i++; return us(); }
    const m = /^\d+(?:\.\d+)?|^\.\d+/.exec(s.slice(i));
    if (!m) throw new Error("sayı bekleniyordu");
    i += m[0].length; return parseFloat(m[0]);
  }
  function us(): number { let b = sayi(); bosluk(); if (s[i] === "^") { i++; b = Math.pow(b, us()); } return b; }
  function carpim(): number {
    let v = us();
    for (;;) { bosluk(); const c = s[i];
      if (c === "*") { i++; v *= us(); } else if (c === "/") { i++; const d = us(); if (d === 0) throw new Error("sıfıra bölme"); v /= d; }
      else if (c === "%") { i++; v %= us(); } else return v; }
  }
  function toplam(): number {
    let v = carpim();
    for (;;) { bosluk(); const c = s[i]; if (c === "+") { i++; v += carpim(); } else if (c === "-") { i++; v -= carpim(); } else return v; }
  }
  const sonuc = toplam(); bosluk();
  if (i < s.length) throw new Error("beklenmeyen karakter");
  return sonuc;
}

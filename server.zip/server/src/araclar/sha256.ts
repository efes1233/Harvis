import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
import { createHash } from "node:crypto";
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "sha256",
  aciklama: "Metnin SHA-256 özetini hesaplar",
  anahtarlar: ["sha256","özet hesapla","hash"],
  calistir: (girdi) => {
    const m = girdi.replace(/sha256|hash|özet hesapla/gi, "").trim();
    return { ok: true, metin: "SHA-256: " + createHash("sha256").update(m).digest("hex") };
  },
  ornek: { girdi: "sha256 abc", beklenen: "ba7816bf8f01cfea414140de5dae2223" },
};
export default arac;

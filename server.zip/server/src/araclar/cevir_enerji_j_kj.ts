import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_j_kj",
  aciklama: "enerji: joule ↔ kilojoule çevirir",
  anahtarlar: ["joule","jul","kilojoule","kj","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilojoule","kj"]) < idx(["joule","jul"]);
    const fa = 1, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilojoule", "joule", fb, fa] : ["joule", "kilojoule", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 joule kaç kilojoule çevir", beklenen: "0.01" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "gun_farki",
  aciklama: "İki tarih (GG.AA.YYYY) arasındaki gün sayısı",
  anahtarlar: ["gün farkı","kaç gün var","gun farki"],
  calistir: (girdi) => {
    const t = girdi.match(/(\d{1,2})[./](\d{1,2})[./](\d{4})/g); if (!t || t.length < 2) return { ok: false, metin: "İki tarih verin (GG.AA.YYYY)." };
    const p = (s: string) => { const [g, a, y] = s.split(/[./]/).map(Number); return Date.UTC(y, a - 1, g); };
    return { ok: true, metin: Math.round(Math.abs(p(t[1]) - p(t[0])) / 864e5) + " gün" };
  },
  ornek: { girdi: "gün farkı 01.01.2024 ile 01.03.2024", beklenen: "60 gün" },
};
export default arac;

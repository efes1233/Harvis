import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "asal_mi",
  aciklama: "Sayının asal olup olmadığını söyler",
  anahtarlar: ["asal mı","asal mi","asal"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 2) return { ok: true, metin: n + " asal değildir." };
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return { ok: true, metin: n + " asal değildir; " + i + " ile bölünür." };
    return { ok: true, metin: n + " asaldır." };
  },
  ornek: { girdi: "97 asal mı", beklenen: "asaldır" },
};
export default arac;

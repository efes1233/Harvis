import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "ebob_ekok",
  aciklama: "İki sayının EBOB ve EKOK değerini verir",
  anahtarlar: ["ebob","ekok"],
  calistir: (girdi) => {
    const [a, b] = sayilar(girdi); if (!a || !b) return { ok: false, metin: "İki sayı verin." };
    const g = (x: number, y: number): number => (y ? g(y, x % y) : x); const e = g(Math.abs(a), Math.abs(b));
    return { ok: true, metin: "EBOB " + e + ", EKOK " + Math.abs(a * b) / e };
  },
  ornek: { girdi: "12 ve 18 ebob ekok", beklenen: "EBOB 6, EKOK 36" },
};
export default arac;

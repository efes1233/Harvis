import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kcal_btu",
  aciklama: "enerji: kilokalori ↔ BTU çevirir",
  anahtarlar: ["kilokalori","kcal","btu","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu"]) < idx(["kilokalori","kcal"]);
    const fa = 4184, fb = 1055.05585262;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU", "kilokalori", fb, fa] : ["kilokalori", "BTU", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilokalori kaç btu çevir", beklenen: "39.65667" },
};
export default arac;

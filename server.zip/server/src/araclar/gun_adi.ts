import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "gun_adi",
  aciklama: "Tarihin haftanın hangi günü olduğunu söyler",
  anahtarlar: ["hangi gün","gün adı"],
  calistir: (girdi) => {
    const t = girdi.match(/(\d{1,2})[./](\d{1,2})[./](\d{4})/); if (!t) return { ok: false, metin: "Tarih verin (GG.AA.YYYY)." };
    const d = new Date(Date.UTC(+t[3], +t[2] - 1, +t[1]));
    return { ok: true, metin: d.toLocaleDateString("tr-TR", { weekday: "long", timeZone: "UTC" }) };
  },
  ornek: { girdi: "hangi gün 29.10.2023", beklenen: "Pazar" },
};
export default arac;

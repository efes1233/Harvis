import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kal_btu",
  aciklama: "enerji: kalori ↔ BTU çevirir",
  anahtarlar: ["kalori","btu","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu"]) < idx(["kalori"]);
    const fa = 4.184, fb = 1055.05585262;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU", "kalori", fb, fa] : ["kalori", "BTU", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kalori kaç btu çevir", beklenen: "0.03965667" },
};
export default arac;

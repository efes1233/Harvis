import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
import { randomInt } from "node:crypto";
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "zar_at",
  aciklama: "Zar atar (varsayılan 6 yüzlü)",
  anahtarlar: ["zar at","zar"],
  calistir: (girdi) => {
    const y = Math.max(2, sayilar(girdi)[0] ?? 6);
    return { ok: true, metin: "Zar: " + (1 + randomInt(y)) };
  },
  ornek: { girdi: "zar at", beklenen: "Zar: " },
};
export default arac;

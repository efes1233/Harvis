import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kj_mt",
  aciklama: "enerji: kilojoule ↔ megaton TNT çevirir",
  anahtarlar: ["kilojoule","kj","megaton","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megaton"]) < idx(["kilojoule","kj"]);
    const fa = 1000, fb = 4184000000000000;
    const [kaynak, hedef, f1, f2] = ters ? ["megaton TNT", "kilojoule", fb, fa] : ["kilojoule", "megaton TNT", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilojoule kaç megaton çevir", beklenen: "2.390057e-12" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
import { randomInt } from "node:crypto";
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "yazi_tura",
  aciklama: "Yazı tura atar",
  anahtarlar: ["yazı tura","yazi tura","para at"],
  calistir: (girdi) => {
    return { ok: true, metin: randomInt(2) ? "Yazı" : "Tura" };
  },
  ornek: { girdi: "yazı tura at", beklenen: "" },
};
export default arac;

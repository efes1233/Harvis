import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_cm_km",
  aciklama: "uzunluk: santimetre ↔ kilometre çevirir",
  anahtarlar: ["santimetre","cm","kilometre","km","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilometre","km"]) < idx(["santimetre","cm"]);
    const fa = 0.01, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilometre", "santimetre", fb, fa] : ["santimetre", "kilometre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 santimetre kaç kilometre çevir", beklenen: "0.0001" },
};
export default arac;

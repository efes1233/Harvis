import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_kg_g",
  aciklama: "kutle: kilogram ↔ gram çevirir",
  anahtarlar: ["kilogram","kilo","kg","gram","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["gram"]) < idx(["kilogram","kilo","kg"]);
    const fa = 1, fb = 0.001;
    const [kaynak, hedef, f1, f2] = ters ? ["gram", "kilogram", fb, fa] : ["kilogram", "gram", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilogram kaç gram çevir", beklenen: "10000" },
};
export default arac;

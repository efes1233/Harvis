import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_l_m3",
  aciklama: "hacim: litre ↔ metreküp çevirir",
  anahtarlar: ["litre","metreküp","m3","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["metreküp","m3"]) < idx(["litre"]);
    const fa = 1, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["metreküp", "litre", fb, fa] : ["litre", "metreküp", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 litre kaç metreküp çevir", beklenen: "0.01" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kal_kwh",
  aciklama: "enerji: kalori ↔ kilovatsaat çevirir",
  anahtarlar: ["kalori","kilovatsaat","kwh","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilovatsaat","kwh"]) < idx(["kalori"]);
    const fa = 4.184, fb = 3600000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilovatsaat", "kalori", fb, fa] : ["kalori", "kilovatsaat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kalori kaç kilovatsaat çevir", beklenen: "0.00001162222" },
};
export default arac;

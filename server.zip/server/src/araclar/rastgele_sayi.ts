import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
import { randomInt } from "node:crypto";
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "rastgele_sayi",
  aciklama: "Aralıkta rastgele sayı seçer",
  anahtarlar: ["rastgele sayı","rastgele say"],
  calistir: (girdi) => {
    const [a = 1, b = 100] = sayilar(girdi); const lo = Math.min(a, b), hi = Math.max(a, b);
    return { ok: true, metin: "Sayı: " + (lo + randomInt(hi - lo + 1)) };
  },
  ornek: { girdi: "1 ile 10 arası rastgele sayı", beklenen: "Sayı: " },
};
export default arac;

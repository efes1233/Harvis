import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_sicaklik_f_k",
  aciklama: "sıcaklık: Fahrenhayt ↔ Kelvin çevirir",
  anahtarlar: ["fahrenhayt","fahrenheit","kelvin","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((x) => t.startsWith(x))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kelvin"]) < idx(["fahrenhayt","fahrenheit"]);
    const sonuc = ters ? (n - 273.15) * 9 / 5 + 32 : (n - 32) * 5 / 9 + 273.15;
    return { ok: true, metin: fmt(n) + " " + (ters ? "Kelvin" : "Fahrenhayt") + " = " + fmt(Number(sonuc.toFixed(4))) + " " + (ters ? "Fahrenhayt" : "Kelvin"), veri: sonuc };
  },
  ornek: { girdi: "32 fahrenhayt kaç kelvin", beklenen: "273.15" },
};
export default arac;

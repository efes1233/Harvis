import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "yuzde",
  aciklama: "Yüzde hesaplar: 'A sayısının yüzde B'si'",
  anahtarlar: ["yüzde","yuzde"],
  calistir: (girdi) => {
    const [a, b] = sayilar(girdi); if (a === undefined || b === undefined) return { ok: false, metin: "İki sayı verin." };
    return { ok: true, metin: fmt(a) + " sayısının %" + fmt(b) + "'si " + fmt((a * b) / 100) };
  },
  ornek: { girdi: "200 sayısının yüzde 15 i", beklenen: "30" },
};
export default arac;

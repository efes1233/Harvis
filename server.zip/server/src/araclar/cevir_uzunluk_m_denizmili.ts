import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_m_denizmili",
  aciklama: "uzunluk: metre ↔ deniz mili çevirir",
  anahtarlar: ["metre","deniz mili","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["deniz mili"]) < idx(["metre"]);
    const fa = 1, fb = 1852;
    const [kaynak, hedef, f1, f2] = ters ? ["deniz mili", "metre", fb, fa] : ["metre", "deniz mili", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metre kaç deniz mili çevir", beklenen: "0.005399568" },
};
export default arac;

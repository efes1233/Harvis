import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "kdv",
  aciklama: "KDV hesaplar (varsayılan %20)",
  anahtarlar: ["kdv"],
  calistir: (girdi) => {
    const [t, o = 20] = sayilar(girdi); if (t === undefined) return { ok: false, metin: "Tutar verin." };
    return { ok: true, metin: "KDV " + (t * o / 100).toFixed(2) + ", toplam " + (t * (1 + o / 100)).toFixed(2) };
  },
  ornek: { girdi: "kdv 100 20", beklenen: "KDV 20.00, toplam 120.00" },
};
export default arac;

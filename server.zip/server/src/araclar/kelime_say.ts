import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "kelime_say",
  aciklama: "Metindeki kelime sayısını verir",
  anahtarlar: ["kelime say","kaç kelime"],
  calistir: (girdi) => {
    const m = girdi.replace(/kelime say|kaç kelime/gi, "").trim();
    return { ok: true, metin: "Kelime sayısı: " + (m ? m.split(/\s+/).length : 0) };
  },
  ornek: { girdi: "kelime say bir iki üç dört", beklenen: "Kelime sayısı: 4" },
};
export default arac;

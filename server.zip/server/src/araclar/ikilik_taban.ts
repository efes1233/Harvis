import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "ikilik_taban",
  aciklama: "Sayıyı ikilik ve onaltılık tabana çevirir",
  anahtarlar: ["ikilik","binary","onaltılık","hex"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0) return { ok: false, metin: "Pozitif tam sayı verin." };
    return { ok: true, metin: n + " = 0b" + n.toString(2) + " = 0x" + n.toString(16).toUpperCase() };
  },
  ornek: { girdi: "255 binary hex", beklenen: "0b11111111 = 0xFF" },
};
export default arac;

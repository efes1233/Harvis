import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kcal_mt",
  aciklama: "enerji: kilokalori ↔ megaton TNT çevirir",
  anahtarlar: ["kilokalori","kcal","megaton","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megaton"]) < idx(["kilokalori","kcal"]);
    const fa = 4184, fb = 4184000000000000;
    const [kaynak, hedef, f1, f2] = ters ? ["megaton TNT", "kilokalori", fb, fa] : ["kilokalori", "megaton TNT", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilokalori kaç megaton çevir", beklenen: "1e-11" },
};
export default arac;

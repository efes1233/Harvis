import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_alan_m2_akre",
  aciklama: "alan: metrekare ↔ akre çevirir",
  anahtarlar: ["metrekare","m2","akre","acre","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["akre","acre"]) < idx(["metrekare","m2"]);
    const fa = 1, fb = 4046.8564224;
    const [kaynak, hedef, f1, f2] = ters ? ["akre", "metrekare", fb, fa] : ["metrekare", "akre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metrekare kaç akre çevir", beklenen: "0.002471054" },
};
export default arac;

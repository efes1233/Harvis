import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "vki",
  aciklama: "Beden kitle indeksi (boy cm, kilo kg)",
  anahtarlar: ["vki","beden kitle","bmi"],
  calistir: (girdi) => {
    const [b, k] = sayilar(girdi); if (!b || !k) return { ok: false, metin: "Boy (cm) ve kilo (kg) verin." };
    const v = k / (b / 100) ** 2; const d = v < 18.5 ? "zayıf" : v < 25 ? "normal" : v < 30 ? "fazla kilolu" : "obez";
    return { ok: true, metin: "VKİ " + v.toFixed(1) + " (" + d + ")" };
  },
  ornek: { girdi: "vki boy 180 kilo 81", beklenen: "VKİ 25.0" },
};
export default arac;

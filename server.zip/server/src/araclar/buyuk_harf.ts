import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "buyuk_harf",
  aciklama: "Metni büyük harfe çevirir (Türkçe uyumlu)",
  anahtarlar: ["büyük harf","büyük yaz"],
  calistir: (girdi) => {
    const m = girdi.replace(/büyük harf(e)?( çevir)?|büyük yaz/gi, "").trim();
    return { ok: true, metin: m.toLocaleUpperCase("tr-TR") };
  },
  ornek: { girdi: "büyük harf çevir istanbul", beklenen: "İSTANBUL" },
};
export default arac;

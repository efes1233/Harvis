import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hacim_ml_pint",
  aciklama: "hacim: mililitre ↔ pint çevirir",
  anahtarlar: ["mililitre","ml","pint","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["pint"]) < idx(["mililitre","ml"]);
    const fa = 0.001, fb = 0.473176473;
    const [kaynak, hedef, f1, f2] = ters ? ["pint", "mililitre", fb, fa] : ["mililitre", "pint", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 mililitre kaç pint çevir", beklenen: "0.02113376" },
};
export default arac;

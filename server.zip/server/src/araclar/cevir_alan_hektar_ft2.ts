import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_alan_hektar_ft2",
  aciklama: "alan: hektar ↔ fitkare çevirir",
  anahtarlar: ["hektar","fitkare","ft2","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["fitkare","ft2"]) < idx(["hektar"]);
    const fa = 10000, fb = 0.09290304;
    const [kaynak, hedef, f1, f2] = ters ? ["fitkare", "hektar", fb, fa] : ["hektar", "fitkare", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 hektar kaç fitkare çevir", beklenen: "1076391" },
};
export default arac;

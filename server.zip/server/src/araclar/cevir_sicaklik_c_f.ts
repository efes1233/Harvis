import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_sicaklik_c_f",
  aciklama: "sıcaklık: Santigrat ↔ Fahrenhayt çevirir",
  anahtarlar: ["santigrat","celsius","derece","fahrenhayt","fahrenheit","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((x) => t.startsWith(x))); return k < 0 ? 1e9 : k; };
    const ters = idx(["fahrenhayt","fahrenheit"]) < idx(["santigrat","celsius","derece"]);
    const sonuc = ters ? (n - 32) * 5 / 9 : n * 9 / 5 + 32;
    return { ok: true, metin: fmt(n) + " " + (ters ? "Fahrenhayt" : "Santigrat") + " = " + fmt(Number(sonuc.toFixed(4))) + " " + (ters ? "Santigrat" : "Fahrenhayt"), veri: sonuc };
  },
  ornek: { girdi: "100 santigrat kaç fahrenhayt", beklenen: "212" },
};
export default arac;

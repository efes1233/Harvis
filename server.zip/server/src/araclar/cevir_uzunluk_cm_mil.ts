import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_cm_mil",
  aciklama: "uzunluk: santimetre ↔ mil çevirir",
  anahtarlar: ["santimetre","cm","mil","mile","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mil","mile"]) < idx(["santimetre","cm"]);
    const fa = 0.01, fb = 1609.344;
    const [kaynak, hedef, f1, f2] = ters ? ["mil", "santimetre", fb, fa] : ["santimetre", "mil", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 santimetre kaç mil çevir", beklenen: "0.00006213712" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_mph_knot",
  aciklama: "hiz: mil/saat ↔ knot çevirir",
  anahtarlar: ["mph","mil/saat","knot","düğüm","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["knot","düğüm"]) < idx(["mph","mil/saat"]);
    const fa = 0.44704, fb = 0.5144444444444445;
    const [kaynak, hedef, f1, f2] = ters ? ["knot", "mil/saat", fb, fa] : ["mil/saat", "knot", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 mph kaç knot çevir", beklenen: "8.689762" },
};
export default arac;

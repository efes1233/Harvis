import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_kmh_mach",
  aciklama: "hiz: km/s ↔ mach çevirir",
  anahtarlar: ["km/s","km/h","kilometre/saat","mach","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mach"]) < idx(["km/s","km/h","kilometre/saat"]);
    const fa = 0.2777777777777778, fb = 343;
    const [kaynak, hedef, f1, f2] = ters ? ["mach", "km/s", fb, fa] : ["km/s", "mach", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 km/s kaç mach çevir", beklenen: "0.008098477" },
};
export default arac;

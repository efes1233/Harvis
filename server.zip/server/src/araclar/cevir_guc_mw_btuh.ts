import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_mw_btuh",
  aciklama: "guc: megawatt ↔ BTU/saat çevirir",
  anahtarlar: ["megawatt","mw","btu/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu/saat"]) < idx(["megawatt","mw"]);
    const fa = 1000000, fb = 0.29307107;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU/saat", "megawatt", fb, fa] : ["megawatt", "BTU/saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 megawatt kaç btu/saat çevir", beklenen: "34121420" },
};
export default arac;

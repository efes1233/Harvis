import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_gun_yil",
  aciklama: "zaman: gün ↔ yıl çevirir",
  anahtarlar: ["gün","yıl","sene","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["yıl","sene"]) < idx(["gün"]);
    const fa = 86400, fb = 31557600;
    const [kaynak, hedef, f1, f2] = ters ? ["yıl", "gün", fb, fa] : ["gün", "yıl", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 gün kaç yıl çevir", beklenen: "0.02737851" },
};
export default arac;

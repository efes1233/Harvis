import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "romen_rakami",
  aciklama: "Sayıyı Roma rakamına çevirir",
  anahtarlar: ["roma rakamı","romen rakamı","romen"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 1 || n > 3999) return { ok: false, metin: "1-3999 arası sayı verin." };
    const t: [number, string][] = [[1000,"M"],[900,"CM"],[500,"D"],[400,"CD"],[100,"C"],[90,"XC"],[50,"L"],[40,"XL"],[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];
    let k = n, s = ""; for (const [v, r] of t) while (k >= v) { s += r; k -= v; }
    return { ok: true, metin: n + " = " + s };
  },
  ornek: { girdi: "1994 roma rakamı", beklenen: "MCMXCIV" },
};
export default arac;

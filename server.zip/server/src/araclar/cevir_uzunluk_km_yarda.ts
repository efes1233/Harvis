import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_km_yarda",
  aciklama: "uzunluk: kilometre ↔ yarda çevirir",
  anahtarlar: ["kilometre","km","yarda","yard","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["yarda","yard"]) < idx(["kilometre","km"]);
    const fa = 1000, fb = 0.9144;
    const [kaynak, hedef, f1, f2] = ters ? ["yarda", "kilometre", fb, fa] : ["kilometre", "yarda", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilometre kaç yarda çevir", beklenen: "10936.13" },
};
export default arac;

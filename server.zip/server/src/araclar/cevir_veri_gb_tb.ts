import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_gb_tb",
  aciklama: "veri: gigabayt ↔ terabayt çevirir",
  anahtarlar: ["gigabayt","gb","terabayt","tb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["terabayt","tb"]) < idx(["gigabayt","gb"]);
    const fa = 1073741824, fb = 1099511627776;
    const [kaynak, hedef, f1, f2] = ters ? ["terabayt", "gigabayt", fb, fa] : ["gigabayt", "terabayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 gigabayt kaç terabayt çevir", beklenen: "0.009765625" },
};
export default arac;

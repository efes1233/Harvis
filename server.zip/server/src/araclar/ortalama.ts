import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "ortalama",
  aciklama: "Sayıların ortalamasını verir",
  anahtarlar: ["ortalama"],
  calistir: (girdi) => {
    const s = sayilar(girdi); if (!s.length) return { ok: false, metin: "Sayı verin." };
    return { ok: true, metin: "Ortalama " + fmt(s.reduce((a, b) => a + b, 0) / s.length) };
  },
  ornek: { girdi: "ortalama 4 8 15 16 23 42", beklenen: "18" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_mg_ons",
  aciklama: "kutle: miligram ↔ ons çevirir",
  anahtarlar: ["miligram","mg","ons","ounce","oz","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["ons","ounce","oz"]) < idx(["miligram","mg"]);
    const fa = 0.000001, fb = 0.028349523125;
    const [kaynak, hedef, f1, f2] = ters ? ["ons", "miligram", fb, fa] : ["miligram", "ons", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 miligram kaç ons çevir", beklenen: "0.0003527396" },
};
export default arac;

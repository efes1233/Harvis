import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_mb_bit",
  aciklama: "veri: megabayt ↔ bit çevirir",
  anahtarlar: ["megabayt","mb","bit","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["bit"]) < idx(["megabayt","mb"]);
    const fa = 1048576, fb = 0.125;
    const [kaynak, hedef, f1, f2] = ters ? ["bit", "megabayt", fb, fa] : ["megabayt", "bit", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 megabayt kaç bit çevir", beklenen: "83886080" },
};
export default arac;

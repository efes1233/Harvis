import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_saat_hafta",
  aciklama: "zaman: saat ↔ hafta çevirir",
  anahtarlar: ["saat","hafta","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["hafta"]) < idx(["saat"]);
    const fa = 3600, fb = 604800;
    const [kaynak, hedef, f1, f2] = ters ? ["hafta", "saat", fb, fa] : ["saat", "hafta", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 saat kaç hafta çevir", beklenen: "0.05952381" },
};
export default arac;

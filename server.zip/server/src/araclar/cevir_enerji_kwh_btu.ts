import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_kwh_btu",
  aciklama: "enerji: kilovatsaat ↔ BTU çevirir",
  anahtarlar: ["kilovatsaat","kwh","btu","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu"]) < idx(["kilovatsaat","kwh"]);
    const fa = 3600000, fb = 1055.05585262;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU", "kilovatsaat", fb, fa] : ["kilovatsaat", "BTU", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilovatsaat kaç btu çevir", beklenen: "34121.42" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_alan_m2_hektar",
  aciklama: "alan: metrekare ↔ hektar çevirir",
  anahtarlar: ["metrekare","m2","hektar","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["hektar"]) < idx(["metrekare","m2"]);
    const fa = 1, fb = 10000;
    const [kaynak, hedef, f1, f2] = ters ? ["hektar", "metrekare", fb, fa] : ["metrekare", "hektar", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metrekare kaç hektar çevir", beklenen: "0.001" },
};
export default arac;

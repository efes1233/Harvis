import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "fibonacci",
  aciklama: "N. Fibonacci sayısını verir",
  anahtarlar: ["fibonacci"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0 || n > 1000) return { ok: false, metin: "0-1000 arası tam sayı verin." };
    let a = 0n, b = 1n; for (let i = 0; i < n; i++) [a, b] = [b, a + b];
    return { ok: true, metin: "F(" + n + ") = " + a };
  },
  ornek: { girdi: "fibonacci 20", beklenen: "6765" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "base64_kodla",
  aciklama: "Metni Base64'e kodlar",
  anahtarlar: ["base64 kodla","base64'e çevir","base64 encode"],
  calistir: (girdi) => {
    const m = girdi.replace(/base64[^\s]*\s*(kodla|encode|çevir)?/gi, "").trim();
    return { ok: true, metin: "Base64: " + Buffer.from(m, "utf-8").toString("base64") };
  },
  ornek: { girdi: "base64 kodla merhaba", beklenen: "bWVyaGFiYQ==" },
};
export default arac;

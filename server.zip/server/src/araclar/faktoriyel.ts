import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "faktoriyel",
  aciklama: "Faktöriyel hesaplar (BigInt)",
  anahtarlar: ["faktöriyel","faktoriyel"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0 || n > 500) return { ok: false, metin: "0-500 arası tam sayı verin." };
    let r = 1n; for (let i = 2n; i <= BigInt(n); i++) r *= i;
    return { ok: true, metin: n + "! = " + r };
  },
  ornek: { girdi: "10 faktöriyel", beklenen: "3628800" },
};
export default arac;

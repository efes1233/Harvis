import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "saat",
  aciklama: "Şu anki saati söyler",
  anahtarlar: ["saat kaç","saati söyle","saat"],
  calistir: (girdi) => {
    const d = new Date();
    return { ok: true, metin: "Saat " + d.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) };
  },
  ornek: { girdi: "saat kaç", beklenen: "Saat " },
};
export default arac;

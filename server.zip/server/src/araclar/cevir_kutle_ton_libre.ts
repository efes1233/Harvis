import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_ton_libre",
  aciklama: "kutle: ton ↔ libre çevirir",
  anahtarlar: ["ton","libre","pound","lb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["libre","pound","lb"]) < idx(["ton"]);
    const fa = 1000, fb = 0.45359237;
    const [kaynak, hedef, f1, f2] = ters ? ["libre", "ton", fb, fa] : ["ton", "libre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 ton kaç libre çevir", beklenen: "22046.23" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "bilesik_faiz",
  aciklama: "Bileşik faiz: anapara, yıllık %, yıl",
  anahtarlar: ["bileşik faiz","bilesik faiz"],
  calistir: (girdi) => {
    const [p, r, y] = sayilar(girdi); if (!p || r === undefined || !y) return { ok: false, metin: "Anapara, oran ve yıl verin." };
    return { ok: true, metin: "Gelecek değer " + (p * (1 + r / 100) ** y).toFixed(2) };
  },
  ornek: { girdi: "bileşik faiz 1000 10 2", beklenen: "1210.00" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_kutle_libre_ons",
  aciklama: "kutle: libre ↔ ons çevirir",
  anahtarlar: ["libre","pound","lb","ons","ounce","oz","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["ons","ounce","oz"]) < idx(["libre","pound","lb"]);
    const fa = 0.45359237, fb = 0.028349523125;
    const [kaynak, hedef, f1, f2] = ters ? ["ons", "libre", fb, fa] : ["libre", "ons", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 libre kaç ons çevir", beklenen: "160" },
};
export default arac;

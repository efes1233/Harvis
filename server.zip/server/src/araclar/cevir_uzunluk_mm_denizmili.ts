import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_mm_denizmili",
  aciklama: "uzunluk: milimetre ↔ deniz mili çevirir",
  anahtarlar: ["milimetre","mm","deniz mili","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["deniz mili"]) < idx(["milimetre","mm"]);
    const fa = 0.001, fb = 1852;
    const [kaynak, hedef, f1, f2] = ters ? ["deniz mili", "milimetre", fb, fa] : ["milimetre", "deniz mili", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 milimetre kaç deniz mili çevir", beklenen: "0.000005399568" },
};
export default arac;

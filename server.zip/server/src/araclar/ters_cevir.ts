import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "ters_cevir",
  aciklama: "Metni tersine çevirir",
  anahtarlar: ["ters çevir","tersini yaz"],
  calistir: (girdi) => {
    const m = girdi.replace(/ters çevir|tersini yaz/gi, "").trim();
    return { ok: true, metin: [...m].reverse().join("") };
  },
  ornek: { girdi: "ters çevir abc", beklenen: "cba" },
};
export default arac;

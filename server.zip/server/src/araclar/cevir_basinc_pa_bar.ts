import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_basinc_pa_bar",
  aciklama: "basinc: pascal ↔ bar çevirir",
  anahtarlar: ["pascal","pa","bar","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["bar"]) < idx(["pascal","pa"]);
    const fa = 1, fb = 100000;
    const [kaynak, hedef, f1, f2] = ters ? ["bar", "pascal", fb, fa] : ["pascal", "bar", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 pascal kaç bar çevir", beklenen: "0.0001" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_mm_km",
  aciklama: "uzunluk: milimetre ↔ kilometre çevirir",
  anahtarlar: ["milimetre","mm","kilometre","km","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilometre","km"]) < idx(["milimetre","mm"]);
    const fa = 0.001, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilometre", "milimetre", fb, fa] : ["milimetre", "kilometre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 milimetre kaç kilometre çevir", beklenen: "0.00001" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_km_mil",
  aciklama: "uzunluk: kilometre ↔ mil çevirir",
  anahtarlar: ["kilometre","km","mil","mile","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mil","mile"]) < idx(["kilometre","km"]);
    const fa = 1000, fb = 1609.344;
    const [kaynak, hedef, f1, f2] = ters ? ["mil", "kilometre", fb, fa] : ["kilometre", "mil", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 kilometre kaç mil çevir", beklenen: "6.213712" },
};
export default arac;

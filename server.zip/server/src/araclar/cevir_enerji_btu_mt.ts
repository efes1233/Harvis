import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_btu_mt",
  aciklama: "enerji: BTU ↔ megaton TNT çevirir",
  anahtarlar: ["btu","megaton","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["megaton"]) < idx(["btu"]);
    const fa = 1055.05585262, fb = 4184000000000000;
    const [kaynak, hedef, f1, f2] = ters ? ["megaton TNT", "BTU", fb, fa] : ["BTU", "megaton TNT", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 btu kaç megaton çevir", beklenen: "2.521644e-12" },
};
export default arac;

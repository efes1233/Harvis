import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "palindrom",
  aciklama: "Metnin palindrom olup olmadığını söyler",
  anahtarlar: ["palindrom"],
  calistir: (girdi) => {
    const m = girdi.replace(/palindrom( mu)?/gi, "").toLocaleLowerCase("tr-TR").replace(/[^\p{L}\p{N}]/gu, "");
    return { ok: true, metin: m === [...m].reverse().join("") ? "Evet, palindrom." : "Hayır, palindrom değil." };
  },
  ornek: { girdi: "palindrom mu kayak", beklenen: "Evet" },
};
export default arac;

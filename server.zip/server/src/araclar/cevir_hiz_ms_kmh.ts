import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_ms_kmh",
  aciklama: "hiz: m/s ↔ km/s çevirir",
  anahtarlar: ["m/s","metre/saniye","km/s","km/h","kilometre/saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["km/s","km/h","kilometre/saat"]) < idx(["m/s","metre/saniye"]);
    const fa = 1, fb = 0.2777777777777778;
    const [kaynak, hedef, f1, f2] = ters ? ["km/s", "m/s", fb, fa] : ["m/s", "km/s", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 m/s kaç km/s çevir", beklenen: "36" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_hiz_mph_mach",
  aciklama: "hiz: mil/saat ↔ mach çevirir",
  anahtarlar: ["mph","mil/saat","mach","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["mach"]) < idx(["mph","mil/saat"]);
    const fa = 0.44704, fb = 343;
    const [kaynak, hedef, f1, f2] = ters ? ["mach", "mil/saat", fb, fa] : ["mil/saat", "mach", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 mph kaç mach çevir", beklenen: "0.01303324" },
};
export default arac;

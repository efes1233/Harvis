import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "kucuk_harf",
  aciklama: "Metni küçük harfe çevirir (Türkçe uyumlu)",
  anahtarlar: ["küçük harf","küçük yaz"],
  calistir: (girdi) => {
    const m = girdi.replace(/küçük harf(e)?( çevir)?|küçük yaz/gi, "").trim();
    return { ok: true, metin: m.toLocaleLowerCase("tr-TR") };
  },
  ornek: { girdi: "küçük harf çevir ISPARTA", beklenen: "ısparta" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "mors",
  aciklama: "Metni Mors koduna çevirir",
  anahtarlar: ["mors"],
  calistir: (girdi) => {
    const M: Record<string, string> = { a:".-",b:"-...",c:"-.-.",d:"-..",e:".",f:"..-.",g:"--.",h:"....",i:"..",j:".---",k:"-.-",l:".-..",m:"--",n:"-.",o:"---",p:".--.",q:"--.-",r:".-.",s:"...",t:"-",u:"..-",v:"...-",w:".--",x:"-..-",y:"-.--",z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----." };
    const m = girdi.replace(/mors( koduna)?( çevir)?/gi, "").toLowerCase().replace(/ı/g,"i").replace(/ş/g,"s").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ö/g,"o").replace(/ü/g,"u");
    return { ok: true, metin: [...m].map((c) => (c === " " ? "/" : M[c] ?? "")).filter(Boolean).join(" ") };
  },
  ornek: { girdi: "mors sos", beklenen: "... --- ..." },
};
export default arac;

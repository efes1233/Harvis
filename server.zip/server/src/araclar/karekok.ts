import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "karekok",
  aciklama: "Karekök hesaplar",
  anahtarlar: ["karekök","karekok"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0]; if (n === undefined || n < 0) return { ok: false, metin: "Negatif olmayan sayı verin." };
    return { ok: true, metin: "√" + fmt(n) + " = " + fmt(Math.sqrt(n)) };
  },
  ornek: { girdi: "144 karekök", beklenen: "12" },
};
export default arac;

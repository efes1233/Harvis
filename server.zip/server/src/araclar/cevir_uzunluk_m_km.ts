import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_uzunluk_m_km",
  aciklama: "uzunluk: metre ↔ kilometre çevirir",
  anahtarlar: ["metre","kilometre","km","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilometre","km"]) < idx(["metre"]);
    const fa = 1, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilometre", "metre", fb, fa] : ["metre", "kilometre", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 metre kaç kilometre çevir", beklenen: "0.01" },
};
export default arac;

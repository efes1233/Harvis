import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_veri_mb_tb",
  aciklama: "veri: megabayt ↔ terabayt çevirir",
  anahtarlar: ["megabayt","mb","terabayt","tb","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["terabayt","tb"]) < idx(["megabayt","mb"]);
    const fa = 1048576, fb = 1099511627776;
    const [kaynak, hedef, f1, f2] = ters ? ["terabayt", "megabayt", fb, fa] : ["megabayt", "terabayt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 megabayt kaç terabayt çevir", beklenen: "0.000009536743" },
};
export default arac;

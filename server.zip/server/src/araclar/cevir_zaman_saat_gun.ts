import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_saat_gun",
  aciklama: "zaman: saat ↔ gün çevirir",
  anahtarlar: ["saat","gün","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["gün"]) < idx(["saat"]);
    const fa = 3600, fb = 86400;
    const [kaynak, hedef, f1, f2] = ters ? ["gün", "saat", fb, fa] : ["saat", "gün", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 saat kaç gün çevir", beklenen: "0.4166667" },
};
export default arac;

import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_zaman_s_saat",
  aciklama: "zaman: saniye ↔ saat çevirir",
  anahtarlar: ["saniye","saat","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["saat"]) < idx(["saniye"]);
    const fa = 1, fb = 3600;
    const [kaynak, hedef, f1, f2] = ters ? ["saat", "saniye", fb, fa] : ["saniye", "saat", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 saniye kaç saat çevir", beklenen: "0.002777778" },
};
export default arac;

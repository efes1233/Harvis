import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_guc_w_kw",
  aciklama: "guc: watt ↔ kilowatt çevirir",
  anahtarlar: ["watt","vat","kilowatt","kw","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["kilowatt","kw"]) < idx(["watt","vat"]);
    const fa = 1, fb = 1000;
    const [kaynak, hedef, f1, f2] = ters ? ["kilowatt", "watt", fb, fa] : ["watt", "kilowatt", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 watt kaç kilowatt çevir", beklenen: "0.01" },
};
export default arac;

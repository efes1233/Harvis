import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "cevir_enerji_j_btu",
  aciklama: "enerji: joule ↔ BTU çevirir",
  anahtarlar: ["joule","jul","btu","çevir"],
  calistir: (girdi) => {
    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(["btu"]) < idx(["joule","jul"]);
    const fa = 1, fb = 1055.05585262;
    const [kaynak, hedef, f1, f2] = ters ? ["BTU", "joule", fb, fa] : ["joule", "BTU", fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };
  },
  ornek: { girdi: "10 joule kaç btu çevir", beklenen: "0.009478171" },
};
export default arac;

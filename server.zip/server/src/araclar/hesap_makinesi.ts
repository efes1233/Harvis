import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";

void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: "hesap_makinesi",
  aciklama: "Aritmetik ifadeleri hesaplar (+ - * / ^ % parantez, 'artı', 'çarpı' vb.)",
  anahtarlar: ["hesapla","kaç eder","artı","çarpı","bölü","eksi"],
  calistir: (girdi) => {
    const r = hesapla(girdi.replace(/hesapla|kaç eder|=/gi, ""));
    return { ok: true, metin: "Sonuç " + fmt(r), veri: r };
  },
  ornek: { girdi: "hesapla 12 çarpı (3 artı 4)", beklenen: "84" },
};
export default arac;

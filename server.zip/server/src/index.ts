import "./ortam.ts";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { join, normalize, extname, sep } from "node:path";
import { KOK, sehirleriYukle, senaryolariYukle } from "./veri.ts";
import { ajanIsle } from "./agent.ts";
import { aracListesi } from "./araclar.ts";
import { tts } from "./tts.ts";
import { sttCoz } from "./stt.ts";
import { elevenHazirMi } from "./eleven.ts";
import { filmUret } from "./birlesim.ts";
import { TUM_SAGLAYICILAR, hazirSaglayicilar } from "./saglayicilar/index.ts";
import { SINIRLAR, anahtarGecerli, istemciIp, type HizSiniri } from "./guvenlik.ts";

void TUM_SAGLAYICILAR;
const MIME: Record<string, string> = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".png": "image/png", ".wav": "audio/wav", ".mp3": "audio/mpeg", ".svg": "image/svg+xml", ".md": "text/markdown; charset=utf-8" };

async function govde(req: IncomingMessage, limit = 25_000_000): Promise<any> {
  const parcalar: Buffer[] = []; let n = 0;
  for await (const p of req) { n += (p as Buffer).length; if (n > limit) throw new Error("gövde çok büyük"); parcalar.push(p as Buffer); }
  const s = Buffer.concat(parcalar).toString("utf-8");
  return s ? JSON.parse(s) : {};
}
const json = (res: ServerResponse, kod: number, v: unknown) => { res.writeHead(kod, { "content-type": MIME[".json"], "cache-control": "no-store" }); res.end(JSON.stringify(v)); };

async function dosyaVer(res: ServerResponse, kok: string, yol: string) {
  const tam = normalize(join(kok, yol));
  if (!tam.startsWith(kok + sep) && tam !== kok) return json(res, 403, { hata: "yasak" });
  try {
    const st = await stat(tam); if (!st.isFile()) throw new Error();
    const d = await readFile(tam);
    res.writeHead(200, { "content-type": MIME[extname(tam)] ?? "application/octet-stream", "content-length": d.length, "cache-control": "public, max-age=3600" });
    res.end(d);
  } catch { json(res, 404, { hata: "bulunamadı" }); }
}

export function sunucuOlustur() {
  return createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://x"); const p = url.pathname;
      if (req.method === "GET" && p === "/api/durum") return json(res, 200, { ad: "JARVIS", surum: "1.0.0", araclar: aracListesi.length, senaryolar: senaryolariYukle().length, eleven: elevenHazirMi(), beyinler: hazirSaglayicilar().map((s) => ({ ad: s.ad, model: s.model(), ucretsiz: Boolean(s.ucretsiz) })), anahtarGerekli: Boolean(process.env.JARVIS_ERISIM_ANAHTARI) });
      if (req.method === "GET" && p === "/api/araclar") return json(res, 200, aracListesi.map((a) => ({ ad: a.ad, aciklama: a.aciklama, ornek: a.ornek.girdi })));
      if (req.method === "GET" && p === "/api/senaryolar") return json(res, 200, senaryolariYukle());
      if (req.method === "GET" && p === "/api/sehirler") return json(res, 200, sehirleriYukle());
      if (req.method === "POST" && (p === "/api/komut" || p === "/api/film" || p === "/api/stt" || p === "/api/tts")) {
        if (!anahtarGecerli(req)) return json(res, 401, { hata: "erişim anahtarı gerekli" });
        const s: HizSiniri = p === "/api/film" ? SINIRLAR.film : p === "/api/komut" ? SINIRLAR.komut : SINIRLAR.ses;
        if (!s.dene(istemciIp(req) + p)) return json(res, 429, { hata: "çok fazla istek, biraz bekleyin" });
      }
      if (req.method === "POST" && p === "/api/film") {
        const b = await govde(req, 20_000); const istek = String(b.istek ?? "").trim().slice(0, 400);
        if (!istek) return json(res, 400, { hata: "istek gerekli" });
        const r = await filmUret(istek, { sure: b.sure === 60 ? 60 : 30, uretimMs: b.uretimSn === 60 ? 60_000 : 30_000 });
        return json(res, 200, r);
      }
      if (req.method === "POST" && p === "/api/komut") { const b = await govde(req); if (!b.metin) return json(res, 400, { hata: "metin gerekli" }); return json(res, 200, await ajanIsle(String(b.metin))); }
      if (req.method === "POST" && p === "/api/stt") return json(res, 200, await sttCoz(await govde(req)));
      if (req.method === "POST" && p === "/api/tts") {
        const b = await govde(req); const s = await tts(String(b.metin ?? ""));
        if (s.motor === "eleven") { res.writeHead(200, { "content-type": s.mime }); return void res.end(s.ses); }
        return json(res, 200, s);
      }
      if (req.method === "GET" && p.startsWith("/assets/")) return dosyaVer(res, join(KOK, "assets"), p.slice(8));
      if (req.method === "GET" && (p === "/" || p === "/index.html")) return dosyaVer(res, join(KOK, "web/dist"), "index.html");
      if (req.method === "GET") return dosyaVer(res, join(KOK, "web/dist"), p.slice(1));
      json(res, 405, { hata: "yöntem desteklenmiyor" });
    } catch (e) { json(res, 500, { hata: (e as Error).message }); }
  });
}

if (process.argv[1]?.endsWith("index.ts")) {
  const port = Number(process.env.PORT ?? 3000);
  sunucuOlustur().listen(port, "0.0.0.0", () => console.log(`JARVIS çevrimiçi: http://localhost:${port}`));
}

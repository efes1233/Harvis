// Herkese açık yayında API kotanı korur: IP başına hız sınırı + isteğe bağlı erişim anahtarı.
import type { IncomingMessage } from "node:http";
import { timingSafeEqual } from "node:crypto";

export class HizSiniri {
  private kayit = new Map<string, number[]>();
  limit: number; pencereMs: number;
  constructor(limit: number, pencereMs = 60_000) { this.limit = limit; this.pencereMs = pencereMs; }
  /** true = izin ver. */
  dene(anahtar: string, simdi = Date.now()): boolean {
    const l = (this.kayit.get(anahtar) ?? []).filter((t) => simdi - t < this.pencereMs);
    if (l.length >= this.limit) { this.kayit.set(anahtar, l); return false; }
    l.push(simdi); this.kayit.set(anahtar, l);
    if (this.kayit.size > 5000) for (const [k, v] of this.kayit) if (!v.some((t) => simdi - t < this.pencereMs)) this.kayit.delete(k);
    return true;
  }
}

export function istemciIp(req: IncomingMessage): string {
  const x = req.headers["x-forwarded-for"];
  const ilk = (Array.isArray(x) ? x[0] : x)?.split(",")[0].trim();
  return ilk || req.socket.remoteAddress || "bilinmiyor";
}

export function anahtarGecerli(req: IncomingMessage, beklenen = process.env.JARVIS_ERISIM_ANAHTARI): boolean {
  if (!beklenen) return true;
  const gelen = String(req.headers["x-jarvis-key"] ?? "");
  const a = Buffer.from(gelen), b = Buffer.from(beklenen);
  return a.length === b.length && timingSafeEqual(a, b);
}

export const SINIRLAR = { komut: new HizSiniri(30), film: new HizSiniri(4), ses: new HizSiniri(40) };

// Yapay zekâ birleşimi: birden fazla model aynı anda senaryo yazar; roller verilir, süre dolunca sonuçlar tek filmde birleşir.
import { filmDogrula, jsonCikar, TURLER, EFEKT_ADLARI, PARAM_ARALIK, type Film, type FilmOlay } from "../../shared/film.ts";
import { senaryoEtkisi } from "../../shared/fizik.ts";
import { hazirSaglayicilar, type Saglayici } from "./saglayicilar/index.ts";
import { hataIsle } from "./saglayicilar/tur.ts";
import { niyetCoz, sehirBul } from "./beyin.ts";
import { sehirleriYukle } from "./veri.ts";

export const ROLLER = ["YAZAR", "YONETMEN", "FIZIKCI"] as const;
export type Rol = (typeof ROLLER)[number];

const ROL_TALIMATI: Record<Rol, string> = {
  YAZAR: "Rolün YAZAR: etkileyici, kısa, sinematik Türkçe anlatım cümleleri (anlat olayları) yaz; sahneler arası geçişi ve gerilimi sen kur.",
  YONETMEN: "Rolün YÖNETMEN: kamera hareketlerini (kamera olayları) ve görsel efektleri (efekt olayları) ustaca zamanla; ritim ve canlılık senden beklenir.",
  FIZIKCI: "Rolün FİZİKÇİ: senaryo olaylarındaki parametreleri bilimsel olarak gerçekçi seç (çap, hız, büyüklük vb.); anlatımda gerçek sayıları kullan.",
};

export function sistemPromptu(sure: 30 | 60, rol: Rol): string {
  const n = sure === 30 ? "8-16" : "14-28";
  return `Sen JARVIS'in senaryo ekibinin bir üyesisin. Kullanıcının isteğinden ${sure} saniyelik sinematik bir dünya simülasyonu senaryosu üret.
${ROL_TALIMATI[rol]}
SADECE geçerli JSON döndür (açıklama, markdown yok). Şema:
{"baslik": string, "olaylar": [ ... ${n} olay ... ]}
Olay türleri (t = saniye, 0..${sure}):
- {"t":number,"tip":"anlat","metin":string}  (en fazla 160 karakter, Türkçe)
- {"t":number,"tip":"kamera","lat":number,"lon":number,"zoom":number}  (zoom 0.6-4.4)
- {"t":number,"tip":"senaryo","tur":${JSON.stringify(TURLER.join("|"))},"lat":number,"lon":number,"parametreler":{...}}
  parametre anahtarları ve aralıkları: ${Object.entries(PARAM_ARALIK).map(([k, [a, b]]) => `${k}:${a}-${b}`).join(", ")}
  (meteor: cap[m],hiz[km/s],aci; deprem: mw; tsunami: mw,derinlik,mesafe; gunes: sinif(1-4),sayi; volkan: vei)
- {"t":number,"tip":"efekt","ad":${JSON.stringify(EFEKT_ADLARI.join("|"))},"siddet":0.1-2}
- {"t":number,"tip":"tema","tema":"mavi"|"kirmizi"}
Kurallar: olayları zamana göre sırala; ilk 2 saniyede bir anlat ve bir kamera olsun; bir "senaryo" olayı (çarpma/patlama anı) mutlaka olsun ve ondan hemen sonra sarsinti/parlama/sok_dalgasi efektleri gelsin; sonda sakinleşen bir anlat ile bitir.`;
}

const medyan = (a: number[]) => { const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

export type Sonuc = { saglayici: string; rol: Rol; film: Film };

/** Rol bazlı birleştirme: anlatım yazardan, kamera yönetmenden, senaryo parametreleri medyan, efektler birleşim. */
export function birlestir(sonuclar: Sonuc[], sure: 30 | 60): Film | null {
  if (!sonuclar.length) return null;
  if (sonuclar.length === 1) return { ...sonuclar[0].film, kaynaklar: [sonuclar[0].saglayici] };
  const say = (s: Sonuc, tip: string) => s.film.olaylar.filter((o) => o.tip === tip).length;
  const en = (tip: string, tercih: Rol) => [...sonuclar].sort((a, b) => (say(b, tip) + (b.rol === tercih ? 0.5 : 0)) - (say(a, tip) + (a.rol === tercih ? 0.5 : 0)))[0];
  const yazar = en("anlat", "YAZAR"), yonetmen = en("kamera", "YONETMEN");
  const olaylar: FilmOlay[] = [];
  olaylar.push(...yazar.film.olaylar.filter((o) => o.tip === "anlat"));
  olaylar.push(...yonetmen.film.olaylar.filter((o) => o.tip === "kamera"));
  // Senaryo olayları: aynı tür + 5 sn kovasında kümele, medyan al
  const kume = new Map<string, Extract<FilmOlay, { tip: "senaryo" }>[]>();
  for (const s of sonuclar) for (const o of s.film.olaylar) if (o.tip === "senaryo") { const k = `${o.tur}:${Math.round(o.t / 5)}`; kume.set(k, [...(kume.get(k) ?? []), o]); }
  for (const g of kume.values()) {
    const anahtarlar = new Set(g.flatMap((o) => Object.keys(o.parametreler)));
    const p: Record<string, number> = {}; for (const k of anahtarlar) p[k] = medyan(g.filter((o) => k in o.parametreler).map((o) => o.parametreler[k]));
    olaylar.push({ t: medyan(g.map((o) => o.t)), tip: "senaryo", tur: g[0].tur, lat: medyan(g.map((o) => o.lat)), lon: medyan(g.map((o) => o.lon)), parametreler: p });
  }
  // Efektler: birleşim, aynı ad 1.5 sn içinde tekilleştirilir (şiddeti yüksek olan kalır)
  const efektler: Extract<FilmOlay, { tip: "efekt" }>[] = [];
  for (const s of sonuclar) for (const o of s.film.olaylar) if (o.tip === "efekt") {
    const var_ = efektler.find((e) => e.ad === o.ad && Math.abs(e.t - o.t) < 1.5);
    if (var_) { if (o.siddet > var_.siddet) var_.siddet = o.siddet; } else efektler.push({ ...o });
  }
  olaylar.push(...efektler);
  const tema = sonuclar.flatMap((s) => s.film.olaylar).find((o) => o.tip === "tema"); if (tema) olaylar.push(tema);
  olaylar.sort((a, b) => a.t - b.t);
  return { baslik: yazar.film.baslik, sure, olaylar: olaylar.slice(0, 90), kaynaklar: sonuclar.map((s) => s.saglayici) };
}

/** İnternet/anahtar yokken de çalışan yerel senaryo yazarı (fizik hesaplı). */
export function yerelFilm(istek: string, sure: 30 | 60): Film {
  const n = niyetCoz(istek);
  const tur = (TURLER as readonly string[]).includes(n.varliklar.tur) ? (n.varliklar.tur as (typeof TURLER)[number]) : "meteor";
  const sehir = sehirBul(istek) ?? sehirleriYukle()[0];
  const p: Record<string, number> = tur === "meteor" ? { cap: Number(n.varliklar.cap ?? 400), hiz: 22, aci: 45, yogunluk: 3000 } : tur === "deprem" ? { mw: Number(n.varliklar.mw ?? 7.8) } : tur === "tsunami" ? { mw: 8.7, derinlik: 4000, mesafe: 3000 } : tur === "gunes" ? { sinif: 4, sayi: 9 } : { vei: 6 };
  const e = senaryoEtkisi(tur, p), k = sure / 30, ad = { meteor: "Göktaşı", deprem: "Deprem", tsunami: "Tsunami", gunes: "Güneş fırtınası", volkan: "Volkan" }[tur];
  const T = (x: number) => Math.round(x * k * 10) / 10;
  const o: FilmOlay[] = [
    { t: 0, tip: "tema", tema: "mavi" }, { t: 0.2, tip: "efekt", ad: "tarama", siddet: 1 },
    { t: 0.5, tip: "kamera", lat: 20, lon: sehir.lon, zoom: 0.9 }, { t: 0.8, tip: "anlat", metin: `Dikkat. ${sehir.ad} bölgesinde ${ad.toLowerCase()} senaryosu hesaplanıyor.` },
    { t: T(5), tip: "kamera", lat: sehir.lat, lon: sehir.lon, zoom: 2.4 }, { t: T(6), tip: "efekt", ad: "kuyruklu", siddet: 1 },
    { t: T(7), tip: "anlat", metin: `Toplam enerji ${e.megaton < 1 ? e.megaton.toFixed(2) : e.megaton.toFixed(0)} megaton TNT eşdeğeri.` },
    { t: T(8), tip: "tema", tema: "kirmizi" }, { t: T(9), tip: "senaryo", tur, lat: sehir.lat, lon: sehir.lon, parametreler: p },
    { t: T(9), tip: "efekt", ad: "parlama", siddet: 1.4 }, { t: T(9.1), tip: "efekt", ad: "sarsinti", siddet: 1.5 }, { t: T(9.2), tip: "efekt", ad: "sok_dalgasi", siddet: 1.2 },
    { t: T(9.4), tip: "efekt", ad: "kivilcim", siddet: 1.3 }, { t: T(10), tip: "efekt", ad: "kor", siddet: 1 },
    { t: T(11), tip: "anlat", metin: e.satirlar.slice(0, 3).join(". ") + "." }, { t: T(14), tip: "efekt", ad: "glitch", siddet: 0.8 },
    { t: T(19), tip: "kamera", lat: sehir.lat, lon: sehir.lon, zoom: 1.1 }, { t: T(20), tip: "tema", tema: "mavi" },
    { t: T(24), tip: "efekt", ad: "aurora", siddet: 1 }, { t: T(26), tip: "anlat", metin: "Simülasyon tamamlandı, efendim. Sistemler normale dönüyor." },
  ];
  return { baslik: `${sehir.ad} – ${ad}`, sure, olaylar: o, kaynaklar: ["yerel"] };
}

export type FilmSonucu = { film: Film; kaynaklar: string[]; hatalar: Record<string, string>; yerel: boolean; sureMs: number };

export async function filmUret(istek: string, o: { sure?: 30 | 60; uretimMs?: number; saglayicilar?: Saglayici[] } = {}): Promise<FilmSonucu> {
  const sure = o.sure ?? 30, uretimMs = Math.min(60_000, Math.max(100, o.uretimMs ?? 30_000));
  const liste = o.saglayicilar ?? hazirSaglayicilar();
  const baslangic = Date.now(), hatalar: Record<string, string> = {}, sonuclar: Sonuc[] = [];
  await Promise.all(liste.map(async (s, i) => {
    const rol = ROLLER[i % ROLLER.length], ac = new AbortController();
    const zaman = setTimeout(() => ac.abort(), uretimMs);
    try {
      const metin = await Promise.race([
        s.sor({ sistem: sistemPromptu(sure, rol), kullanici: `İstek: ${istek}`, json: true, maxToken: sure === 30 ? 1800 : 3200, sinyal: ac.signal }),
        new Promise<never>((_, rej) => ac.signal.addEventListener("abort", () => rej(new Error("süre doldu")))),
      ]);
      const film = filmDogrula(jsonCikar(metin), sure, s.ad);
      if (film) sonuclar.push({ saglayici: s.ad, rol, film }); else hatalar[s.ad] = "geçersiz JSON/şema";
    } catch (e) { hatalar[s.ad] = (e as Error).message; hataIsle(s.ad, e); } finally { clearTimeout(zaman); }
  }));
  const birlesik = birlestir(sonuclar, sure);
  if (birlesik) return { film: birlesik, kaynaklar: birlesik.kaynaklar, hatalar, yerel: false, sureMs: Date.now() - baslangic };
  const y = yerelFilm(istek, sure);
  return { film: y, kaynaklar: ["yerel"], hatalar, yerel: true, sureMs: Date.now() - baslangic };
}

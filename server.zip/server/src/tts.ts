import { elevenSentez, elevenHazirMi } from "./eleven.ts";
export type TtsSonuc = { motor: "eleven"; ses: Buffer; mime: "audio/mpeg" } | { motor: "tarayici"; metin: string };

/** ElevenLabs varsa ses üretir; yoksa istemciye tarayıcı sentezini kullanmasını söyler. */
export async function tts(metin: string): Promise<TtsSonuc> {
  if (elevenHazirMi()) {
    const s = await elevenSentez(metin);
    if (s.ok) return { motor: "eleven", ses: s.ses, mime: "audio/mpeg" };
  }
  return { motor: "tarayici", metin };
}

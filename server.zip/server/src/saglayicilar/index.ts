import type { Saglayici } from "./tur.ts";
import { anthropic } from "./anthropic.ts";
import { gemini } from "./gemini.ts";
import { ollama } from "./ollama.ts";
import { openaiUyumlu } from "./openaiUyumlu.ts";
import { sogumada } from "./tur.ts";

// Model adları .env ile değiştirilebilir (JARVIS_*_MODEL); ücretsiz katmanlar ve model adları zamanla değişir.
// ---- Kalıcı ücretsiz katmanı olanlar (öncelikli) ----
export const groq = openaiUyumlu("groq", "https://api.groq.com/openai/v1/chat/completions", "GROQ_API_KEY", "JARVIS_GROQ_MODEL", "llama-3.3-70b-versatile", true, true);
export const mistral = openaiUyumlu("mistral", "https://api.mistral.ai/v1/chat/completions", "MISTRAL_API_KEY", "JARVIS_MISTRAL_MODEL", "mistral-small-latest", true, true);
export const openrouter = openaiUyumlu("openrouter", "https://openrouter.ai/api/v1/chat/completions", "OPENROUTER_API_KEY", "JARVIS_OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free", false, true);
export const nvidia = openaiUyumlu("nvidia", "https://integrate.api.nvidia.com/v1/chat/completions", "NVIDIA_API_KEY", "JARVIS_NVIDIA_MODEL", "meta/llama-3.1-70b-instruct", false, true);
// ---- Ücretsiz/kredi: koşullar değişiyor, kendi hesabınızda doğrulayın ----
export const cerebras = openaiUyumlu("cerebras", "https://api.cerebras.ai/v1/chat/completions", "CEREBRAS_API_KEY", "JARVIS_CEREBRAS_MODEL", "llama-3.3-70b", true, true);
export const github = openaiUyumlu("github", "https://models.github.ai/inference/chat/completions", "GITHUB_MODELS_TOKEN", "JARVIS_GITHUB_MODEL", "openai/gpt-4o-mini", true, true);
// ---- Ücretli olabilir (xAI ve OpenAI API'nin kalıcı ücretsiz katmanı yok; ChatGPT aboneliği API anahtarı değildir) ----
export const grok = openaiUyumlu("grok", "https://api.x.ai/v1/chat/completions", "XAI_API_KEY", "JARVIS_GROK_MODEL", "grok-3-mini");
export const openai = openaiUyumlu("openai", "https://api.openai.com/v1/chat/completions", "OPENAI_API_KEY", "JARVIS_OPENAI_MODEL", "gpt-4o-mini");
export const deepseek = openaiUyumlu("deepseek", "https://api.deepseek.com/chat/completions", "DEEPSEEK_API_KEY", "JARVIS_DEEPSEEK_MODEL", "deepseek-chat");

// Öncelik sırası: ücretsizler önce
export const TUM_SAGLAYICILAR: Saglayici[] = [gemini, groq, mistral, openrouter, nvidia, ollama, cerebras, github, grok, openai, deepseek, anthropic];

/** JARVIS_BEYINLER=gemini,groq,mistral ile sınırlanabilir; JARVIS_SADECE_UCRETSIZ=1 ücretli olabilenleri dışlar; JARVIS_MAKS_BEYIN sayıyı sınırlar. */
export function hazirSaglayicilar(liste: Saglayici[] = TUM_SAGLAYICILAR, env: Record<string, string | undefined> = process.env): Saglayici[] {
  const secili = (env.JARVIS_BEYINLER ?? "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  let s = liste.filter((x) => x.hazir() && !sogumada(x.ad));
  if (secili.length) s = s.filter((x) => secili.includes(x.ad));
  if (env.JARVIS_SADECE_UCRETSIZ === "1") s = s.filter((x) => x.ucretsiz);
  const maks = Number(env.JARVIS_MAKS_BEYIN ?? 5);
  return s.slice(0, Number.isFinite(maks) && maks > 0 ? maks : 5);
}
export { anthropic, gemini, ollama };
export type { Saglayici } from "./tur.ts";

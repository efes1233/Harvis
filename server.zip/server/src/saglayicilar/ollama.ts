import { SaglayiciHatasi, type Saglayici } from "./tur.ts";

// Yerel, tamamen ücretsiz: https://ollama.com  →  `ollama pull llama3.2`  →  .env: OLLAMA_MODEL=llama3.2
export const ollama: Saglayici = {
  ad: "ollama",
  ucretsiz: true,
  model: () => process.env.OLLAMA_MODEL ?? "llama3.2",
  hazir: () => Boolean(process.env.OLLAMA_MODEL),
  async sor({ sistem, kullanici, json, sinyal }) {
    const taban = process.env.OLLAMA_URL ?? "http://localhost:11434";
    const r = await fetch(`${taban}/api/chat`, { method: "POST", signal: sinyal, headers: { "content-type": "application/json" },
      body: JSON.stringify({ model: ollama.model(), stream: false, ...(json ? { format: "json" } : {}), messages: [{ role: "system", content: sistem }, { role: "user", content: kullanici }] }) });
    if (!r.ok) throw new SaglayiciHatasi("ollama", r.status);
    const j = (await r.json()) as { message?: { content?: string } };
    return j.message?.content ?? "";
  },
};

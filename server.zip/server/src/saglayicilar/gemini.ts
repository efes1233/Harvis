import { SaglayiciHatasi, type Saglayici } from "./tur.ts";

export const gemini: Saglayici = {
  ad: "gemini",
  ucretsiz: true,
  model: () => process.env.JARVIS_GEMINI_MODEL ?? "gemini-2.0-flash",
  hazir: () => Boolean(process.env.GEMINI_API_KEY),
  async sor({ sistem, kullanici, json, maxToken = 1500, sinyal }) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${gemini.model()}:generateContent`;
    const r = await fetch(url, {
      method: "POST", signal: sinyal,
      headers: { "x-goog-api-key": process.env.GEMINI_API_KEY ?? "", "content-type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: sistem }] }, contents: [{ role: "user", parts: [{ text: kullanici }] }],
        generationConfig: { maxOutputTokens: maxToken, ...(json ? { responseMimeType: "application/json" } : {}) },
      }),
    });
    if (!r.ok) throw new SaglayiciHatasi("gemini", r.status);
    const j = (await r.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
    return (j.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("");
  },
};

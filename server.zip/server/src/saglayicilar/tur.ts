export type SorOpsiyon = { sistem: string; kullanici: string; json?: boolean; maxToken?: number; sinyal?: AbortSignal };
export type Saglayici = {
  ad: string;                 // örn. "anthropic"
  ucretsiz?: boolean;         // kalıcı ücretsiz katmanı var mı (değişebilir; sağlayıcı sayfasından doğrulayın)
  model: () => string;
  hazir: () => boolean;       // anahtar tanımlı mı
  sor: (o: SorOpsiyon) => Promise<string>;
};
export class SaglayiciHatasi extends Error {
  durum: number;
  constructor(ad: string, durum: number, ek = "") { super(`${ad} HTTP ${durum}${ek ? ": " + ek : ""}`); this.name = "SaglayiciHatasi"; this.durum = durum; }
}

// 429 (kota/hız sınırı) alan sağlayıcı kısa süre dinlendirilir; ücretsiz kotayı boşa harcamayız.
const soguma = new Map<string, number>();
export const sogumaBaslat = (ad: string, ms = 60_000, simdi = Date.now()) => { soguma.set(ad, simdi + ms); };
export const sogumada = (ad: string, simdi = Date.now()) => (soguma.get(ad) ?? 0) > simdi;
export const sogumaTemizle = () => soguma.clear();
export function hataIsle(ad: string, e: unknown) { if (e instanceof SaglayiciHatasi && (e.durum === 429 || e.durum === 402)) sogumaBaslat(ad); }

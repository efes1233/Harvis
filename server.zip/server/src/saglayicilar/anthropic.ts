import { SaglayiciHatasi, type Saglayici } from "./tur.ts";

export const anthropic: Saglayici = {
  ad: "anthropic",
  ucretsiz: false,
  model: () => process.env.JARVIS_ANTHROPIC_MODEL ?? "claude-sonnet-4-6",
  hazir: () => Boolean(process.env.ANTHROPIC_API_KEY),
  async sor({ sistem, kullanici, maxToken = 1500, sinyal }) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", signal: sinyal,
      headers: { "x-api-key": process.env.ANTHROPIC_API_KEY ?? "", "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: anthropic.model(), max_tokens: maxToken, system: sistem, messages: [{ role: "user", content: kullanici }] }),
    });
    if (!r.ok) throw new SaglayiciHatasi("anthropic", r.status);
    const j = (await r.json()) as { content?: { type: string; text?: string }[] };
    return (j.content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
  },
};

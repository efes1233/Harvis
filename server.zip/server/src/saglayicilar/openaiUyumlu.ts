// OpenAI Chat Completions uyumlu tüm servisler için fabrika (OpenAI, xAI Grok, DeepSeek, Mistral, Groq, OpenRouter).
import { SaglayiciHatasi, type Saglayici } from "./tur.ts";

export function openaiUyumlu(ad: string, url: string, anahtarEnv: string, modelEnv: string, varsayilanModel: string, jsonModu = true, ucretsiz = false): Saglayici {
  const s: Saglayici = {
    ad, ucretsiz,
    model: () => process.env[modelEnv] ?? varsayilanModel,
    hazir: () => Boolean(process.env[anahtarEnv]),
    async sor({ sistem, kullanici, json, maxToken = 1500, sinyal }) {
      const govde: Record<string, unknown> = { model: s.model(), max_tokens: maxToken, messages: [{ role: "system", content: sistem }, { role: "user", content: kullanici }] };
      if (json && jsonModu) govde.response_format = { type: "json_object" };
      const r = await fetch(url, { method: "POST", signal: sinyal, headers: { authorization: `Bearer ${process.env[anahtarEnv] ?? ""}`, "content-type": "application/json" }, body: JSON.stringify(govde) });
      if (!r.ok) throw new SaglayiciHatasi(ad, r.status);
      const j = (await r.json()) as { choices?: { message?: { content?: string } }[] };
      return j.choices?.[0]?.message?.content ?? "";
    },
  };
  return s;
}

// Serbest sohbet: bağlı yapay zekâlardan en hızlı cevap ("hizli") veya hepsinin sentezi ("birlestir").
import { hazirSaglayicilar, type Saglayici } from "./saglayicilar/index.ts";
import { hataIsle } from "./saglayicilar/tur.ts";

const SISTEM = "Sen JARVIS'sin: kısa, zarif, hafif esprili bir yapay zeka asistanısın. Türkçe yanıt ver, en fazla 3 cümle.";

export async function sohbet(metin: string, o: { saglayicilar?: Saglayici[]; mod?: "hizli" | "birlestir"; zamanMs?: number } = {}): Promise<{ yanit: string; kaynak: string } | null> {
  const liste = o.saglayicilar ?? hazirSaglayicilar();
  if (!liste.length) return null;
  const mod = o.mod ?? (process.env.JARVIS_SOHBET_MODU === "birlestir" ? "birlestir" : "hizli");
  const zamanMs = o.zamanMs ?? 12_000, ac = new AbortController(); const zaman = setTimeout(() => ac.abort(), zamanMs);
  const sor = (s: Saglayici) => s.sor({ sistem: SISTEM, kullanici: metin, maxToken: 300, sinyal: ac.signal }).then((y) => { if (!y.trim()) throw new Error("boş"); return { yanit: y.trim(), kaynak: s.ad }; }).catch((e) => { hataIsle(s.ad, e); throw e; });
  try {
    if (mod === "hizli") return await Promise.any(liste.map(sor)).catch(() => null);
    const tamam = (await Promise.allSettled(liste.map(sor))).flatMap((r) => (r.status === "fulfilled" ? [r.value] : []));
    if (!tamam.length) return null;
    if (tamam.length === 1) return tamam[0];
    const yazici = liste.find((s) => s.ad === tamam[0].kaynak) ?? liste[0];
    const ozet = await yazici.sor({ sistem: SISTEM + " Aşağıdaki aday cevapları tek, tutarlı ve kısa bir cevapta birleştir.", kullanici: `Soru: ${metin}\n\n` + tamam.map((t, i) => `Aday ${i + 1}: ${t.yanit}`).join("\n"), maxToken: 300 }).catch(() => tamam[0].yanit);
    return { yanit: ozet.trim(), kaynak: tamam.map((t) => t.kaynak).join("+") };
  } finally { clearTimeout(zaman); ac.abort(); }
}

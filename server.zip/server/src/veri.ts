import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import type { Senaryo } from "../../shared/types.ts";

export const KOK = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
export type Sehir = { ad: string; lat: number; lon: number; nufusMilyon: number };

export function sehirleriYukle(): Sehir[] {
  return JSON.parse(readFileSync(join(KOK, "assets/data/sehirler.json"), "utf-8"));
}
export function senaryolariYukle(): Senaryo[] {
  const d = join(KOK, "assets/senaryolar");
  if (!existsSync(d)) return [];
  return readdirSync(d).filter((f) => f.endsWith(".json")).sort().map((f) => JSON.parse(readFileSync(join(d, f), "utf-8")));
}

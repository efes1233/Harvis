// Minimal .env yükleyici (bağımlılıksız). Zaten tanımlı ortam değişkenlerini ezmez.
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

export function envCoz(icerik: string): Record<string, string> {
  const o: Record<string, string> = {};
  for (const satir of icerik.split(/\r?\n/)) {
    const m = /^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/.exec(satir);
    if (!m || satir.trim().startsWith("#")) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    o[m[1]] = v;
  }
  return o;
}
export function envYukle(yol = join(dirname(fileURLToPath(import.meta.url)), "..", "..", ".env")) {
  if (!existsSync(yol)) return;
  for (const [k, v] of Object.entries(envCoz(readFileSync(yol, "utf-8")))) if (process.env[k] === undefined) process.env[k] = v;
}
envYukle();

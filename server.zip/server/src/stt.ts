// Sesten metne. Tarayıcı Web Speech API metni doğrudan gönderir (anahtarsız).
// Ham ses gelirse OPENAI_API_KEY varsa Whisper kullanılır.
export type SttSonuc = { ok: boolean; metin: string; kaynak: "tarayici" | "whisper" | "yok"; hata?: string };

export async function sttCoz(girdi: { metin?: string; sesBase64?: string; mime?: string }): Promise<SttSonuc> {
  if (girdi.metin && girdi.metin.trim()) return { ok: true, metin: girdi.metin.trim(), kaynak: "tarayici" };
  if (girdi.sesBase64) {
    const key = process.env.OPENAI_API_KEY;
    if (!key) return { ok: false, metin: "", kaynak: "yok", hata: "OPENAI_API_KEY tanımlı değil; tarayıcı konuşma tanıma kullanın." };
    const buf = Buffer.from(girdi.sesBase64, "base64");
    const fd = new FormData();
    fd.append("file", new Blob([buf], { type: girdi.mime ?? "audio/webm" }), "ses.webm");
    fd.append("model", "whisper-1");
    fd.append("language", "tr");
    const r = await fetch("https://api.openai.com/v1/audio/transcriptions", { method: "POST", headers: { Authorization: `Bearer ${key}` }, body: fd });
    if (!r.ok) return { ok: false, metin: "", kaynak: "whisper", hata: `Whisper HTTP ${r.status}` };
    const j = (await r.json()) as { text?: string };
    return { ok: true, metin: j.text ?? "", kaynak: "whisper" };
  }
  return { ok: false, metin: "", kaynak: "yok", hata: "girdi yok" };
}

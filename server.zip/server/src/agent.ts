// Ajan: niyet -> araç/simülasyon eylemi. İstemciye yanıt metni + eylem listesi döner.
import type { Senaryo } from "../../shared/types.ts";
import { senaryoEtkisi } from "../../shared/fizik.ts";
import { niyetCoz, llmYanit, sehirBul } from "./beyin.ts";
import { aracCalistir } from "./araclar.ts";
import { sehirleriYukle, senaryolariYukle } from "./veri.ts";
import { filmUret } from "./birlesim.ts";
import type { Film } from "../../shared/film.ts";

export type Eylem =
  | { tip: "senaryo"; senaryo: Senaryo; etki: ReturnType<typeof senaryoEtkisi> }
  | { tip: "kamera"; ac: boolean }
  | { tip: "dunya"; komut: "yakinlas" | "uzaklas" | "dondur" | "sifirla" }
  | { tip: "odak"; lat: number; lon: number; ad: string }
  | { tip: "tema"; tema: "mavi" | "kirmizi" }
  | { tip: "film"; film: Film; yerel: boolean };
export type AjanYaniti = { yanit: string; niyet: string; eylemler: Eylem[] };

const VARSAYILAN: Record<string, Record<string, number>> = {
  meteor: { cap: 200, hiz: 20, aci: 45, yogunluk: 3000 },
  deprem: { mw: 7.2 }, tsunami: { mw: 8.5, derinlik: 4000, mesafe: 3000 },
  gunes: { sinif: 4, sayi: 5 }, volkan: { vei: 6 },
};
const ADLAR: Record<string, string> = { meteor: "Meteor çarpması", deprem: "Deprem", tsunami: "Tsunami", gunes: "Güneş patlaması", volkan: "Volkanik patlama" };

export function senaryoKur(tur: string, sehirAd: string | undefined, ek: Record<string, number> = {}): Senaryo {
  const s = sehirAd ? sehirleriYukle().find((x) => x.ad === sehirAd) : undefined;
  const p = { ...(VARSAYILAN[tur] ?? {}), ...ek };
  return { id: `canli-${tur}-${Date.now()}`, ad: `${ADLAR[tur]}${s ? " – " + s.ad : ""}`, tur: tur as Senaryo["tur"],
    lat: s?.lat ?? 0, lon: s?.lon ?? 0, parametreler: p, aciklama: "Sesli komutla oluşturuldu" };
}

export async function ajanIsle(metin: string): Promise<AjanYaniti> {
  const n = niyetCoz(metin);
  const e: Eylem[] = [];
  switch (n.ad) {
    case "senaryo_baslat": {
      const ek: Record<string, number> = {};
      if (n.varliklar.cap) ek.cap = Number(n.varliklar.cap);
      if (n.varliklar.mw) ek.mw = Number(n.varliklar.mw);
      const kayitli = senaryolariYukle().find((s) => s.tur === n.varliklar.tur && (!n.varliklar.sehir || s.ad.includes(n.varliklar.sehir)) && !n.varliklar.cap && !n.varliklar.mw);
      const sen = kayitli ?? senaryoKur(n.varliklar.tur, n.varliklar.sehir, ek);
      const etki = senaryoEtkisi(sen.tur, sen.parametreler);
      e.push({ tip: "senaryo", senaryo: sen, etki });
      return { yanit: `Simülasyon başlatılıyor, efendim. ${sen.ad}. ${etki.satirlar.slice(0, 3).join(". ")}.`, niyet: n.ad, eylemler: e };
    }
    case "film_uret": {
      const sure = n.varliklar.sure === "60" ? 60 : 30;
      const r = await filmUret(n.varliklar.istek, { sure, uretimMs: Number(process.env.JARVIS_URETIM_SN ?? 30) * 1000 });
      const kim = r.yerel ? "yerel yazar" : r.kaynaklar.join(", ");
      return { yanit: `Senaryo hazır: ${r.film.baslik}. ${sure} saniyelik film başlıyor. Yazanlar: ${kim}.`, niyet: n.ad, eylemler: [{ tip: "film", film: r.film, yerel: r.yerel }] };
    }
    case "dunya_yakinlas": return { yanit: "Yaklaşıyorum.", niyet: n.ad, eylemler: [{ tip: "dunya", komut: "yakinlas" }] };
    case "dunya_uzaklas": return { yanit: "Uzaklaşıyorum.", niyet: n.ad, eylemler: [{ tip: "dunya", komut: "uzaklas" }] };
    case "dunya_dondur": return { yanit: "Dünya dönüyor.", niyet: n.ad, eylemler: [{ tip: "dunya", komut: "dondur" }] };
    case "dunya_sifirla": return { yanit: "Görünüm sıfırlandı.", niyet: n.ad, eylemler: [{ tip: "dunya", komut: "sifirla" }] };
    case "sehre_odaklan": { const s = sehirBul(metin)!; return { yanit: `${s.ad} üzerine odaklanıyorum.`, niyet: n.ad, eylemler: [{ tip: "odak", lat: s.lat, lon: s.lon, ad: s.ad }] }; }
    case "kamera_ac": return { yanit: "El takibi etkinleştiriliyor. Kameraya izin vermeniz gerekebilir.", niyet: n.ad, eylemler: [{ tip: "kamera", ac: true }] };
    case "kamera_kapat": return { yanit: "El takibi kapatıldı.", niyet: n.ad, eylemler: [{ tip: "kamera", ac: false }] };
    case "hud_tema": return { yanit: n.varliklar.tema === "kirmizi" ? "Kırmızı protokol devrede." : "Mavi arayüze dönüldü.", niyet: n.ad, eylemler: [{ tip: "tema", tema: n.varliklar.tema as "mavi" | "kirmizi" }] };
    case "selam": return { yanit: "Hizmetinizdeyim, efendim. Nasıl yardımcı olabilirim?", niyet: n.ad, eylemler: [] };
    case "tesekkur": return { yanit: "Rica ederim, efendim.", niyet: n.ad, eylemler: [] };
    case "arac": { const r = await aracCalistir(n.varliklar.arac, metin); return { yanit: r.metin, niyet: `arac:${n.varliklar.arac}`, eylemler: e }; }
    default: {
      const l = await llmYanit(metin);
      return { yanit: l ?? "Bunu anlayamadım efendim. Meteor simülasyonu, birim çevirme ya da hesaplama gibi komutlar deneyebilirsiniz.", niyet: "bilinmiyor", eylemler: e };
    }
  }
}

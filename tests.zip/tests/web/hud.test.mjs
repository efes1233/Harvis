// 60 HUD widget'ını esbuild ile derleyip react-dom/server ile gerçekten render eder.
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { execSync } from "node:child_process";
import { writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const req = createRequire(import.meta.url);
const esbuild = [process.env.ESBUILD_PATH, "esbuild", "/opt/npm-tools/node_modules/esbuild"].filter(Boolean).map((a) => { try { return req(a); } catch { return null; } }).find(Boolean);
assert.ok(esbuild, "esbuild gerekli");
let global = ""; try { global = execSync("npm root -g", { encoding: "utf-8" }).trim(); } catch {}
const dir = mkdtempSync(join(tmpdir(), "hud-")); const out = join(dir, "t.cjs");
writeFileSync(join(dir, "giris.tsx"), `import React from "react"; import { renderToStaticMarkup } from "react-dom/server";
import { TUM_WIDGETLAR } from ${JSON.stringify(process.cwd() + "/web/src/hud/index.ts")};
export const sonuc = Object.fromEntries(Object.entries(TUM_WIDGETLAR).map(([ad, C]) => [ad, renderToStaticMarkup(React.createElement(C as any, {}))]));`);
await esbuild.build({ entryPoints: [join(dir, "giris.tsx")], outfile: out, bundle: true, platform: "node", format: "cjs", jsx: "automatic", nodePaths: [global, process.env.NODE_PATH].filter(Boolean), logLevel: "error" });
const { sonuc } = req(out);
const adlar = Object.keys(sonuc); assert.equal(adlar.length, 60);
for (const a of adlar) { assert.ok(sonuc[a].startsWith("<svg"), a + " svg üretmeli"); assert.ok(sonuc[a].includes("aria-label"), a + " erişilebilir etiket"); assert.ok(sonuc[a].length > 200, a); }
assert.equal(new Set(Object.values(sonuc)).size, 60, "her widget benzersiz çıktı vermeli");
console.log("ok hud (60 widget)");

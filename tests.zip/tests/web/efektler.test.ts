import assert from "node:assert/strict";
import { Efektler } from "../../web/src/evren/efektler.ts";
import { FilmOynatici, zamanla } from "../../web/src/evren/film.ts";
import { Motor } from "../../web/src/evren/motor.ts";
import { EFEKT_ADLARI, type Film } from "../../shared/film.ts";

let tohum = 7; const rnd = () => ((tohum = (tohum * 1664525 + 1013904223) >>> 0) / 4294967296);

// Her efekt adı tetiklenebilir ve zamanla söner
for (const ad of EFEKT_ADLARI) {
  const e = new Efektler(rnd); e.tetikle(ad, 1.5, { x: 0.4, y: 0.6 });
  assert.ok(e.sarsinti > 0 || e.glitch > 0 || e.parlama > 0 || e.aurora > 0.18 || e.tarama >= 0 || e.yagmur > 0 || e.aktifSayisi > 0, ad + " iz bırakmalı");
  for (let i = 0; i < 400; i++) e.adim(0.05);
  assert.equal(e.parcaciklar.length + e.simsekler.length + e.sokDalgalari.length, 0, ad + " sönmeli");
  assert.equal(e.sarsinti, 0); assert.equal(e.glitch, 0); assert.ok(e.aurora < 0.25, ad + " aurora tabana iner: " + e.aurora);
}
// Parçacık sayıları ve sınırlar
const e = new Efektler(rnd); e.tetikle("kivilcim", 1, { x: 0.5, y: 0.5 }); assert.equal(e.parcaciklar.length, 70);
e.adim(0.5); assert.ok(e.parcaciklar.every((p) => Math.hypot(p.x - 0.5, p.y - 0.5) > 0), "parçacıklar hareket eder");
for (let i = 0; i < 30; i++) e.tetikle("kor", 2); assert.ok(e.parcaciklar.length <= 1200, "parçacık tavanı");
const kor = new Efektler(rnd); kor.tetikle("kor", 1); const y0 = kor.parcaciklar[0].y; for (let i = 0; i < 20; i++) kor.adim(0.05); assert.ok(kor.parcaciklar[0]?.vy > -0.6, "yerçekimi aşağı çeker");
// Şimşek hedefe uzanır
const s = new Efektler(rnd); s.tetikle("simsek", 1, { x: 0.3, y: 0.7 }); assert.ok(s.simsekler.length >= 2); const son = s.simsekler[0].pts.at(-1)!; assert.ok(Math.abs(son.x - 0.3) < 1e-9 && Math.abs(son.y - 0.7) < 1e-9);
// Sarsıntı ofseti
const sa = new Efektler(rnd); assert.deepEqual(sa.sarsintiOfset(), { x: 0, y: 0 }); sa.tetikle("sarsinti", 1); sa.adim(0.016); assert.ok(Math.hypot(sa.sarsintiOfset().x, sa.sarsintiOfset().y) > 0.1);
// Tarama çizgisi 0→1 → kapanır
const ta = new Efektler(rnd); ta.tetikle("tarama"); for (let i = 0; i < 10; i++) ta.adim(0.1); assert.ok(ta.tarama > 0.4 && ta.tarama < 0.6, "tarama ortada: " + ta.tarama); for (let i = 0; i < 15; i++) ta.adim(0.1); assert.equal(ta.tarama, -1);

// Motor: çarpmada otomatik efektler
const m = new Motor(); m.senaryoBaslat({ id: "t", ad: "t", tur: "meteor", lat: 41, lon: 29, parametreler: { cap: 300, hiz: 20, aci: 45, yogunluk: 3000 }, aciklama: "" });
for (let i = 0; i < 20; i++) m.adim(0.1); assert.equal(m.efekt.sarsinti, 0);
for (let i = 0; i < 12; i++) m.adim(0.1); assert.ok(m.olaylar.includes("carpma")); assert.ok(m.efekt.sokDalgalari.length >= 1 && m.efekt.parcaciklar.length > 50, "çarpma efektleri");
for (const tur of ["deprem", "gunes", "tsunami", "volkan"] as const) { const k = new Motor(); k.senaryoBaslat({ id: "t", ad: "t", tur, lat: 10, lon: 10, parametreler: { mw: 8, sinif: 4, sayi: 5, derinlik: 4000, mesafe: 1000, vei: 6 }, aciklama: "" }); for (let i = 0; i < 40; i++) k.adim(0.1); assert.ok(k.efekt.aktifSayisi > 0 || k.efekt.aurora > 0.2 || k.efekt.yagmur > 0 || k.efekt.glitch > 0, tur + " efekt üretmeli"); }

// Film oynatıcı
const film: Film = { baslik: "T", sure: 30, kaynaklar: ["x"], olaylar: [
  { t: 12, tip: "senaryo", tur: "meteor", lat: 41, lon: 29, parametreler: { cap: 200 } }, { t: 1, tip: "anlat", metin: "bir" }, { t: 2, tip: "kamera", lat: 40, lon: 30, zoom: 2 },
  { t: 5, tip: "tema", tema: "kirmizi" }, { t: 6, tip: "efekt", ad: "tarama", siddet: 1 }, { t: 20, tip: "anlat", metin: "iki" }] };
assert.equal(zamanla(film).find((o) => o.tip === "senaryo")!.t, 9, "senaryo 3 sn erken başlar");
const log: string[] = []; const mm = new Motor(); const fo = new FilmOynatici(); let bitti = false;
fo.baslat(film);
for (let i = 0; i < 320; i++) { mm.adim(0.1); fo.adim(0.1, { motor: mm, anlat: (x) => log.push("anlat:" + x), tema: (x) => log.push("tema:" + x), bitti: () => { bitti = true; } }); }
assert.deepEqual(log, ["anlat:bir", "tema:kirmizi", "anlat:iki"]); assert.ok(bitti); assert.equal(fo.calisiyor, false);
assert.ok(mm.olaylar.includes("basla:meteor") && mm.olaylar.includes("carpma"), "senaryo oynatıldı ve çarptı");
console.log("ok efektler");

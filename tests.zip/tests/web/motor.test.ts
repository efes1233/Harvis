import assert from "node:assert/strict";
import { Motor, daireNoktalari, RAD } from "../../web/src/evren/motor.ts";
import { jestUygula } from "../../web/src/evren/evrenFeatures.ts";
import { haversineKm } from "../../shared/fizik.ts";

const m = new Motor();
// projekte <-> ekrandan tutarlılığı
for (const [la, lo] of [[41, 29], [-33, 151], [10, -100], [60, 5]]) {
  const p = m.projekte(la * RAD, lo * RAD);
  if (p.z > 0.05) { const b = m.ekrandan(p.x, p.y)!; assert.ok(Math.abs(b.lat - la * RAD) < 1e-6, "lat"); assert.ok(Math.abs(Math.atan2(Math.sin(b.lon - lo * RAD), Math.cos(b.lon - lo * RAD))) < 1e-6, "lon"); }
}
// Merkez noktası kamera merkezi
const c = m.ekrandan(0, 0)!; assert.ok(Math.abs(c.lat - m.lat) < 1e-9 && Math.abs(c.lon - m.lon) < 1e-9);
// Daire yarıçapı doğru
const pts = daireNoktalari(41, 29, 500, 48);
for (const p of pts) assert.ok(Math.abs(haversineKm(41, 29, p.lat / RAD, p.lon / RAD) - 500) < 1, "daire yarıçapı");
// Zoom
m.yakinlas(); for (let i = 0; i < 60; i++) m.adim(0.05); assert.ok(m.zoom > 1.3);
m.uzaklas(); m.uzaklas(); for (let i = 0; i < 80; i++) m.adim(0.05); assert.ok(m.zoom < 1);
// Odak
m.odaklan(41, 29, 2); for (let i = 0; i < 120; i++) m.adim(0.05);
assert.ok(Math.abs(m.lat - 41 * RAD) < 0.01 && Math.abs(m.lon - 29 * RAD) < 0.01, "odak");
// Senaryo zaman çizelgesi
const s = new Motor();
s.senaryoBaslat({ id: "t", ad: "t", tur: "meteor", lat: 39, lon: 32, parametreler: { cap: 300, hiz: 20, aci: 45, yogunluk: 3000 }, aciklama: "" });
assert.equal(s.evre, 0); assert.equal(s.halkalar().length, 0);
for (let i = 0; i < 50; i++) s.adim(0.1); // 5 sn
assert.equal(s.evre, 1); assert.ok(s.olaylar.includes("carpma"));
const h = s.halkalar(); assert.ok(h.length >= 1 && h[0].yaricapKm > 0);
for (let i = 0; i < 300; i++) s.adim(0.1);
assert.equal(s.evre, -1); assert.ok(s.olaylar.includes("bitti"));
// Jest -> motor
const j = new Motor(); const bild: string[] = [];
jestUygula(j, { tip: "it", yumruk: false }, (x) => bild.push(x)); assert.ok(j.hedefZoom > 1);
jestUygula(j, { tip: "cek", yumruk: false }, (x) => bild.push(x)); jestUygula(j, { tip: "cek", yumruk: false }, (x) => bild.push(x)); assert.ok(j.hedefZoom < 1.5);
jestUygula(j, { tip: "it", yumruk: true }, (x) => bild.push(x)); assert.ok(j.senaryo && j.senaryo.tur === "meteor");
const k = new Motor(); const lon0 = k.lon; jestUygula(k, { tip: "grab_basla" }); jestUygula(k, { tip: "surukle", dx: 0.1, dy: 0 }); assert.notEqual(k.lon, lon0);
jestUygula(k, { tip: "swipe", yon: "sag" }); assert.ok(k.velLon > 1);
console.log("ok motor");

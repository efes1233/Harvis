import assert from "node:assert/strict";
import { JestMotoru, IkiElZoom, pozSinifla, sentetikEl, pinchOrani } from "../../web/src/hands/gestures.ts";

assert.equal(pozSinifla(sentetikEl({ acik: [true, true, true, true] })), "open");
assert.equal(pozSinifla(sentetikEl({ acik: [false, false, false, false] })), "grab");
assert.equal(pozSinifla(sentetikEl({ acik: [true, false, false, false] })), "point");
assert.equal(pozSinifla(sentetikEl({ pinch: true })), "pinch");
assert.ok(pinchOrani(sentetikEl({ pinch: true })) < 0.3);

// Pinch başla/bitir
let g = new JestMotoru();
let ev = g.guncelle(sentetikEl({ pinch: true }), 0);
assert.ok(ev.some((e) => e.tip === "pinch_basla"));
ev = g.guncelle(sentetikEl({ acik: [true, true, true, true] }), 100);
assert.ok(ev.some((e) => e.tip === "pinch_bitir"));

// Grab + sürükleme
g = new JestMotoru();
g.guncelle(sentetikEl({ acik: [false, false, false, false], cx: 0.5 }), 0);
ev = g.guncelle(sentetikEl({ acik: [false, false, false, false], cx: 0.55 }), 50);
const s = ev.find((e) => e.tip === "surukle") as any;
assert.ok(s && s.dx > 0.04, "sürükleme dx");
ev = g.guncelle(sentetikEl({ acik: [true, true, true, true], cx: 0.55 }), 100);
assert.ok(ev.some((e) => e.tip === "grab_birak"));

// Swipe: açık el hızla sağa (ayna: görüntüde x artışı = kullanıcının solu)
g = new JestMotoru();
let sw: any = null;
for (let i = 0; i < 6; i++) { const r = g.guncelle(sentetikEl({ cx: 0.2 + i * 0.08 }), i * 50); sw ??= r.find((e) => e.tip === "swipe"); }
assert.ok(sw && sw.yon === "sol", "swipe yönü");
// Swipe sonrası bekleme süresi
assert.equal(g.guncelle(sentetikEl({ cx: 0.9 }), 300).filter((e) => e.tip === "swipe").length, 0);

// Push (açık el büyür)
g = new JestMotoru();
let it: any = null;
for (let i = 0; i < 6; i++) { const r = g.guncelle(sentetikEl({ olcek: 0.12 + i * 0.03 }), i * 60); it ??= r.find((e) => e.tip === "it"); }
assert.ok(it && it.yumruk === false, "it olayı");
// Pull
g = new JestMotoru(); let cek: any = null;
for (let i = 0; i < 6; i++) { const r = g.guncelle(sentetikEl({ olcek: 0.3 - i * 0.03 }), i * 60); cek ??= r.find((e) => e.tip === "cek"); }
assert.ok(cek, "çek olayı");

// El kaybolunca bırak
g = new JestMotoru(); g.guncelle(sentetikEl({ pinch: true }), 0);
assert.ok(g.guncelle(null, 50).some((e) => e.tip === "pinch_bitir"));

// İki el zoom
const z = new IkiElZoom();
z.guncelle(sentetikEl({ pinch: true, cx: 0.3 }), sentetikEl({ pinch: true, cx: 0.7 }));
const zo = z.guncelle(sentetikEl({ pinch: true, cx: 0.2 }), sentetikEl({ pinch: true, cx: 0.8 })) as any;
assert.ok(zo && zo.oran > 1.2, "iki el zoom oranı");
console.log("ok gestures");

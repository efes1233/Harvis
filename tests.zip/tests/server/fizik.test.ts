import assert from "node:assert/strict";
import * as F from "../../shared/fizik.ts";
const yak = (a: number, b: number, tol = 0.02) => assert.ok(Math.abs(a - b) / Math.abs(b) < tol, `${a} ≈ ${b}`);

const E = F.meteorKinetikEnerji(100, 20, 3000);           // 100 m, 20 km/s
yak(E, 0.5 * 3000 * (Math.PI / 6) * 1e6 * 4e8, 1e-9);
yak(F.jouleToMegaton(E), 75.0, 0.01);                      // ~75 Mt
yak(F.depremEnerji(9), 10 ** 18.3, 1e-9);
yak(F.kirilmaUzunlukKm(7.5), 10 ** (0.59 * 7.5 - 2.44), 1e-9);
yak(F.tsunamiHiz(4000), Math.sqrt(9.81 * 4000));            // ~198 m/s
yak(F.tsunamiSureSaat(3000, 4000), 3000e3 / 198.1 / 3600, 0.01);
yak(F.asiriBasincYaricapKm(1, 1), 11, 0.01);               // 1 Mt, 1 psi ≈ 11 km
yak(F.asiriBasincYaricapKm(1, 5), 4.7, 0.01);
yak(F.haversineKm(41.01, 28.98, 39.93, 32.86), 349, 0.03); // İstanbul-Ankara ≈ 350 km
assert.equal(F.haversineKm(10, 20, 10, 20), 0);
const k = F.krater(1000, 20, 45); assert.ok(k.final > 10000 && k.final < 40000, "1 km cisim → onlarca km krater: " + k.final);
assert.ok(F.krater(100, 20, 90).final > F.krater(100, 20, 20).final, "dik çarpma daha büyük krater");
assert.ok(F.sismikBuyukluk(E) > 5 && F.sismikBuyukluk(E) < 7);
for (const t of ["meteor", "deprem", "tsunami", "gunes", "volkan"]) {
  const e = F.senaryoEtkisi(t, { cap: 100, hiz: 20, mw: 8, derinlik: 4000, mesafe: 1000, sinif: 4, sayi: 3, vei: 5 });
  assert.ok(e.enerjiJoule > 0 && e.satirlar.length > 0, t);
}
assert.throws(() => F.senaryoEtkisi("yok", {}));
console.log("ok fizik");

import assert from "node:assert/strict";
import { sunucuOlustur } from "../../server/src/index.ts";

const srv = sunucuOlustur();
await new Promise<void>((r) => srv.listen(0, r));
const port = (srv.address() as any).port, T = `http://127.0.0.1:${port}`;
try {
  const d = await (await fetch(T + "/api/durum")).json() as any; assert.equal(d.ad, "JARVIS"); assert.ok(d.araclar >= 200); assert.ok(d.senaryolar >= 100);
  const a = await (await fetch(T + "/api/araclar")).json() as any[]; assert.ok(a.length >= 200);
  const s = await (await fetch(T + "/api/senaryolar")).json() as any[]; assert.ok(s.length >= 100);
  const k = await (await fetch(T + "/api/komut", { method: "POST", body: JSON.stringify({ metin: "Ankara'ya meteor çarpması başlat" }) })).json() as any;
  assert.equal(k.niyet, "senaryo_baslat");
  assert.equal((await fetch(T + "/api/komut", { method: "POST", body: "{}" })).status, 400);
  const tt = await (await fetch(T + "/api/tts", { method: "POST", body: JSON.stringify({ metin: "x" }) })).json() as any; assert.equal(tt.motor, "tarayici");
  const html = await fetch(T + "/"); assert.equal(html.status, 200); assert.ok((await html.text()).includes("JARVIS"));
  const js = await fetch(T + "/app.js"); assert.equal(js.status, 200); assert.ok((await js.text()).length > 100000);
  const png = await fetch(T + "/assets/textures/dunya_4k.png"); assert.equal(png.status, 200); assert.equal(png.headers.get("content-type"), "image/png");
  const wav = await fetch(T + "/assets/sounds/baslangic.wav"); assert.equal(wav.headers.get("content-type"), "audio/wav");
  assert.equal((await fetch(T + "/assets/../package.json")).status === 200, false, "dizin dışına çıkış engellenmeli");
  assert.equal((await fetch(T + "/%2e%2e/package.json")).status === 200, false);
  const fr = await fetch(T + "/api/film", { method: "POST", body: JSON.stringify({ istek: "Ankara meteor senaryosu", sure: 30 }) }).then((r) => r.json()) as any;
  assert.equal(fr.yerel, true); assert.ok(fr.film.olaylar.length > 10);
  assert.equal((await fetch(T + "/api/film", { method: "POST", body: "{}" })).status, 400);
  const fk = await (await fetch(T + "/api/komut", { method: "POST", body: JSON.stringify({ metin: "1 dakikalık İzmir deprem senaryosu yaz" }) })).json() as any;
  assert.equal(fk.niyet, "film_uret"); assert.equal(fk.eylemler[0].tip, "film"); assert.equal(fk.eylemler[0].film.sure, 60);
  process.env.JARVIS_ERISIM_ANAHTARI = "gizli";
  assert.equal((await fetch(T + "/api/komut", { method: "POST", body: JSON.stringify({ metin: "yaklaş" }) })).status, 401);
  assert.equal((await fetch(T + "/api/komut", { method: "POST", headers: { "x-jarvis-key": "gizli" }, body: JSON.stringify({ metin: "yaklaş" }) })).status, 200);
  delete process.env.JARVIS_ERISIM_ANAHTARI;
  assert.ok(Array.isArray(((await (await fetch(T + "/api/durum")).json()) as any).beyinler));
  assert.equal((await fetch(T + "/yok.txt")).status, 404);
} finally { srv.close(); }
console.log("ok http");

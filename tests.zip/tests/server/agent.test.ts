import assert from "node:assert/strict";
import { ajanIsle } from "../../server/src/agent.ts";

let r = await ajanIsle("İstanbul'a meteor çarpması simülasyonu başlat");
assert.equal(r.niyet, "senaryo_baslat");
const e = r.eylemler[0] as any;
assert.equal(e.tip, "senaryo"); assert.ok(Math.abs(e.senaryo.lat - 41.01) < 0.01); assert.ok(e.etki.megaton > 0);
assert.ok(r.yanit.includes("Simülasyon"));

r = await ajanIsle("Tokyo'da 8.2 büyüklüğünde deprem başlat");
assert.equal((r.eylemler[0] as any).senaryo.parametreler.mw, 8.2);

r = await ajanIsle("yaklaş"); assert.deepEqual(r.eylemler, [{ tip: "dunya", komut: "yakinlas" }]);
r = await ajanIsle("Berlin'i göster"); assert.equal((r.eylemler[0] as any).tip, "odak");
r = await ajanIsle("kırmızı mod"); assert.deepEqual(r.eylemler, [{ tip: "tema", tema: "kirmizi" }]);
r = await ajanIsle("kamerayı aç"); assert.deepEqual(r.eylemler, [{ tip: "kamera", ac: true }]);
r = await ajanIsle("12 çarpı 12 hesapla"); assert.ok(r.yanit.includes("144"), r.yanit);
r = await ajanIsle("100 celsius kaç fahrenhayt"); assert.ok(r.yanit.includes("212"), r.yanit);
r = await ajanIsle("merhaba"); assert.ok(r.yanit.includes("efendim"));
delete process.env.ANTHROPIC_API_KEY;
r = await ajanIsle("qwerty asdf"); assert.equal(r.niyet, "bilinmiyor");
console.log("ok agent");

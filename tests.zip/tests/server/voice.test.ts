import assert from "node:assert/strict";
import { sttCoz } from "../../server/src/stt.ts";
import { tts } from "../../server/src/tts.ts";
import { elevenHazirMi, elevenSentez, istekGovdesi, VARSAYILAN } from "../../server/src/eleven.ts";
import { main as elevenCli } from "../../server/src/eleven-cli.ts";

delete process.env.ELEVEN_API_KEY; delete process.env.OPENAI_API_KEY;
assert.equal(elevenHazirMi(), false);
assert.deepEqual(await sttCoz({ metin: "  merhaba  " }), { ok: true, metin: "merhaba", kaynak: "tarayici" });
const s = await sttCoz({ sesBase64: "AAAA" }); assert.equal(s.ok, false); assert.ok(s.hata?.includes("OPENAI_API_KEY"));
assert.equal((await sttCoz({})).ok, false);
const t = await tts("Merhaba"); assert.deepEqual(t, { motor: "tarayici", metin: "Merhaba" });
const e = await elevenSentez("x"); assert.equal(e.ok, false);
const g = istekGovdesi("Selam"); assert.equal(g.text, "Selam"); assert.equal(g.model_id, VARSAYILAN.model); assert.ok(g.voice_settings.stability > 0);
assert.equal(await elevenCli([]), 1);
assert.equal(await elevenCli(["Merhaba"]), 2);

// Anahtar varsa istek doğru biçimde gider (sahte fetch ile)
process.env.ELEVEN_API_KEY = "test-key";
const gercek = globalThis.fetch; let yakalanan: any = null;
globalThis.fetch = (async (u: any, o: any) => { yakalanan = { u: String(u), o }; return new Response(new Uint8Array([1, 2, 3]), { status: 200 }); }) as any;
const ok = await elevenSentez("Merhaba"); assert.equal(ok.ok, true);
assert.ok(yakalanan.u.includes("/v1/text-to-speech/")); assert.equal(yakalanan.o.headers["xi-api-key"], "test-key");
const tt = await tts("Merhaba"); assert.equal(tt.motor, "eleven");
globalThis.fetch = gercek; delete process.env.ELEVEN_API_KEY;
console.log("ok voice");

import assert from "node:assert/strict";
import { HizSiniri, anahtarGecerli, istemciIp } from "../../server/src/guvenlik.ts";

const h = new HizSiniri(3, 1000);
assert.ok(h.dene("a", 0) && h.dene("a", 10) && h.dene("a", 20)); assert.equal(h.dene("a", 30), false);
assert.ok(h.dene("b", 30), "başka istemci etkilenmez"); assert.ok(h.dene("a", 1100), "pencere geçince yeniden izin");
const req = (headers: any, ip = "1.2.3.4") => ({ headers, socket: { remoteAddress: ip } }) as any;
assert.equal(istemciIp(req({ "x-forwarded-for": "9.9.9.9, 10.0.0.1" })), "9.9.9.9"); assert.equal(istemciIp(req({})), "1.2.3.4");
assert.equal(anahtarGecerli(req({}), undefined), true, "anahtar tanımsızsa serbest");
assert.equal(anahtarGecerli(req({ "x-jarvis-key": "gizli" }), "gizli"), true);
assert.equal(anahtarGecerli(req({ "x-jarvis-key": "yanlis" }), "gizli"), false); assert.equal(anahtarGecerli(req({}), "gizli"), false); assert.equal(anahtarGecerli(req({ "x-jarvis-key": "gizlii" }), "gizli"), false);
console.log("ok guvenlik");

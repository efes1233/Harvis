import assert from "node:assert/strict";
import { TUM_SAGLAYICILAR, hazirSaglayicilar, groq, mistral, openrouter, gemini, anthropic, openai, grok, ollama, github, cerebras, nvidia } from "../../server/src/saglayicilar/index.ts";
import { sogumaBaslat, sogumaTemizle, SaglayiciHatasi, hataIsle } from "../../server/src/saglayicilar/tur.ts";
import { envCoz } from "../../server/src/ortam.ts";

const gercek = globalThis.fetch; let son: any = null;
function sahte(govde: unknown, durum = 200) { globalThis.fetch = (async (u: any, o: any) => { son = { u: String(u), o, b: JSON.parse(o.body) }; return new Response(JSON.stringify(govde), { status: durum }); }) as any; }
for (const k of ["GROQ_API_KEY", "MISTRAL_API_KEY", "OPENROUTER_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "XAI_API_KEY", "GITHUB_MODELS_TOKEN", "CEREBRAS_API_KEY", "NVIDIA_API_KEY", "OLLAMA_MODEL", "JARVIS_BEYINLER", "JARVIS_SADECE_UCRETSIZ"]) delete process.env[k];
assert.equal(hazirSaglayicilar().length, 0);

// OpenAI uyumlu ailesi
const oa = { choices: [{ message: { content: "{\"ok\":1}" } }] };
for (const [s, env, url] of [[groq, "GROQ_API_KEY", "api.groq.com"], [mistral, "MISTRAL_API_KEY", "api.mistral.ai"], [openrouter, "OPENROUTER_API_KEY", "openrouter.ai"], [openai, "OPENAI_API_KEY", "api.openai.com"], [grok, "XAI_API_KEY", "api.x.ai"], [github, "GITHUB_MODELS_TOKEN", "models.github.ai"], [cerebras, "CEREBRAS_API_KEY", "api.cerebras.ai"], [nvidia, "NVIDIA_API_KEY", "integrate.api.nvidia.com"]] as const) {
  assert.equal(s.hazir(), false);
  process.env[env] = "k-" + s.ad; assert.equal(s.hazir(), true);
  sahte(oa);
  const y = await s.sor({ sistem: "S", kullanici: "K", json: true });
  assert.equal(y, "{\"ok\":1}"); assert.ok(son.u.includes(url), s.ad + " url"); assert.equal(son.o.headers.authorization, "Bearer k-" + s.ad);
  assert.equal(son.b.messages[0].role, "system"); assert.equal(son.b.messages[1].content, "K"); assert.ok(son.b.model);
  delete process.env[env];
}
assert.equal(groq.ucretsiz, true); assert.equal(openai.ucretsiz, false); assert.equal(grok.ucretsiz, false);
assert.ok(openrouter.model().endsWith(":free"), "openrouter varsayılanı ücretsiz model");

// Gemini
process.env.GEMINI_API_KEY = "g"; sahte({ candidates: [{ content: { parts: [{ text: "merhaba" }, { text: " dünya" }] } }] });
assert.equal(await gemini.sor({ sistem: "S", kullanici: "K", json: true }), "merhaba dünya");
assert.ok(son.u.includes("generateContent")); assert.equal(son.o.headers["x-goog-api-key"], "g"); assert.equal(son.b.generationConfig.responseMimeType, "application/json"); assert.equal(son.b.systemInstruction.parts[0].text, "S");
// Anthropic
process.env.ANTHROPIC_API_KEY = "a"; sahte({ content: [{ type: "text", text: "selam" }] });
assert.equal(await anthropic.sor({ sistem: "S", kullanici: "K" }), "selam"); assert.equal(son.o.headers["x-api-key"], "a"); assert.equal(son.b.system, "S");
// Ollama: anahtarsız, yerel
assert.equal(ollama.hazir(), false); process.env.OLLAMA_MODEL = "llama3.2"; assert.equal(ollama.hazir(), true);
sahte({ message: { content: "yerel" } }); assert.equal(await ollama.sor({ sistem: "S", kullanici: "K", json: true }), "yerel"); assert.ok(son.u.includes("localhost:11434/api/chat")); assert.equal(son.b.format, "json");
// Hata
sahte({}, 429); await assert.rejects(() => gemini.sor({ sistem: "S", kullanici: "K" }), /gemini HTTP 429/);

// Filtreler
process.env.GROQ_API_KEY = "x"; process.env.OPENAI_API_KEY = "x"; process.env.XAI_API_KEY = "x"; process.env.MISTRAL_API_KEY = "x";
const ad = (e: Record<string, string> = {}) => hazirSaglayicilar(TUM_SAGLAYICILAR, e).map((s) => s.ad);
assert.deepEqual(ad(), ["gemini", "groq", "mistral", "ollama", "grok", "openai", "anthropic"].filter((x) => ad().includes(x)));
assert.equal(ad()[0], "gemini", "ücretsizler önce");
assert.deepEqual(ad({ JARVIS_SADECE_UCRETSIZ: "1" }).filter((x) => ["grok", "openai", "anthropic"].includes(x)), []);
assert.deepEqual(ad({ JARVIS_BEYINLER: "groq,openai" }), ["groq", "openai"]);
assert.equal(ad({ JARVIS_MAKS_BEYIN: "2" }).length, 2);
// 429 soğuma
sogumaTemizle(); hataIsle("groq", new SaglayiciHatasi("groq", 429)); assert.ok(!ad().includes("groq"), "429 sonrası dinlenmeli");
sogumaTemizle(); hataIsle("groq", new SaglayiciHatasi("groq", 500)); assert.ok(ad().includes("groq"), "500 soğutmaz");
sogumaBaslat("mistral", 10, Date.now() - 100); assert.ok(ad().includes("mistral"), "soğuma süresi dolunca geri gelir");

// .env ayrıştırma
assert.deepEqual(envCoz('# yorum\nA=1\nexport B="iki ü"\nC=\'3\'\n  D = 4 \nBOZUK\n'), { A: "1", B: "iki ü", C: "3", D: "4" });
globalThis.fetch = gercek; console.log("ok saglayici");

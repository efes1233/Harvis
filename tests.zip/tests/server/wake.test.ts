import assert from "node:assert/strict";
import { uyanmaKelimesiVarMi, uyanmaSonrasi, UyanmaDinleyici, lev } from "../../server/src/wake.ts";

assert.equal(uyanmaKelimesiVarMi("Jarvis, saat kaç?"), true);
assert.equal(uyanmaKelimesiVarMi("hey jarvis"), true);
assert.equal(uyanmaKelimesiVarMi("carvis yaklaş"), true);
assert.equal(uyanmaKelimesiVarMi("merhaba dünya"), false);
assert.equal(uyanmaSonrasi("Jarvis İstanbul'a meteor çarpması başlat"), "istanbul'a meteor çarpması başlat");
assert.equal(uyanmaSonrasi("jarvis"), "");
assert.equal(uyanmaSonrasi("selam"), null);
assert.equal(lev("jarvis", "jarvis"), 0); assert.equal(lev("jarvis", "garvis"), 1);

const d = new UyanmaDinleyici(5000);
assert.deepEqual(d.isle("bir şey söyledim", 0), { aktif: false, komut: null });
assert.deepEqual(d.isle("jarvis", 1000), { aktif: true, komut: null });
assert.deepEqual(d.isle("yaklaş", 3000), { aktif: true, komut: "yaklaş" });  // pencere içinde, uyanma kelimesi gerekmez
assert.deepEqual(d.isle("tekrar", 20000), { aktif: false, komut: null });    // pencere doldu
console.log("ok wake");

import assert from "node:assert/strict";
import { niyetCoz, sehirBul } from "../../server/src/beyin.ts";

const dava: [string, string, Record<string, string>?][] = [
  ["İstanbul'a meteor çarpması simülasyonu başlat", "senaryo_baslat", { tur: "meteor", sehir: "İstanbul" }],
  ["Dünyaya şuradan meteor çarpma simülasyonu başlat", "senaryo_baslat", { tur: "meteor" }],
  ["Tokyo'da 7.8 büyüklüğünde deprem başlat", "senaryo_baslat", { tur: "deprem", sehir: "Tokyo", mw: "7.8" }],
  ["Ankara'ya 500 metre asteroit düşür", "senaryo_baslat", { tur: "meteor", sehir: "Ankara", cap: "500" }],
  ["güneş patlaması başlat", "senaryo_baslat", { tur: "gunes" }],
  ["tsunami simülasyonu", "senaryo_baslat", { tur: "tsunami" }],
  ["yaklaş", "dunya_yakinlas"], ["biraz uzaklaş", "dunya_uzaklas"], ["dünyayı döndür", "dunya_dondur"], ["sıfırla", "dunya_sifirla"],
  ["Londra'yı göster", "sehre_odaklan", { sehir: "Londra" }],
  ["kamerayı aç", "kamera_ac"], ["el takibini kapat", "kamera_kapat"], ["kırmızı mod", "hud_tema", { tema: "kirmizi" }], ["mavi tema", "hud_tema", { tema: "mavi" }],
  ["merhaba jarvis", "selam"], ["teşekkürler", "tesekkur"],
  ["12 çarpı 12 hesapla", "arac"], ["10 km kaç mil", "arac"],
  ["xyzzy qwerty", "bilinmiyor"],
];
for (const [girdi, ad, v] of dava) {
  const n = niyetCoz(girdi);
  assert.equal(n.ad, ad, `"${girdi}" -> ${n.ad}`);
  for (const [k, val] of Object.entries(v ?? {})) assert.equal(n.varliklar[k], val, `"${girdi}" varlık ${k}: ${n.varliklar[k]}`);
}
assert.equal(sehirBul("istanbul")?.ad, "İstanbul");
assert.equal(sehirBul("sao paulo")?.ad, undefined); // aksanlı ad ASCII ile eşleşmez → bilinçli sınır
console.log("ok beyin");

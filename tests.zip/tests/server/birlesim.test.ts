import assert from "node:assert/strict";
import { filmUret, birlestir, yerelFilm, sistemPromptu } from "../../server/src/birlesim.ts";
import { sohbet } from "../../server/src/sohbet.ts";
import { filmDogrula, jsonCikar } from "../../shared/film.ts";
import type { Saglayici } from "../../server/src/saglayicilar/index.ts";

const sahteS = (ad: string, cevap: (o: any) => Promise<string> | string): Saglayici => ({ ad, ucretsiz: true, model: () => "m", hazir: () => true, sor: async (o) => cevap(o) });
const film = (ek: any[]) => JSON.stringify({ baslik: "Test", olaylar: ek });
const yazarJson = film([{ t: 1, tip: "anlat", metin: "Başlıyoruz." }, { t: 8, tip: "anlat", metin: "Çarpma!" }, { t: 20, tip: "anlat", metin: "Bitti." }, { t: 8, tip: "senaryo", tur: "meteor", lat: 41, lon: 29, parametreler: { cap: 300, hiz: 20 } }]);
const yonetmenJson = "Tabii! ```json\n" + film([{ t: 0, tip: "kamera", lat: 10, lon: 20, zoom: 1 }, { t: 6, tip: "kamera", lat: 41, lon: 29, zoom: 2.5 }, { t: 9, tip: "efekt", ad: "sarsinti", siddet: 1.2 }, { t: 9.5, tip: "efekt", ad: "sarsinti", siddet: 1.9 }, { t: 8.5, tip: "senaryo", tur: "meteor", lat: 42, lon: 30, parametreler: { cap: 500, hiz: 24 } }]) + "\n``` umarım beğenirsin";
const fizikciJson = film([{ t: 9, tip: "senaryo", tur: "meteor", lat: 41.5, lon: 29.5, parametreler: { cap: 400, hiz: 22, aci: 45 } }, { t: 3, tip: "anlat", metin: "Tek cümle." }]);

// Şema/JSON yardımcıları
assert.deepEqual(jsonCikar('{"a":1}'), { a: 1 }); assert.deepEqual(jsonCikar("önsöz {\"a\":2} sonsöz"), { a: 2 }); assert.equal(jsonCikar("json yok"), null);
const f = filmDogrula({ baslik: "x", olaylar: [{ t: 999, tip: "efekt", ad: "sarsinti", siddet: 50 }, { t: 1, tip: "senaryo", tur: "meteor", lat: 500, lon: 0, parametreler: { cap: 1e9, uydurma: 5 } }, { t: 2, tip: "yok" }, { tip: "anlat", metin: "t yok" }] }, 30, "k")!;
assert.equal(f.olaylar.length, 2); assert.equal(f.olaylar[1].t, 30); assert.equal((f.olaylar[1] as any).siddet, 2);
const sn = f.olaylar[0] as any; assert.equal(sn.lat, 85); assert.equal(sn.parametreler.cap, 20000); assert.equal("uydurma" in sn.parametreler, false);
assert.equal(filmDogrula({ olaylar: [] }, 30), null); assert.equal(filmDogrula(null, 30), null);

// Üç sağlayıcı birleşir
const r = await filmUret("İstanbul meteor", { sure: 30, uretimMs: 2000, saglayicilar: [sahteS("A", () => yazarJson), sahteS("B", () => yonetmenJson), sahteS("C", () => fizikciJson)] });
assert.equal(r.yerel, false); assert.deepEqual([...r.kaynaklar].sort(), ["A", "B", "C"]);
const ol = r.film.olaylar; assert.ok(ol.every((o, i) => i === 0 || ol[i - 1].t <= o.t), "zaman sıralı");
assert.equal(ol.filter((o) => o.tip === "anlat").length, 3, "anlatım en çok anlat üreten yazardan");
assert.equal(ol.filter((o) => o.tip === "kamera").length, 2, "kamera yönetmenden");
const sen = ol.filter((o) => o.tip === "senaryo"); assert.equal(sen.length, 1, "yakın senaryolar tek olayda kümelenir");
assert.equal((sen[0] as any).parametreler.cap, 400, "cap medyanı (300,500,400)"); assert.equal((sen[0] as any).parametreler.hiz, 22);
const sars = ol.filter((o) => o.tip === "efekt"); assert.equal(sars.length, 1); assert.equal((sars[0] as any).siddet, 1.9, "aynı efekt tekilleşir, güçlü kalır");
assert.equal(r.film.baslik, "Test");

// Roller promptta
assert.ok(sistemPromptu(30, "YAZAR").includes("YAZAR")); assert.ok(sistemPromptu(60, "FIZIKCI").includes("60 saniyelik"));
let alinan = ""; await filmUret("x", { saglayicilar: [sahteS("A", (o) => { alinan = o.sistem; return yazarJson; })], uretimMs: 1000 }); assert.ok(alinan.includes("YAZAR"));

// Yavaş + bozuk + hata veren sağlayıcılar: süre dolunca elde olanla devam
const t0 = Date.now();
const r2 = await filmUret("x", { sure: 30, uretimMs: 300, saglayicilar: [
  sahteS("hizli", () => yazarJson),
  sahteS("yavas", () => new Promise<string>((res) => setTimeout(() => res(yonetmenJson), 5000))),
  sahteS("bozuk", () => "bu JSON değil"),
  sahteS("patlar", () => { throw new Error("HTTP 500"); }),
] });
assert.ok(Date.now() - t0 < 1500, "süre sınırına uyulmalı: " + (Date.now() - t0));
assert.deepEqual(r2.kaynaklar, ["hizli"]); assert.equal(r2.hatalar.yavas, "süre doldu"); assert.ok(r2.hatalar.bozuk.includes("geçersiz")); assert.ok(r2.hatalar.patlar.includes("500")); assert.equal(r2.yerel, false);

// Hiç sağlayıcı yok / hepsi başarısız → yerel yazar
const r3 = await filmUret("Tokyo'da 8 büyüklüğünde deprem senaryosu", { sure: 60, saglayicilar: [] });
assert.equal(r3.yerel, true); assert.equal(r3.film.sure, 60); assert.ok(r3.film.olaylar.some((o) => o.tip === "senaryo" && o.tur === "deprem")); assert.ok(r3.film.olaylar.every((o) => o.t <= 60));
const yf = yerelFilm("güneş patlaması", 30); assert.ok(filmDogrula(yf, 30), "yerel film şemaya uyar");
for (const tur of ["meteor", "deprem", "tsunami", "gunes", "volkan"]) assert.ok(filmDogrula(yerelFilm(tur + " senaryo yaz", 30), 30), tur);

// Sohbet: hızlı mod en çabuk cevabı alır; birleştir modu sentezler
const s1 = await sohbet("selam", { saglayicilar: [sahteS("yavas", () => new Promise((r) => setTimeout(() => r("geç"), 800))), sahteS("hizli", () => "merhaba")], mod: "hizli" });
assert.deepEqual(s1, { yanit: "merhaba", kaynak: "hizli" });
const s2 = await sohbet("selam", { saglayicilar: [sahteS("a", (o) => (o.sistem.includes("birleştir") ? "SENTEZ" : "bir")), sahteS("b", () => "iki")], mod: "birlestir" });
assert.equal(s2?.yanit, "SENTEZ"); assert.equal(s2?.kaynak, "a+b");
assert.equal(await sohbet("x", { saglayicilar: [] }), null);
assert.equal(await sohbet("x", { saglayicilar: [sahteS("h", () => { throw new Error("x"); })] }), null);
console.log("ok birlesim");

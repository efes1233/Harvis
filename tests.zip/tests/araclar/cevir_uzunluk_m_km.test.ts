import assert from "node:assert/strict";
import arac from "../../server/src/araclar/cevir_uzunluk_m_km.ts";
const r = await arac.calistir(arac.ornek.girdi, {});
assert.equal(r.ok, true, "ok olmalı: " + r.metin);
assert.ok(r.metin.includes(arac.ornek.beklenen), `beklenen "${arac.ornek.beklenen}" sonuçta yok: ${r.metin}`);
console.log("ok cevir_uzunluk_m_km");

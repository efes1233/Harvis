import assert from "node:assert/strict";
import { readFileSync, statSync, readdirSync } from "node:fs";
const R = (p: string) => new URL("../../assets/" + p, import.meta.url);

// PNG: imza + IHDR boyutları
for (const [ad, w, h] of [["dunya_4k.png", 4096, 2048], ["dunya_gece_4k.png", 4096, 2048], ["bulutlar_2k.png", 2048, 1024]] as const) {
  const b = readFileSync(R("textures/" + ad));
  assert.deepEqual([...b.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10], ad + " PNG imzası");
  assert.equal(b.readUInt32BE(16), w, ad + " genişlik"); assert.equal(b.readUInt32BE(20), h, ad + " yükseklik");
  assert.ok(b.length > 500_000, ad + " boyut");
}
// WAV: RIFF başlığı, süre
const sesler: Record<string, number> = { baslangic: 3, bip: 0.15, uyanma: 0.6, pinch: 0.4, meteor_carpma: 4, hud_ambient: 8, tarama: 2 };
for (const [ad, sure] of Object.entries(sesler)) {
  const b = readFileSync(R(`sounds/${ad}.wav`));
  assert.equal(b.toString("ascii", 0, 4), "RIFF"); assert.equal(b.toString("ascii", 8, 12), "WAVE");
  assert.equal(b.readUInt32LE(24), 44100, "örnekleme hızı"); assert.equal(b.readUInt16LE(34), 16, "bit");
  const veri = b.length - 44; assert.ok(Math.abs(veri / 2 / 44100 - sure) < 0.01, `${ad} süre`);
  let tepe = 0; for (let i = 44; i < b.length; i += 2) tepe = Math.max(tepe, Math.abs(b.readInt16LE(i))); assert.ok(tepe > 3000, ad + " sessiz olmamalı");
}
// JSON veri
const sehirler = JSON.parse(readFileSync(R("data/sehirler.json"), "utf-8")); assert.equal(sehirler.length, 30);
const y = JSON.parse(readFileSync(R("data/yildizlar.json"), "utf-8")); assert.equal(y.length, 60000);
assert.ok(y.every((s: any) => s.ra >= 0 && s.ra <= 360 && s.dec >= -90 && s.dec <= 90));
assert.ok(readdirSync(R("senaryolar")).length >= 100);
console.log("ok varliklar");

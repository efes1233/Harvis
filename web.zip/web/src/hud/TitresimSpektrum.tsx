import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "TİTREŞİM";
export default function TitresimSpektrum(p: Ortak) {
  return <Spektrum etiket="TİTREŞİM" seed={306} renk={p.renk} />;
}

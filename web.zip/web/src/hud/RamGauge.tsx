import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "RAM";
export default function RamGauge(p: Ortak) {
  return <Gauge etiket="RAM" birim="%" deger={p.deger ?? 76} renk={p.renk ?? "#7df9ff"} />;
}

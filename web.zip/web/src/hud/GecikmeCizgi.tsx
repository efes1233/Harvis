import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "GECİKME";
export default function GecikmeCizgi(p: Ortak) {
  return <Cizgi etiket="GECİKME" seed={423} renk={p.renk} />;
}

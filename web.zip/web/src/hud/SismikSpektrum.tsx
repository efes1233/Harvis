import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "SİSMİK";
export default function SismikSpektrum(p: Ortak) {
  return <Spektrum etiket="SİSMİK" seed={345} renk={p.renk} />;
}

import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "BASINÇ";
export default function BasincGauge(p: Ortak) {
  return <Gauge etiket="BASINÇ" birim="%" deger={p.deger ?? 47} renk={p.renk ?? "#90e0ef"} />;
}

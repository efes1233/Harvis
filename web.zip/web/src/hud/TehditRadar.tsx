import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "TEHDİT";
export default function TehditRadar(p: Ortak) {
  return <Radar etiket="TEHDİT" seed={241} renk={p.renk} />;
}

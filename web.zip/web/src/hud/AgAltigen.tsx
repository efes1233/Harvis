import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "AĞ";
export default function AgAltigen(p: Ortak) {
  return <Altigen etiket="AĞ" seed={579} renk={p.renk} />;
}

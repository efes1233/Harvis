import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "REAKTÖR";
export default function ReaktorHalka(p: Ortak) {
  return <Halka etiket="REAKTÖR" seed={670} renk={p.renk} />;
}

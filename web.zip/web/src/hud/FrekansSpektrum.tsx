import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "FREKANS";
export default function FrekansSpektrum(p: Ortak) {
  return <Spektrum etiket="FREKANS" seed={384} renk={p.renk} />;
}

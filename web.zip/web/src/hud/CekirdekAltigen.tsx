import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ÇEKİRDEK";
export default function CekirdekAltigen(p: Ortak) {
  return <Altigen etiket="ÇEKİRDEK" seed={605} renk={p.renk} />;
}

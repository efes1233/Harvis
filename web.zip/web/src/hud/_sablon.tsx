import React from "react";

// Deterministik sahte-rastgele (SSR ve testlerde aynı çıktı)
export function tohum(seed: number) { let s = seed >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
export type Ortak = { renk?: string; deger?: number };

export function Gauge({ etiket, birim, deger = 60, renk = "#00e5ff" }: { etiket: string; birim: string } & Ortak) {
  const d = Math.max(0, Math.min(100, deger)), r = 42, c = 2 * Math.PI * r * 0.75;
  return (
    <svg viewBox="0 0 120 120" className="w-gauge" role="img" aria-label={`${etiket} ${d}${birim}`}>
      <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="8" strokeDasharray={`${c} 999`} transform="rotate(135 60 60)" strokeLinecap="round" />
      <circle cx="60" cy="60" r={r} fill="none" stroke={renk} strokeWidth="8" strokeDasharray={`${(c * d) / 100} 999`} transform="rotate(135 60 60)" strokeLinecap="round" />
      <text x="60" y="64" textAnchor="middle" fill={renk} fontSize="20">{Math.round(d)}{birim}</text>
      <text x="60" y="108" textAnchor="middle" fill="#8fdcff" fontSize="10">{etiket}</text>
    </svg>
  );
}
export function Radar({ etiket, seed = 1, renk = "#00e5ff" }: { etiket: string; seed?: number } & Ortak) {
  const r = tohum(seed);
  const noktalar = Array.from({ length: 7 }, () => ({ a: r() * 6.283, d: 12 + r() * 40 }));
  return (
    <svg viewBox="0 0 120 120" className="w-radar" role="img" aria-label={etiket}>
      {[15, 30, 45].map((q) => <circle key={q} cx="60" cy="60" r={q} fill="none" stroke={renk} strokeOpacity=".3" />)}
      <line x1="60" y1="10" x2="60" y2="110" stroke={renk} strokeOpacity=".2" /><line x1="10" y1="60" x2="110" y2="60" stroke={renk} strokeOpacity=".2" />
      <g className="w-sweep"><path d="M60 60 L60 15 A45 45 0 0 1 95 32 Z" fill={renk} fillOpacity=".25" /></g>
      {noktalar.map((n, i) => <circle key={i} cx={60 + Math.cos(n.a) * n.d} cy={60 + Math.sin(n.a) * n.d} r="2" fill="#ffd166" />)}
      <text x="60" y="118" textAnchor="middle" fill="#8fdcff" fontSize="9">{etiket}</text>
    </svg>
  );
}
export function Spektrum({ etiket, seed = 1, renk = "#00e5ff" }: { etiket: string; seed?: number } & Ortak) {
  const r = tohum(seed), n = 24;
  return (
    <svg viewBox="0 0 120 80" className="w-spektrum" role="img" aria-label={etiket}>
      {Array.from({ length: n }, (_, i) => { const h = 6 + r() * 52; return <rect key={i} x={4 + i * 4.8} y={64 - h} width="3.2" height={h} fill={renk} fillOpacity={0.4 + (h / 58) * 0.6} />; })}
      <text x="60" y="77" textAnchor="middle" fill="#8fdcff" fontSize="9">{etiket}</text>
    </svg>
  );
}
export function Cizgi({ etiket, seed = 1, renk = "#00e5ff" }: { etiket: string; seed?: number } & Ortak) {
  const r = tohum(seed); let y = 40; const pts = Array.from({ length: 30 }, (_, i) => { y = Math.max(8, Math.min(62, y + (r() - 0.5) * 18)); return `${4 + i * 3.9},${y.toFixed(1)}`; });
  return (
    <svg viewBox="0 0 120 80" className="w-cizgi" role="img" aria-label={etiket}>
      <polyline points={pts.join(" ")} fill="none" stroke={renk} strokeWidth="1.6" />
      <polyline points={`4,70 ${pts.join(" ")} 116,70`} fill={renk} fillOpacity=".12" stroke="none" />
      <text x="60" y="77" textAnchor="middle" fill="#8fdcff" fontSize="9">{etiket}</text>
    </svg>
  );
}
export function Altigen({ etiket, seed = 1, renk = "#00e5ff" }: { etiket: string; seed?: number } & Ortak) {
  const r = tohum(seed), cells: React.ReactElement[] = [];
  for (let row = 0; row < 4; row++) for (let col = 0; col < 6; col++) {
    const cx = 14 + col * 18 + (row % 2) * 9, cy = 14 + row * 15, p = Array.from({ length: 6 }, (_, k) => `${(cx + 8 * Math.cos((k * Math.PI) / 3)).toFixed(1)},${(cy + 8 * Math.sin((k * Math.PI) / 3)).toFixed(1)}`).join(" ");
    cells.push(<polygon key={`${row}-${col}`} points={p} fill={renk} fillOpacity={r() > 0.55 ? 0.55 : 0.1} stroke={renk} strokeOpacity=".5" />);
  }
  return (<svg viewBox="0 0 120 80" className="w-altigen" role="img" aria-label={etiket}>{cells}<text x="60" y="77" textAnchor="middle" fill="#8fdcff" fontSize="9">{etiket}</text></svg>);
}
export function Halka({ etiket, seed = 1, renk = "#00e5ff" }: { etiket: string; seed?: number } & Ortak) {
  const r = tohum(seed);
  return (
    <svg viewBox="0 0 120 120" className="w-halka" role="img" aria-label={etiket}>
      {[48, 38, 28, 18].map((q, i) => <circle key={q} className={i % 2 ? "w-don-ters" : "w-don"} cx="60" cy="60" r={q} fill="none" stroke={renk} strokeWidth="2" strokeDasharray={`${8 + r() * 30} ${6 + r() * 14}`} strokeOpacity={0.9 - i * 0.15} />)}
      <circle cx="60" cy="60" r="6" fill={renk} />
      <text x="60" y="116" textAnchor="middle" fill="#8fdcff" fontSize="9">{etiket}</text>
    </svg>
  );
}

import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "BÖLGE";
export default function BolgeAltigen(p: Ortak) {
  return <Altigen etiket="BÖLGE" seed={644} renk={p.renk} />;
}

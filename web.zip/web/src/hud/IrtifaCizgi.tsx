import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "İRTİFA";
export default function IrtifaCizgi(p: Ortak) {
  return <Cizgi etiket="İRTİFA" seed={449} renk={p.renk} />;
}

import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "DÖNÜ";
export default function DonuHalka(p: Ortak) {
  return <Halka etiket="DÖNÜ" seed={683} renk={p.renk} />;
}

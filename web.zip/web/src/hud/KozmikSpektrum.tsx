import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "KOZMİK";
export default function KozmikSpektrum(p: Ortak) {
  return <Spektrum etiket="KOZMİK" seed={319} renk={p.renk} />;
}

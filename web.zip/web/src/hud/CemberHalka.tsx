import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ÇEMBER";
export default function CemberHalka(p: Ortak) {
  return <Halka etiket="ÇEMBER" seed={748} renk={p.renk} />;
}

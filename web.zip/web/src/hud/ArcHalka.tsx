import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ARC";
export default function ArcHalka(p: Ortak) {
  return <Halka etiket="ARC" seed={761} renk={p.renk} />;
}

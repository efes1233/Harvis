import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ALAN";
export default function AlanHalka(p: Ortak) {
  return <Halka etiket="ALAN" seed={774} renk={p.renk} />;
}

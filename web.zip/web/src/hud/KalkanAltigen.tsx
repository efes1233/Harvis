import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "KALKAN";
export default function KalkanAltigen(p: Ortak) {
  return <Altigen etiket="KALKAN" seed={540} renk={p.renk} />;
}

import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "NEM";
export default function NemCizgi(p: Ortak) {
  return <Cizgi etiket="NEM" seed={462} renk={p.renk} />;
}

import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "KALP";
export default function KalpSpektrum(p: Ortak) {
  return <Spektrum etiket="KALP" seed={358} renk={p.renk} />;
}

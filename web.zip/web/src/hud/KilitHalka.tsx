import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "KİLİT";
export default function KilitHalka(p: Ortak) {
  return <Halka etiket="KİLİT" seed={696} renk={p.renk} />;
}

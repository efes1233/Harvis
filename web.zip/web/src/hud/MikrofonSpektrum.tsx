import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "MİKROFON";
export default function MikrofonSpektrum(p: Ortak) {
  return <Spektrum etiket="MİKROFON" seed={293} renk={p.renk} />;
}

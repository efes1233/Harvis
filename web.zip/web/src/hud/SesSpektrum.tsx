import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "SES";
export default function SesSpektrum(p: Ortak) {
  return <Spektrum etiket="SES" seed={280} renk={p.renk} />;
}

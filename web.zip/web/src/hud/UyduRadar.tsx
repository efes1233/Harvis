import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "UYDU";
export default function UyduRadar(p: Ortak) {
  return <Radar etiket="UYDU" seed={189} renk={p.renk} />;
}

import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "CPU";
export default function CpuGauge(p: Ortak) {
  return <Gauge etiket="CPU" birim="%" deger={p.deger ?? 50} renk={p.renk ?? "#00e5ff"} />;
}

import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "GPU";
export default function GpuGauge(p: Ortak) {
  return <Gauge etiket="GPU" birim="%" deger={p.deger ?? 63} renk={p.renk ?? "#4cc9f0"} />;
}

import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "YÜK";
export default function YukCizgi(p: Ortak) {
  return <Cizgi etiket="YÜK" seed={501} renk={p.renk} />;
}

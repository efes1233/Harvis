import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "MOTOR";
export default function MotorSpektrum(p: Ortak) {
  return <Spektrum etiket="MOTOR" seed={371} renk={p.renk} />;
}

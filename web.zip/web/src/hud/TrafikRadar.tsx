import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "TRAFİK";
export default function TrafikRadar(p: Ortak) {
  return <Radar etiket="TRAFİK" seed={228} renk={p.renk} />;
}

import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ENERJİ";
export default function EnerjiCizgi(p: Ortak) {
  return <Cizgi etiket="ENERJİ" seed={410} renk={p.renk} />;
}

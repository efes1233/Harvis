import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "PİL";
export default function PilGauge(p: Ortak) {
  return <Gauge etiket="PİL" birim="%" deger={p.deger ?? 68} renk={p.renk ?? "#06d6a0"} />;
}

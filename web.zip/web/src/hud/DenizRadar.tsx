import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "DENİZ";
export default function DenizRadar(p: Ortak) {
  return <Radar etiket="DENİZ" seed={267} renk={p.renk} />;
}

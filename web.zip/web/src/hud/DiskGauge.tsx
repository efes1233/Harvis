import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "DİSK";
export default function DiskGauge(p: Ortak) {
  return <Gauge etiket="DİSK" birim="%" deger={p.deger ?? 89} renk={p.renk ?? "#80ffdb"} />;
}

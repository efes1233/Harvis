import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "SENSÖR";
export default function SensorAltigen(p: Ortak) {
  return <Altigen etiket="SENSÖR" seed={631} renk={p.renk} />;
}

import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "HIZ";
export default function HizCizgi(p: Ortak) {
  return <Cizgi etiket="HIZ" seed={436} renk={p.renk} />;
}

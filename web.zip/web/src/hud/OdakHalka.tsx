import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ODAK";
export default function OdakHalka(p: Ortak) {
  return <Halka etiket="ODAK" seed={735} renk={p.renk} />;
}

import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "YAMA";
export default function YamaAltigen(p: Ortak) {
  return <Altigen etiket="YAMA" seed={618} renk={p.renk} />;
}

import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ORBİT";
export default function OrbitHalka(p: Ortak) {
  return <Halka etiket="ORBİT" seed={787} renk={p.renk} />;
}

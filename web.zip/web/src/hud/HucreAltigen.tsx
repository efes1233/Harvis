import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "HÜCRE";
export default function HucreAltigen(p: Ortak) {
  return <Altigen etiket="HÜCRE" seed={566} renk={p.renk} />;
}

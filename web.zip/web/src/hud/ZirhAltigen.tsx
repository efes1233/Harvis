import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ZIRH";
export default function ZirhAltigen(p: Ortak) {
  return <Altigen etiket="ZIRH" seed={553} renk={p.renk} />;
}

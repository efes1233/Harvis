import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "OKSİJEN";
export default function OksijenCizgi(p: Ortak) {
  return <Cizgi etiket="OKSİJEN" seed={527} renk={p.renk} />;
}

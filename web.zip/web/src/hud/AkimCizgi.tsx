import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "AKIM";
export default function AkimCizgi(p: Ortak) {
  return <Cizgi etiket="AKIM" seed={488} renk={p.renk} />;
}

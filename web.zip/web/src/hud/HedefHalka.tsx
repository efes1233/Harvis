import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "HEDEF";
export default function HedefHalka(p: Ortak) {
  return <Halka etiket="HEDEF" seed={709} renk={p.renk} />;
}

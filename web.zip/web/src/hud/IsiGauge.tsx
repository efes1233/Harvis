import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "ISI";
export default function IsiGauge(p: Ortak) {
  return <Gauge etiket="ISI" birim="°" deger={p.deger ?? 55} renk={p.renk ?? "#ffd166"} />;
}

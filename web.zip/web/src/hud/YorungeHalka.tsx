import React from "react";
import { Halka, type Ortak } from "./_sablon.tsx";

export const ETIKET = "YÖRÜNGE";
export default function YorungeHalka(p: Ortak) {
  return <Halka etiket="YÖRÜNGE" seed={722} renk={p.renk} />;
}

import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "SİNYAL";
export default function SinyalGauge(p: Ortak) {
  return <Gauge etiket="SİNYAL" birim="%" deger={p.deger ?? 81} renk={p.renk ?? "#48cae4"} />;
}

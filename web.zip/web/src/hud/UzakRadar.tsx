import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "UZAK";
export default function UzakRadar(p: Ortak) {
  return <Radar etiket="UZAK" seed={163} renk={p.renk} />;
}

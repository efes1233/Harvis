import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "MATRİS";
export default function MatrisAltigen(p: Ortak) {
  return <Altigen etiket="MATRİS" seed={657} renk={p.renk} />;
}

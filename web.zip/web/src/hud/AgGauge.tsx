import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "AĞ";
export default function AgGauge(p: Ortak) {
  return <Gauge etiket="AĞ" birim="%" deger={p.deger ?? 42} renk={p.renk ?? "#00b4d8"} />;
}

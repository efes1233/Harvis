import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "DRON";
export default function DronRadar(p: Ortak) {
  return <Radar etiket="DRON" seed={254} renk={p.renk} />;
}

import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "PAKET";
export default function PaketCizgi(p: Ortak) {
  return <Cizgi etiket="PAKET" seed={514} renk={p.renk} />;
}

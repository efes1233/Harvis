import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "HAVA";
export default function HavaRadar(p: Ortak) {
  return <Radar etiket="HAVA" seed={176} renk={p.renk} />;
}

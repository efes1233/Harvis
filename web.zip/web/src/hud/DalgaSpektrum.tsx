import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "DALGA";
export default function DalgaSpektrum(p: Ortak) {
  return <Spektrum etiket="DALGA" seed={397} renk={p.renk} />;
}

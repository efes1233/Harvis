import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "YAKIN";
export default function YakinRadar(p: Ortak) {
  return <Radar etiket="YAKIN" seed={150} renk={p.renk} />;
}

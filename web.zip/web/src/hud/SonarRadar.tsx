import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "SONAR";
export default function SonarRadar(p: Ortak) {
  return <Radar etiket="SONAR" seed={202} renk={p.renk} />;
}

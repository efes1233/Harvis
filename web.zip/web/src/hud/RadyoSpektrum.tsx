import React from "react";
import { Spektrum, type Ortak } from "./_sablon.tsx";

export const ETIKET = "RADYO";
export default function RadyoSpektrum(p: Ortak) {
  return <Spektrum etiket="RADYO" seed={332} renk={p.renk} />;
}

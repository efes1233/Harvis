import React from "react";
import { Radar, type Ortak } from "./_sablon.tsx";

export const ETIKET = "GÖK";
export default function GokRadar(p: Ortak) {
  return <Radar etiket="GÖK" seed={215} renk={p.renk} />;
}

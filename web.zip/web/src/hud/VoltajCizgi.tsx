import React from "react";
import { Cizgi, type Ortak } from "./_sablon.tsx";

export const ETIKET = "VOLTAJ";
export default function VoltajCizgi(p: Ortak) {
  return <Cizgi etiket="VOLTAJ" seed={475} renk={p.renk} />;
}

import React from "react";
import { Altigen, type Ortak } from "./_sablon.tsx";

export const ETIKET = "MODÜL";
export default function ModulAltigen(p: Ortak) {
  return <Altigen etiket="MODÜL" seed={592} renk={p.renk} />;
}

import React from "react";
import { Gauge, type Ortak } from "./_sablon.tsx";

export const ETIKET = "GÜÇ";
export default function GucGauge(p: Ortak) {
  return <Gauge etiket="GÜÇ" birim="%" deger={p.deger ?? 34} renk={p.renk ?? "#ff9f1c"} />;
}

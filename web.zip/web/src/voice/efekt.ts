// Ses efektleri (assets/sounds/*.wav)
export type EfektAd = "baslangic" | "bip" | "uyanma" | "pinch" | "meteor_carpma" | "hud_ambient" | "tarama";
const onbellek = new Map<string, HTMLAudioElement>();
let sessiz = false;
export const sesiKapat = (k: boolean) => { sessiz = k; };

export function efektCal(ad: EfektAd, ses = 0.5, dongu = false): HTMLAudioElement | null {
  if (sessiz || typeof Audio === "undefined") return null;
  let a = onbellek.get(ad);
  if (!a) { a = new Audio(`/assets/sounds/${ad}.wav`); onbellek.set(ad, a); }
  a.loop = dongu; a.volume = ses; a.currentTime = 0;
  a.play().catch(() => {});
  return a;
}

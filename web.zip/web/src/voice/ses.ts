// Tarayıcı ses katmanı: sürekli dinleme (Web Speech API) + uyanma kelimesi + konuşma (ElevenLabs veya yerel sentez).
import { UyanmaDinleyici } from "../../../server/src/wake.ts";

type SR = { lang: string; continuous: boolean; interimResults: boolean; onresult: ((e: any) => void) | null; onend: (() => void) | null; onerror: ((e: any) => void) | null; start(): void; stop(): void };

export function sesTanimaDestekli(): boolean {
  return typeof window !== "undefined" && Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
}

export class SesKontrol {
  private sr: SR | null = null;
  private dinliyor = false;
  private konusuyor = false;
  private uyanma = new UyanmaDinleyici(9000);
  onKomut: (metin: string) => void = () => {};
  onDurum: (d: "kapali" | "uyanma_bekliyor" | "dinliyor") => void = () => {};
  onMetin: (m: string, son: boolean) => void = () => {};

  baslat(): boolean {
    if (!sesTanimaDestekli()) return false;
    const C = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const sr: SR = new C(); sr.lang = "tr-TR"; sr.continuous = true; sr.interimResults = true;
    sr.onresult = (e) => {
      if (this.konusuyor) return; // kendi sesimizi duymayalım
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const metin: string = e.results[i][0].transcript; const son: boolean = e.results[i].isFinal;
        this.onMetin(metin, son);
        if (!son) continue;
        const r = this.uyanma.isle(metin);
        this.onDurum(r.aktif ? "dinliyor" : "uyanma_bekliyor");
        if (r.aktif && r.komut) this.onKomut(r.komut);
      }
    };
    sr.onend = () => { if (this.dinliyor) { try { sr.start(); } catch { /* zaten çalışıyor */ } } };
    sr.onerror = (e) => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { this.dinliyor = false; this.onDurum("kapali"); } };
    this.sr = sr; this.dinliyor = true; sr.start(); this.onDurum("uyanma_bekliyor");
    return true;
  }
  durdur() { this.dinliyor = false; this.sr?.stop(); this.sr = null; this.onDurum("kapali"); }
  get aktif() { return this.dinliyor; }

  /** Yanıtı seslendirir. ElevenLabs hazırsa onu, değilse tarayıcı sesini (alçak perde) kullanır. */
  private kuyruk: Promise<void> = Promise.resolve();
  /** Konuşmalar üst üste binmesin diye sıraya girer. */
  konus(metin: string): Promise<void> { this.kuyruk = this.kuyruk.then(() => this.sesver(metin)).catch(() => {}); return this.kuyruk; }

  private async sesver(metin: string): Promise<void> {
    this.konusuyor = true;
    try {
      const anahtar = (() => { try { return localStorage.getItem("jarvis_erisim_anahtari") ?? ""; } catch { return ""; } })();
      const r = await fetch("/api/tts", { method: "POST", headers: { "content-type": "application/json", ...(anahtar ? { "x-jarvis-key": anahtar } : {}) }, body: JSON.stringify({ metin }) });
      const ct = r.headers.get("content-type") ?? "";
      if (r.ok && ct.startsWith("audio/")) {
        const url = URL.createObjectURL(await r.blob()); const a = new Audio(url);
        await new Promise<void>((res) => { a.onended = () => res(); a.onerror = () => res(); a.play().catch(() => res()); });
        URL.revokeObjectURL(url); return;
      }
    } catch { /* yerel sentez */ }
    try {
      if (!("speechSynthesis" in window)) return;
      const u = new SpeechSynthesisUtterance(metin); u.lang = "tr-TR"; u.pitch = 0.75; u.rate = 1.02;
      const v = speechSynthesis.getVoices().find((x) => x.lang.startsWith("tr")); if (v) u.voice = v;
      await new Promise<void>((res) => { u.onend = () => res(); u.onerror = () => res(); speechSynthesis.speak(u); });
    } finally { setTimeout(() => { this.konusuyor = false; }, 300); }
    this.konusuyor = false;
  }
}

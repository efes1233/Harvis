import React, { useEffect, useRef, useState } from "react";

export type Satir = { kim: "sen" | "jarvis" | "sistem"; metin: string };
type Props = { satirlar: Satir[]; onGonder: (m: string) => void; dinleniyor: string };

export default function Konsol({ satirlar, onGonder, dinleniyor }: Props) {
  const [m, setM] = useState(""); const son = useRef<HTMLDivElement>(null);
  useEffect(() => { son.current?.scrollTo({ top: 1e9 }); }, [satirlar]);
  return (
    <section className="panel konsol" aria-label="Konsol">
      <header>KONSOL <span className="rozet">{dinleniyor}</span></header>
      <div className="satirlar" ref={son}>
        {satirlar.map((s, i) => <p key={i} className={`s-${s.kim}`}><b>{s.kim === "sen" ? "SİZ" : s.kim === "jarvis" ? "JARVIS" : "SİSTEM"}</b> {s.metin}</p>)}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); if (m.trim()) { onGonder(m.trim()); setM(""); } }}>
        <input value={m} onChange={(e) => setM(e.target.value)} placeholder='Örn: "İstanbul’a meteor çarpması başlat"' aria-label="Komut" />
        <button type="submit">GÖNDER</button>
      </form>
    </section>
  );
}

import React, { useState } from "react";
import type { Film } from "../../../shared/film.ts";

export type Beyin = { ad: string; model: string; ucretsiz: boolean };
type Props = { beyinler: Beyin[]; oynuyor: boolean; oran: number; baslik?: string; altyazi: string; kaynaklar: string[]; mesgul: boolean; onUret: (istek: string, sure: 30 | 60, uretimSn: 30 | 60) => void; onDurdur: () => void };

export default function FilmPaneli({ beyinler, oynuyor, oran, baslik, altyazi, kaynaklar, mesgul, onUret, onDurdur }: Props) {
  const [istek, setIstek] = useState("İstanbul'a dev bir göktaşı çarpıyor");
  const [sure, setSure] = useState<30 | 60>(30); const [uretim, setUretim] = useState<30 | 60>(30);
  return (
    <section className="panel film" aria-label="Senaryo stüdyosu">
      <header>SENARYO STÜDYOSU <span className="rozet">{beyinler.length ? `${beyinler.length} BEYİN` : "YEREL YAZAR"}</span></header>
      <div className="beyinler">{beyinler.length ? beyinler.map((b) => <span key={b.ad} className={`cip ${b.ucretsiz ? "ucretsiz" : ""}`} title={b.model}>{b.ad}{b.ucretsiz ? " ✓" : ""}</span>) : <small>API anahtarı yok: yerel yazar kullanılır (.env dosyasına anahtar ekleyin)</small>}</div>
      <textarea value={istek} onChange={(e) => setIstek(e.target.value)} rows={2} aria-label="Senaryo isteği" maxLength={400} />
      <div className="satir">
        <label>Film <select value={sure} onChange={(e) => setSure(Number(e.target.value) as 30 | 60)}><option value={30}>30 sn</option><option value={60}>1 dk</option></select></label>
        <label>Yazma süresi <select value={uretim} onChange={(e) => setUretim(Number(e.target.value) as 30 | 60)}><option value={30}>30 sn</option><option value={60}>1 dk</option></select></label>
        <button disabled={mesgul || oynuyor} onClick={() => onUret(istek, sure, uretim)}>{mesgul ? "YAZILIYOR…" : "✦ AI'LAR YAZSIN"}</button>
        {oynuyor && <button onClick={onDurdur}>■ DURDUR</button>}
      </div>
      {(oynuyor || baslik) && <div className="ilerleme"><div style={{ width: `${oran * 100}%` }} /></div>}
      {baslik && <small>🎬 {baslik} · yazanlar: {kaynaklar.join(" + ")}</small>}
      {oynuyor && altyazi && <p className="altyazi" role="status">{altyazi}</p>}
    </section>
  );
}
export type { Film };

import React from "react";

const UYDULAR = [{ ad: "SAT-01", r: 262, sure: 38, a: 20 }, { ad: "SAT-02", r: 262, sure: 52, a: 140 }, { ad: "ISS", r: 222, sure: 24, a: 260 }];

/** Dönen yörünge çizgileri ve telemetri etiketleri. */
export default function Orbit({ zoom = 1, fps = 0 }: { zoom?: number; fps?: number }) {
  return (
    <svg viewBox="-300 -300 600 600" className="orbit" aria-hidden="true">
      <ellipse rx="262" ry="86" fill="none" stroke="var(--c)" strokeOpacity=".4" transform="rotate(-24)" />
      <ellipse rx="222" ry="62" fill="none" stroke="var(--c2)" strokeOpacity=".4" transform="rotate(18)" />
      {UYDULAR.map((u) => (
        <g key={u.ad} className="uydu" style={{ animationDuration: `${u.sure}s`, animationDelay: `-${u.a / 10}s` }}>
          <circle cx={u.r} cy="0" r="4" fill="var(--c)" /><text x={u.r + 8} y="4" fill="var(--c)" fontSize="9">{u.ad}</text>
        </g>
      ))}
      <text x="-290" y="280" fill="var(--c)" fontSize="10">ZOOM {zoom.toFixed(2)}x</text>
      <text x="290" y="280" textAnchor="end" fill="var(--c)" fontSize="10">{fps} FPS</text>
    </svg>
  );
}

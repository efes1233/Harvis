import React from "react";

/** Reaktör çekirdeği tarzı dönen halkalar; Globe üzerine bindirilir. */
export default function HudCore({ durum = "HAZIR", etkin = true }: { durum?: string; etkin?: boolean }) {
  const tikler = Array.from({ length: 72 }, (_, i) => i);
  return (
    <svg viewBox="-300 -300 600 600" className={`hud-core ${etkin ? "etkin" : ""}`} aria-hidden="true">
      <g className="don-yavas">
        <circle r="285" fill="none" stroke="var(--c)" strokeOpacity=".35" strokeDasharray="2 10" />
        {tikler.map((i) => <line key={i} x1="0" y1="-270" x2="0" y2={i % 6 === 0 ? -255 : -262} stroke="var(--c)" strokeOpacity={i % 6 === 0 ? 0.9 : 0.4} transform={`rotate(${i * 5})`} />)}
      </g>
      <g className="don-ters">
        <circle r="248" fill="none" stroke="var(--c)" strokeOpacity=".5" strokeWidth="2" strokeDasharray="120 40 20 40" />
        <circle r="236" fill="none" stroke="var(--c2)" strokeOpacity=".5" strokeDasharray="4 6" />
      </g>
      <g>
        {[0, 90, 180, 270].map((a) => <path key={a} d="M-30 -292 L0 -280 L30 -292" fill="none" stroke="var(--c)" strokeWidth="2" transform={`rotate(${a})`} />)}
      </g>
      <text x="0" y="-306" textAnchor="middle" fill="var(--c)" fontSize="12" letterSpacing="4" dy="14">{durum}</text>
    </svg>
  );
}

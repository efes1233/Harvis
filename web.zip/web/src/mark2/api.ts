// Sunucu çağrıları: erişim anahtarı (varsa) ve anlaşılır hata mesajları.
const ANAHTAR = "jarvis_erisim_anahtari";
export async function apiPost(yol: string, govde: unknown, tekrar = true): Promise<unknown> {
  const anahtar = (() => { try { return localStorage.getItem(ANAHTAR) ?? ""; } catch { return ""; } })();
  const r = await fetch(yol, { method: "POST", headers: { "content-type": "application/json", ...(anahtar ? { "x-jarvis-key": anahtar } : {}) }, body: JSON.stringify(govde) });
  if (r.status === 401 && tekrar) {
    const yeni = window.prompt("Bu JARVIS sunucusu erişim anahtarı istiyor:");
    if (yeni) { try { localStorage.setItem(ANAHTAR, yeni); } catch { /* özel mod */ } return apiPost(yol, govde, false); }
    throw new Error("Erişim anahtarı gerekli.");
  }
  if (r.status === 429) throw new Error("Çok fazla istek; birkaç saniye bekleyin.");
  if (!r.ok) throw new Error(`Sunucu hatası (${r.status}).`);
  return r.json();
}

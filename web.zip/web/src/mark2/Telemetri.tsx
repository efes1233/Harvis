import React from "react";
import type { Etki } from "../../../shared/fizik.ts";

export default function Telemetri({ etki, ad, evre, t }: { etki: Etki | null; ad?: string; evre: number; t: number }) {
  const evreAd = ["YAKLAŞMA", "ETKİ", "SÖNÜM"][evre] ?? "BEKLEMEDE";
  return (
    <section className="panel telemetri" aria-label="Telemetri">
      <header>SENARYO TELEMETRİSİ</header>
      <div className="durum"><span>{ad ?? "Aktif senaryo yok"}</span><span className="rozet">{evreAd}{evre >= 0 ? ` T+${t.toFixed(1)}s` : ""}</span></div>
      <ul>{(etki?.satirlar ?? ["Bir komut verin veya aşağıdan senaryo seçin."]).map((s, i) => <li key={i}>{s}</li>)}</ul>
    </section>
  );
}

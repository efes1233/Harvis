import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Globe from "../evren/Globe.tsx";
import { Motor } from "../evren/motor.ts";
import { senaryolariGetir } from "../evren/senaryo.ts";
import { jestUygula } from "../evren/evrenFeatures.ts";
import { JestMotoru, IkiElZoom, type El } from "../hands/gestures.ts";
import { ElTakipci } from "../hands/tracker.ts";
import { YuzTakipci } from "../hands/face.ts";
import Onizleme from "../hands/Onizleme.tsx";
import { SesKontrol, sesTanimaDestekli } from "../voice/ses.ts";
import { efektCal } from "../voice/efekt.ts";
import HudCore from "./HudCore.tsx";
import Orbit from "./Orbit.tsx";
import Konsol, { type Satir } from "./Konsol.tsx";
import Telemetri from "./Telemetri.tsx";
import FilmPaneli, { type Beyin } from "./FilmPaneli.tsx";
import { FilmOynatici } from "../evren/film.ts";
import type { Film } from "../../../shared/film.ts";
import { apiPost } from "./api.ts";
import { TUM_WIDGETLAR } from "../hud/index.ts";
import type { Senaryo } from "../../../shared/types.ts";
import type { Yildiz, SehirNokta } from "../evren/ciz.ts";

const SOL = ["CpuGauge", "RamGauge", "SismikSpektrum", "EnerjiCizgi"] as const;
const SAG = ["UyduRadar", "ReaktorHalka", "KalkanAltigen", "FrekansSpektrum"] as const;
const HIZLI = [["Meteor: İstanbul", "İstanbul'a 300 metre meteor çarpması başlat"], ["Deprem: Tokyo", "Tokyo'da deprem simülasyonu başlat"], ["Güneş patlaması", "güneş patlaması başlat"], ["Ankara'ya odaklan", "Ankara'yı göster"], ["Yaklaş", "yaklaş"], ["Sıfırla", "sıfırla"]] as const;

export default function Mark2() {
  const motor = useMemo(() => new Motor(), []);
  const [basladi, setBasladi] = useState(false);
  const [tema, setTema] = useState<"mavi" | "kirmizi">("mavi");
  const [satirlar, setSatirlar] = useState<Satir[]>([{ kim: "sistem", metin: "JARVIS Mark II hazır. \"Jarvis\" diyerek ya da yazarak komut verin." }]);
  const [sehirler, setSehirler] = useState<SehirNokta[]>([]);
  const [yildizlar, setYildizlar] = useState<Yildiz[]>([]);
  const [senaryolar, setSenaryolar] = useState<Senaryo[]>([]);
  const [fps, setFps] = useState(0);
  const [, yenile] = useState(0);
  const [sesDurum, setSesDurum] = useState<"kapali" | "uyanma_bekliyor" | "dinliyor">("kapali");
  const [kameraAktif, setKameraAktif] = useState(false);
  const [eller, setEller] = useState<El[]>([]);
  const [poz, setPoz] = useState("none");
  const ses = useRef(new SesKontrol()); const takipci = useRef(new ElTakipci()); const yuz = useRef(new YuzTakipci());
  const video = useRef<HTMLVideoElement>(null);
  const [beyinler, setBeyinler] = useState<Beyin[]>([]);
  const [filmMesgul, setFilmMesgul] = useState(false);
  const [filmBilgi, setFilmBilgi] = useState<{ baslik?: string; kaynaklar: string[] }>({ kaynaklar: [] });
  const [altyazi, setAltyazi] = useState("");
  const filmOyn = useRef(new FilmOynatici()); const altyaziZaman = useRef<ReturnType<typeof setTimeout>>();
  const jest = useRef(new JestMotoru()); const ikiEl = useRef(new IkiElZoom());

  const yaz = useCallback((kim: Satir["kim"], metin: string) => setSatirlar((s) => [...s.slice(-60), { kim, metin }]), []);

  useEffect(() => {
    fetch("/assets/data/sehirler.json").then((r) => r.json()).then(setSehirler).catch(() => {});
    fetch("/assets/data/yildizlar.json").then((r) => r.json()).then((y: Yildiz[]) => setYildizlar(y.sort((a, b) => a.mag - b.mag).slice(0, 7000))).catch(() => {});
    senaryolariGetir().then(setSenaryolar).catch(() => {});
    fetch("/api/durum").then((r) => r.json()).then((d) => setBeyinler(d.beyinler ?? [])).catch(() => {});
    const t = setInterval(() => yenile((n) => n + 1), 250);
    return () => clearInterval(t);
  }, []);

  const filmBaslat = useCallback((f: Film) => { filmOyn.current.baslat(f); motor.sifirla(); setFilmBilgi({ baslik: f.baslik, kaynaklar: f.kaynaklar }); yaz("sistem", `Film: ${f.baslik} (${f.sure} sn) – yazanlar: ${f.kaynaklar.join(" + ")}`); efektCal("tarama", 0.4); }, [motor, yaz]);
  const anlat = useCallback((m: string) => { setAltyazi(m); clearTimeout(altyaziZaman.current); altyaziZaman.current = setTimeout(() => setAltyazi(""), 6500); void ses.current.konus(m); }, []);
  const filmAdim = useCallback((dt: number) => { filmOyn.current.adim(dt, { motor, anlat, tema: setTema, bitti: () => { setAltyazi(""); yaz("sistem", "Film bitti."); } }); }, [motor, anlat, yaz]);
  const filmUret = useCallback(async (istek: string, sure: 30 | 60, uretimSn: 30 | 60) => {
    setFilmMesgul(true); yaz("sistem", `Beyinler senaryo yazıyor (en fazla ${uretimSn} sn)…`); efektCal("tarama", 0.3);
    try { const r = (await apiPost("/api/film", { istek, sure, uretimSn })) as { film: Film; yerel: boolean; hatalar: Record<string, string> };
      const hata = Object.entries(r.hatalar ?? {}); if (hata.length) yaz("sistem", "Yazamayanlar: " + hata.map(([a, m]) => `${a} (${m})`).join(", "));
      filmBaslat(r.film);
    } catch (err) { yaz("sistem", (err as Error).message); } finally { setFilmMesgul(false); }
  }, [filmBaslat, yaz]);

  const komut = useCallback(async (metin: string) => {
    yaz("sen", metin);
    try {
      const j = (await apiPost("/api/komut", { metin })) as { yanit: string; eylemler: any[] };
      yaz("jarvis", j.yanit);
      for (const e of j.eylemler) {
        if (e.tip === "senaryo") { motor.senaryoBaslat(e.senaryo); efektCal("tarama", 0.4); setTimeout(() => efektCal("meteor_carpma", 0.7), 3000); }
        else if (e.tip === "dunya") { if (e.komut === "yakinlas") motor.yakinlas(); else if (e.komut === "uzaklas") motor.uzaklas(); else if (e.komut === "dondur") motor.dondur(); else motor.sifirla(); }
        else if (e.tip === "odak") motor.odaklan(e.lat, e.lon, 2.2);
        else if (e.tip === "tema") setTema(e.tema);
        else if (e.tip === "kamera") e.ac ? kameraAc() : kameraKapat();
        else if (e.tip === "film") filmBaslat(e.film);
      }
      void ses.current.konus(j.yanit);
    } catch (err) { yaz("sistem", (err as Error).message || "Sunucuya ulaşılamadı."); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [motor, yaz, filmBaslat]);

  const kameraAc = useCallback(async () => {
    if (takipci.current.aktif || !video.current) return;
    try {
      takipci.current.sonuc(({ eller: e, t }) => {
        setEller(e);
        if (e.length >= 2) { const z = ikiEl.current.guncelle(e[0], e[1]); if (z) jestUygula(motor, z); }
        else for (const o of jest.current.guncelle(e[0] ?? null, t)) jestUygula(motor, o, (m, s) => { yaz("sistem", m); if (s) efektCal(s, 0.3); });
        setPoz(jest.current.mevcutPoz);
      });
      await takipci.current.baslat(video.current); setKameraAktif(true); yaz("sistem", "El takibi aktif: kavra=döndür, itme=yaklaş, çekme=uzaklaş, savurma=çevir, yumruk+it=meteor.");
      yuz.current.baslat().catch(() => {});
    } catch (err) { yaz("sistem", (err as Error).message); setKameraAktif(false); }
  }, [motor, yaz]);
  const kameraKapat = useCallback(() => { takipci.current.durdur(); yuz.current.durdur(); jest.current.sifirla(); setKameraAktif(false); setEller([]); }, []);

  const sesiAc = useCallback(() => {
    const s = ses.current; s.onKomut = (m) => { efektCal("uyanma", 0.4); void komut(m); }; s.onDurum = setSesDurum;
    if (!s.baslat()) yaz("sistem", "Bu tarayıcı konuşma tanımayı desteklemiyor (Chrome/Edge önerilir). Yazarak komut verebilirsiniz.");
  }, [komut, yaz]);

  const baslat = () => { setBasladi(true); efektCal("baslangic", 0.5); setTimeout(() => efektCal("hud_ambient", 0.12, true), 3000); void ses.current.konus("Sistemler çevrimiçi. Hoş geldiniz, efendim."); };

  // Klavye yedeği
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      if (e.key === "+" || e.key === "=") motor.yakinlas(); else if (e.key === "-") motor.uzaklas();
      else if (e.key === "ArrowLeft") motor.velLon = -1; else if (e.key === "ArrowRight") motor.velLon = 1;
      else if (e.key === "ArrowUp") motor.velLat = 0.7; else if (e.key === "ArrowDown") motor.velLat = -0.7;
      else if (e.key === "Escape") motor.sifirla();
    };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [motor]);

  const W = TUM_WIDGETLAR;
  return (
    <div className="mark2" data-tema={tema}>
      {!basladi && <button className="baslat" onClick={baslat}><span>JARVIS</span><small>Sistemi başlatmak için dokunun</small></button>}
      <header className="ust"><b>J.A.R.V.I.S.</b><span>MARK II · EVREN SİMÜLASYONU</span><span className="rozet">{sesDurum === "kapali" ? "SES KAPALI" : sesDurum === "dinliyor" ? "DİNLİYOR" : "“JARVIS” BEKLENİYOR"}</span></header>
      <aside className="sol">{SOL.map((a) => { const C = W[a]; return <div key={a} className="widget"><C /></div>; })}</aside>
      <main className="orta">
        <div className="sahne">
          <Globe motor={motor} tema={tema} sehirler={sehirler} yildizlar={yildizlar} onKare={setFps} onAdim={filmAdim} />
          <HudCore durum={motor.senaryo ? "SİMÜLASYON" : "HAZIR"} etkin={basladi} />
          <Orbit zoom={motor.zoom} fps={fps} />
          {filmOyn.current.calisiyor && altyazi && <p className="sahne-altyazi">{altyazi}</p>}
        </div>
        <div className="kontroller">
          <button onClick={() => (sesDurum === "kapali" ? sesiAc() : ses.current.durdur())} className={sesDurum !== "kapali" ? "on" : ""} disabled={!sesTanimaDestekli()}>🎙 {sesDurum === "kapali" ? "SESİ AÇ" : "SESİ KAPAT"}</button>
          <button onClick={() => (kameraAktif ? kameraKapat() : kameraAc())} className={kameraAktif ? "on" : ""}>✋ {kameraAktif ? "EL TAKİBİ KAPAT" : "EL TAKİBİ AÇ"}</button>
          <button onClick={() => setTema(tema === "mavi" ? "kirmizi" : "mavi")}>◐ TEMA</button>
        </div>
        <div className="hizli">{HIZLI.map(([e, k]) => <button key={e} onClick={() => komut(k)}>{e}</button>)}
          <select aria-label="Senaryo seç" value="" onChange={(e) => { const s = senaryolar.find((x) => x.id === e.target.value); if (s) { motor.senaryoBaslat(s); yaz("sistem", `Senaryo: ${s.ad}`); efektCal("tarama", 0.4); setTimeout(() => efektCal("meteor_carpma", 0.7), 3000); } }}>
            <option value="">Senaryo seç ({senaryolar.length})…</option>
            {senaryolar.map((s) => <option key={s.id} value={s.id}>{s.ad}</option>)}
          </select>
        </div>
      </main>
      <aside className="sag">
        <Onizleme ref={video} aktif={kameraAktif} eller={eller} poz={poz} />
        {SAG.map((a) => { const C = W[a]; return <div key={a} className="widget"><C /></div>; })}
      </aside>
      <div className="alt"><FilmPaneli beyinler={beyinler} oynuyor={filmOyn.current.calisiyor} oran={filmOyn.current.oran} baslik={filmBilgi.baslik} altyazi={altyazi} kaynaklar={filmBilgi.kaynaklar} mesgul={filmMesgul} onUret={filmUret} onDurdur={() => { filmOyn.current.durdur(); setAltyazi(""); }} /><Telemetri etki={motor.etki} ad={motor.senaryo?.ad} evre={motor.evre} t={motor.t} /><Konsol satirlar={satirlar} onGonder={komut} dinleniyor={sesDurum === "kapali" ? "YAZILI" : "SESLİ"} /></div>
    </div>
  );
}

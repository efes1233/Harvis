import React, { useEffect, useRef } from "react";
import { Motor } from "./motor.ts";
import { efektCiz } from "./efektCiz.ts";
import { dokuOku, kureCiz, izgaraCiz, sehirCiz, etkiCiz, yildizCiz, type Doku, type Yildiz, type SehirNokta } from "./ciz.ts";

const S = 560;
type Props = { motor: Motor; tema: "mavi" | "kirmizi"; sehirler: SehirNokta[]; yildizlar: Yildiz[]; onKare?: (fps: number) => void; onAdim?: (dt: number) => void };

function resimYukle(src: string): Promise<HTMLImageElement | null> {
  return new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
}

export default function Globe({ motor, tema, sehirler, yildizlar, onKare, onAdim }: Props) {
  const adimRef = useRef(onAdim); adimRef.current = onAdim;
  const ref = useRef<HTMLCanvasElement>(null);
  const dokular = useRef<{ gun: Doku | null; gece: Doku | null; bulut: Doku | null }>({ gun: null, gece: null, bulut: null });
  const temaRef = useRef(tema); temaRef.current = tema;
  const veri = useRef({ sehirler, yildizlar }); veri.current = { sehirler, yildizlar };

  useEffect(() => {
    let iptal = false;
    (async () => {
      const [g, n, b] = await Promise.all([resimYukle("/assets/textures/dunya_4k.png"), resimYukle("/assets/textures/dunya_gece_4k.png"), resimYukle("/assets/textures/bulutlar_2k.png")]);
      if (iptal) return;
      dokular.current = { gun: g ? dokuOku(g, 2048, 1024) : null, gece: n ? dokuOku(n, 2048, 1024) : null, bulut: b ? dokuOku(b, 1024, 512) : null };
    })();
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    const cv = ref.current!, ctx = cv.getContext("2d")!;
    let raf = 0, onceki = performance.now(), sayac = 0, sure = 0;
    const kare = (t: number) => {
      const dt = (t - onceki) / 1000; onceki = t;
      motor.adim(dt); adimRef.current?.(dt);
      const sar = motor.efekt.sarsintiOfset(); const ata = cv.parentElement; if (ata) ata.style.transform = sar.x || sar.y ? `translate(${sar.x.toFixed(1)}px, ${sar.y.toFixed(1)}px)` : "";
      ctx.fillStyle = "#020814"; ctx.fillRect(0, 0, S, S);
      yildizCiz(ctx, motor, veri.current.yildizlar, S);
      const d = dokular.current;
      kureCiz(ctx, motor, d.gun, d.gece, d.bulut, S, temaRef.current);
      izgaraCiz(ctx, motor, S, temaRef.current);
      sehirCiz(ctx, motor, veri.current.sehirler, S, temaRef.current);
      etkiCiz(ctx, motor, S);
      efektCiz(ctx, motor, S, temaRef.current);
      sayac++; sure += dt; if (sure >= 1) { onKare?.(sayac); sayac = 0; sure = 0; }
      raf = requestAnimationFrame(kare);
    };
    raf = requestAnimationFrame(kare);
    return () => cancelAnimationFrame(raf);
  }, [motor, onKare]);

  // Fare / dokunmatik: sürükle, tekerlek, iki parmak sıkıştırma
  useEffect(() => {
    const cv = ref.current!; const ptr = new Map<number, { x: number; y: number }>(); let sonDist = 0;
    const down = (e: PointerEvent) => { cv.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); motor.tutuyor = true; motor.otoDonus = false; motor.odakHedef = null; motor.velLon = 0; };
    const move = (e: PointerEvent) => {
      const p = ptr.get(e.pointerId); if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY;
      if (ptr.size === 1) { const k = (2.4 / cv.clientWidth) / Math.max(0.6, motor.zoom); motor.surukle(dx * k, dy * k); motor.velLon = -dx * k * 20; }
      else if (ptr.size === 2) { const [a, b] = [...ptr.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); if (sonDist) motor.zoomOran(d / sonDist); sonDist = d; }
    };
    const up = (e: PointerEvent) => { ptr.delete(e.pointerId); sonDist = 0; if (!ptr.size) { motor.tutuyor = false; } };
    const wheel = (e: WheelEvent) => { e.preventDefault(); motor.zoomOran(e.deltaY < 0 ? 1.12 : 1 / 1.12); };
    cv.addEventListener("pointerdown", down); cv.addEventListener("pointermove", move); cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
    cv.addEventListener("wheel", wheel, { passive: false });
    return () => { cv.removeEventListener("pointerdown", down); cv.removeEventListener("pointermove", move); cv.removeEventListener("pointerup", up); cv.removeEventListener("pointercancel", up); cv.removeEventListener("wheel", wheel); };
  }, [motor]);

  return <canvas ref={ref} width={S} height={S} className="globe-canvas" aria-label="Etkileşimli 3B Dünya" />;
}

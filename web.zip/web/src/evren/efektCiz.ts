// Efektlerin canvas çizimi (efektler.ts durumunu okur).
import type { Efektler } from "./efektler.ts";
import { RAD, type Motor } from "./motor.ts";

type Tema = "mavi" | "kirmizi";
const KARAKTER = "01アイウエオカキクケコ#<>/ΣΩ";

export function efektCiz(ctx: CanvasRenderingContext2D, m: Motor, S: number, tema: Tema) {
  const e = m.efekt, R = S * 0.36 * m.zoom;
  ctx.save(); ctx.globalCompositeOperation = "lighter";
  auroraCiz(ctx, m, e, S, R, tema);
  ctx.globalCompositeOperation = "source-over";
  for (const p of e.parcaciklar) { const a = 1 - p.omur / p.max; ctx.globalAlpha = Math.max(0, a); ctx.fillStyle = p.renk; ctx.beginPath(); ctx.arc(p.x * S, p.y * S, p.boyut * (0.5 + a), 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = "lighter";
  for (const d of e.sokDalgalari) {
    const a = Math.max(0, 1 - d.t / 2.2), r = d.t * 0.3 * S * d.siddet;
    ctx.strokeStyle = `rgba(255,${180 - d.t * 60 | 0},90,${a * 0.8})`; ctx.lineWidth = 6 * a + 1; ctx.beginPath(); ctx.arc(d.x * S, d.y * S, r, 0, 7); ctx.stroke();
    ctx.strokeStyle = `rgba(255,255,255,${a * 0.35})`; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(d.x * S, d.y * S, r * 0.82, 0, 7); ctx.stroke();
  }
  for (const s of e.simsekler) {
    ctx.globalAlpha = Math.min(1, s.omur * 4);
    for (const [w, c] of [[7, "rgba(120,180,255,0.35)"], [2, "#ffffff"]] as const) { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); s.pts.forEach((q, i) => (i ? ctx.lineTo(q.x * S, q.y * S) : ctx.moveTo(q.x * S, q.y * S))); ctx.stroke(); }
  }
  ctx.globalAlpha = 1;
  for (const k of e.kuyruklular) {
    const g = ctx.createLinearGradient(k.x * S, k.y * S, (k.x - k.vx * 0.9) * S, (k.y - k.vy * 0.9) * S);
    g.addColorStop(0, "rgba(255,255,255,0.95)"); g.addColorStop(1, "rgba(120,200,255,0)");
    ctx.strokeStyle = g; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(k.x * S, k.y * S); ctx.lineTo((k.x - k.vx * 0.9) * S, (k.y - k.vy * 0.9) * S); ctx.stroke();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(k.x * S, k.y * S, 3, 0, 7); ctx.fill();
  }
  if (e.tarama >= 0) {
    const y = e.tarama * S, g = ctx.createLinearGradient(0, y - 40, 0, y + 4);
    const c = tema === "mavi" ? "0,229,255" : "255,90,60"; g.addColorStop(0, `rgba(${c},0)`); g.addColorStop(1, `rgba(${c},0.55)`);
    ctx.fillStyle = g; ctx.fillRect(0, y - 40, S, 44);
  }
  ctx.restore();
  if (e.yagmur > 0) yagmurCiz(ctx, e, S, tema);
  if (e.parlama > 0) { ctx.fillStyle = `rgba(255,245,230,${Math.min(0.6, e.parlama * 0.5)})`; ctx.fillRect(0, 0, S, S); }
  if (e.glitch > 0) glitchCiz(ctx, e.glitch, S, e.zaman);
  // Vinyet nabzı: senaryo sırasında kenarlar kızarır
  if (m.senaryo) { const a = 0.12 + 0.08 * Math.sin(e.zaman * 6); const g = ctx.createRadialGradient(S / 2, S / 2, S * 0.4, S / 2, S / 2, S * 0.75); g.addColorStop(0, "rgba(255,0,0,0)"); g.addColorStop(1, `rgba(255,30,20,${a})`); ctx.fillStyle = g; ctx.fillRect(0, 0, S, S); }
}

function auroraCiz(ctx: CanvasRenderingContext2D, m: Motor, e: Efektler, S: number, R: number, tema: Tema) {
  const guc = Math.min(1.2, e.aurora); if (guc < 0.05) return;
  const cx = S / 2, cy = S / 2;
  for (const kutup of [1, -1]) {
    for (let lon = -180; lon < 180; lon += 3) {
      const dalga = 0.5 + 0.5 * Math.sin(lon * 0.09 + e.zaman * 1.3 + kutup);
      const p0 = m.projekte(kutup * 66 * RAD, lon * RAD), p1 = m.projekte(kutup * (72 + dalga * 7) * RAD, lon * RAD);
      if (p0.z <= 0.02 || p1.z <= 0.02) continue;
      const h = tema === "mavi" ? 120 + dalga * 70 : 340 + dalga * 40; // yeşil→mor / kırmızı→pembe
      const g = ctx.createLinearGradient(cx + p0.x * R, cy - p0.y * R, cx + p1.x * R, cy - p1.y * R);
      g.addColorStop(0, `hsla(${h},90%,60%,${0.5 * guc * dalga})`); g.addColorStop(1, `hsla(${h + 50},90%,65%,0)`);
      ctx.strokeStyle = g; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(cx + p0.x * R, cy - p0.y * R); ctx.lineTo(cx + p1.x * R, cy - p1.y * R); ctx.stroke();
    }
  }
}

function yagmurCiz(ctx: CanvasRenderingContext2D, e: Efektler, S: number, tema: Tema) {
  ctx.save(); ctx.font = "13px monospace"; const sutun = 28, w = S / sutun;
  for (let i = 0; i < sutun; i++) {
    const hiz = 90 + ((i * 53) % 120), y0 = ((e.zaman * hiz + i * 97) % (S + 200)) - 100;
    for (let k = 0; k < 9; k++) {
      ctx.fillStyle = tema === "mavi" ? `rgba(0,255,200,${(1 - k / 9) * 0.6 * Math.min(1, e.yagmur)})` : `rgba(255,90,60,${(1 - k / 9) * 0.6 * Math.min(1, e.yagmur)})`;
      ctx.fillText(KARAKTER[(i * 7 + k * 3 + Math.floor(e.zaman * 8)) % KARAKTER.length], i * w, y0 - k * 14);
    }
  }
  ctx.restore();
}

function glitchCiz(ctx: CanvasRenderingContext2D, siddet: number, S: number, t: number) {
  const c = ctx.canvas, n = 4 + Math.round(siddet * 4);
  for (let i = 0; i < n; i++) {
    const y = ((Math.sin(t * 91 + i * 13.7) * 0.5 + 0.5) * (S - 20)) | 0, h = 4 + ((i * 11) % 14), dx = (Math.sin(t * 53 + i * 5.1) * 26 * siddet) | 0;
    ctx.drawImage(c, 0, y, S, h, dx, y, S, h);
  }
  ctx.fillStyle = `rgba(255,0,80,${0.05 * siddet})`; ctx.fillRect(0, 0, S, S);
}

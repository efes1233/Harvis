// El hareketleri -> simülasyon komutları köprüsü.
import type { JestOlayi } from "../hands/gestures.ts";
import type { Motor } from "./motor.ts";
import { senaryoKurIstemci } from "./senaryo.ts";

export type Bildirim = (mesaj: string, ses?: "pinch" | "bip" | "uyanma") => void;

export function jestUygula(m: Motor, o: JestOlayi, bildir: Bildirim = () => {}): void {
  switch (o.tip) {
    case "pinch_basla": m.tutuyor = true; bildir("Seçim", "pinch"); break;
    case "pinch_bitir": m.tutuyor = false; break;
    case "grab_basla": m.tutuyor = true; m.otoDonus = false; m.velLon = 0; m.odakHedef = null; bildir("Kavrandı", "bip"); break;
    case "grab_birak": m.tutuyor = false; bildir("Bırakıldı"); break;
    case "surukle": m.surukle(o.dx * 4.2 / Math.max(0.6, m.zoom), -o.dy * 3.2 / Math.max(0.6, m.zoom)); m.velLon = -o.dx * 4.2; break;
    case "yakinlastir": m.zoomOran(o.oran); break;
    case "swipe": {
      const v = 1.6;
      if (o.yon === "sol") m.velLon = -v; else if (o.yon === "sag") m.velLon = v;
      else if (o.yon === "yukari") m.velLat = v * 0.5; else m.velLat = -v * 0.5;
      m.otoDonus = false; m.odakHedef = null; bildir(`Savurma: ${o.yon}`, "bip"); break;
    }
    case "it":
      if (o.yumruk) {
        const c = m.ekrandan(0, 0);
        if (c) { m.senaryoBaslat(senaryoKurIstemci("meteor", c.lat / (Math.PI / 180), c.lon / (Math.PI / 180))); bildir("Meteor tetiklendi", "uyanma"); }
      } else { m.yakinlas(1.5); bildir("Yaklaşılıyor", "pinch"); }
      break;
    case "cek": m.uzaklas(1.5); bildir("Uzaklaşılıyor", "pinch"); break;
  }
}

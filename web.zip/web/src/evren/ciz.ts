// Canvas çizim: piksel-piksel küre, atmosfer, ızgara, şehir işaretleri, etki halkaları, meteor izi, yıldızlar.
import { Motor, daireNoktalari, RAD } from "./motor.ts";

export type Doku = { w: number; h: number; d: Uint8ClampedArray };
export type Yildiz = { ra: number; dec: number; mag: number; k: number };
export type SehirNokta = { ad: string; lat: number; lon: number };

export function dokuOku(img: CanvasImageSource, w: number, h: number): Doku {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d", { willReadFrequently: true })!;
  x.drawImage(img, 0, 0, w, h);
  return { w, h, d: x.getImageData(0, 0, w, h).data };
}

const ISIK = (() => { const v = [-0.45, 0.4, 0.8]; const n = Math.hypot(...v); return v.map((a) => a / n); })();

export function kureCiz(ctx: CanvasRenderingContext2D, m: Motor, gun: Doku | null, gece: Doku | null, bulut: Doku | null, S: number, tema: "mavi" | "kirmizi") {
  const cx = S / 2, cy = S / 2, R = S * 0.36 * m.zoom;
  const img = ctx.createImageData(S, S), out = img.data;
  const cp = Math.cos(m.lat), sp = Math.sin(m.lat), bulutKayma = (performance.now() / 1000) * 0.004;
  const y0 = Math.max(0, Math.floor(cy - R)), y1 = Math.min(S, Math.ceil(cy + R));
  const x0 = Math.max(0, Math.floor(cx - R)), x1 = Math.min(S, Math.ceil(cx + R));
  for (let py = y0; py < y1; py++) {
    const ny = (cy - py) / R;
    for (let px = x0; px < x1; px++) {
      const nx = (px - cx) / R, d2 = nx * nx + ny * ny;
      if (d2 > 1) continue;
      const nz = Math.sqrt(1 - d2);
      const yy = ny * cp + nz * sp, zz = -ny * sp + nz * cp;
      const lat = Math.asin(yy), lon = Math.atan2(nx, zz) + m.lon;
      let u = (lon / (2 * Math.PI) + 0.5) % 1; if (u < 0) u += 1;
      const v = 0.5 - lat / Math.PI;
      const lamb = nx * ISIK[0] + ny * ISIK[1] + nz * ISIK[2];
      const gunIsik = Math.max(0, Math.min(1, lamb * 1.6 + 0.35));
      const i = (py * S + px) * 4;
      let r = 20, g = 60, b = 110;
      if (gun) { const o = (Math.min(gun.h - 1, (v * gun.h) | 0) * gun.w + Math.min(gun.w - 1, (u * gun.w) | 0)) * 4; r = gun.d[o]; g = gun.d[o + 1]; b = gun.d[o + 2]; }
      r *= gunIsik; g *= gunIsik; b *= gunIsik;
      if (gece && gunIsik < 0.5) { const o = (Math.min(gece.h - 1, (v * gece.h) | 0) * gece.w + Math.min(gece.w - 1, (u * gece.w) | 0)) * 4; const k = (0.5 - gunIsik) * 2; r += gece.d[o] * k; g += gece.d[o + 1] * k; b += gece.d[o + 2] * k * 0.6; }
      if (bulut) { const uu = (u + bulutKayma) % 1; const o = (Math.min(bulut.h - 1, (v * bulut.h) | 0) * bulut.w + Math.min(bulut.w - 1, (uu * bulut.w) | 0)) * 4; const a = (bulut.d[o + 3] / 255) * 0.2 * gunIsik; r += (255 - r) * a; g += (255 - g) * a; b += (255 - b) * a; }
      const kenar = Math.pow(1 - nz, 2.2);
      const l0 = (r + g + b) / 3, l = Math.min(235, l0 < 40 ? l0 * 0.6 : 24 + (l0 - 40) * 2.4);
      if (tema === "mavi") { r = l * 0.3; g = l * 0.95 + kenar * 60; b = l * 1.2 + kenar * 140; }
      else { r = l * 0.95 + kenar * 120; g = l * 0.22; b = l * 0.18; }
      out[i] = r > 255 ? 255 : r; out[i + 1] = g > 255 ? 255 : g; out[i + 2] = b > 255 ? 255 : b; out[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  // Atmosfer parıltısı
  const renk = tema === "mavi" ? "0,220,255" : "255,70,60";
  const nefes = 1 + 0.012 * Math.sin(performance.now() / 900);
  const gr = ctx.createRadialGradient(cx, cy, R * 0.96, cx, cy, R * 1.12 * nefes);
  gr.addColorStop(0, `rgba(${renk},0.55)`); gr.addColorStop(1, `rgba(${renk},0)`);
  ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, R * 1.12 * nefes, 0, Math.PI * 2); ctx.fill();
}

export function yildizCiz(ctx: CanvasRenderingContext2D, m: Motor, y: Yildiz[], S: number) {
  const cx = S / 2, cy = S / 2, ol = S * 0.62;
  const cp = Math.cos(m.lat * 0.3), sp = Math.sin(m.lat * 0.3), kl = m.lon * 0.3;
  for (let i = 0; i < y.length; i++) {
    const s = y[i], dec = s.dec * RAD, dl = s.ra * RAD - kl, c = Math.cos(dec);
    const x0 = c * Math.sin(dl), y0 = Math.sin(dec), z0 = c * Math.cos(dl);
    const yy = y0 * cp - z0 * sp, zz = y0 * sp + z0 * cp;
    if (zz < 0) continue;
    const px = cx + x0 * ol * 1.6, py = cy - yy * ol * 1.6;
    if (px < 0 || px > S || py < 0 || py > S) continue;
    const a = Math.max(0.12, 1 - s.mag / 7) * (0.7 + 0.3 * Math.sin(performance.now() / 600 + i * 1.7)), w = s.mag < 2 ? 1.8 : 1;
    ctx.fillStyle = s.k > 9000 ? `rgba(170,200,255,${a})` : s.k < 4000 ? `rgba(255,200,160,${a})` : `rgba(255,255,255,${a})`;
    ctx.fillRect(px, py, w, w);
  }
}

export function izgaraCiz(ctx: CanvasRenderingContext2D, m: Motor, S: number, tema: "mavi" | "kirmizi") {
  const R = S * 0.36 * m.zoom, cx = S / 2, cy = S / 2;
  ctx.lineWidth = 1; ctx.strokeStyle = tema === "mavi" ? "rgba(0,229,255,0.22)" : "rgba(255,80,60,0.22)";
  for (let la = -60; la <= 60; la += 30) cizgi(ctx, m, Array.from({ length: 73 }, (_, i) => ({ lat: la * RAD, lon: (i * 5 - 180) * RAD })), cx, cy, R);
  for (let lo = -180; lo < 180; lo += 30) cizgi(ctx, m, Array.from({ length: 37 }, (_, i) => ({ lat: (i * 5 - 90) * RAD, lon: lo * RAD })), cx, cy, R);
}

function cizgi(ctx: CanvasRenderingContext2D, m: Motor, pts: { lat: number; lon: number }[], cx: number, cy: number, R: number, kapat = false) {
  ctx.beginPath(); let acik = false;
  for (const p of pts) {
    const q = m.projekte(p.lat, p.lon);
    if (q.z <= 0) { acik = false; continue; }
    const x = cx + q.x * R, y = cy - q.y * R;
    if (!acik) { ctx.moveTo(x, y); acik = true; } else ctx.lineTo(x, y);
  }
  if (kapat) ctx.closePath();
  ctx.stroke();
}

export function sehirCiz(ctx: CanvasRenderingContext2D, m: Motor, sehirler: SehirNokta[], S: number, tema: "mavi" | "kirmizi") {
  const R = S * 0.36 * m.zoom, cx = S / 2, cy = S / 2;
  ctx.font = "11px 'Share Tech Mono', monospace"; ctx.textBaseline = "middle";
  for (const s of sehirler) {
    const q = m.projekte(s.lat * RAD, s.lon * RAD);
    if (q.z < 0.15) continue;
    const x = cx + q.x * R, y = cy - q.y * R;
    ctx.fillStyle = tema === "mavi" ? "#7df9ff" : "#ff8a80"; ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
    const nabiz = ((performance.now() / 1500 + s.lon * 0.013) % 1); ctx.globalAlpha = (1 - nabiz) * 0.5 * q.z; ctx.strokeStyle = ctx.fillStyle; ctx.beginPath(); ctx.arc(x, y, 2 + nabiz * 9, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
    if (m.zoom > 1.25) { ctx.globalAlpha = Math.min(1, q.z * 1.2); ctx.fillText(s.ad, x + 6, y); ctx.globalAlpha = 1; }
  }
}

export function etkiCiz(ctx: CanvasRenderingContext2D, m: Motor, S: number) {
  if (!m.senaryo) return;
  const R = S * 0.36 * m.zoom, cx = S / 2, cy = S / 2, s = m.senaryo;
  const hedef = m.projekte(s.lat * RAD, s.lon * RAD);
  const hx = cx + hedef.x * R, hy = cy - hedef.y * R;
  if (m.evre === 0 && hedef.z > 0) {
    // Meteor izi: uzaydan hedefe
    const p = m.yaklasmaOrani, bx = hx + 260 * (1 - p), by = hy - 360 * (1 - p);
    const g = ctx.createLinearGradient(bx, by, bx + 90 * (1 - p), by - 130 * (1 - p));
    g.addColorStop(0, "rgba(255,220,150,1)"); g.addColorStop(1, "rgba(255,120,0,0)");
    ctx.strokeStyle = g; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + 90 * (1 - p), by - 130 * (1 - p)); ctx.stroke();
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(bx, by, 4 + p * 3, 0, 7); ctx.fill();
  }
  const hl = m.halkalar();
  const enBuyukPx = ((m.etki?.etkiYaricapKm ?? 0) / 6371) * R;
  const f = enBuyukPx > 0 && enBuyukPx < 46 ? 46 / enBuyukPx : 1; // küçük etkiler görünür kalsın
  for (const h of hl) {
    ctx.strokeStyle = h.renk; ctx.globalAlpha = h.alfa * 0.9; ctx.lineWidth = 2.5;
    cizgi(ctx, m, daireNoktalari(s.lat, s.lon, h.yaricapKm * f), cx, cy, R);
    ctx.globalAlpha = 1;
  }
  if (f > 1 && hl.length && hedef.z > 0) { ctx.fillStyle = "rgba(255,255,255,.7)"; ctx.font = "10px monospace"; ctx.fillText(`etki alanı görsel ölçek ×${f.toFixed(0)}`, hx + 14, hy + 62); }
  if (hedef.z > 0) {
    ctx.strokeStyle = "#ff4d4d"; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(hx, hy, 10 + (m.t * 10) % 14, 0, 7); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx - 18, hy); ctx.lineTo(hx + 18, hy); ctx.moveTo(hx, hy - 18); ctx.lineTo(hx, hy + 18); ctx.stroke();
  }
  if (m.parlama > 0) { ctx.fillStyle = `rgba(255,240,220,${m.parlama * 0.45})`; ctx.fillRect(0, 0, S, S); }
}

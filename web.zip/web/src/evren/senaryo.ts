import type { Senaryo } from "../../../shared/types.ts";

export function senaryoKurIstemci(tur: Senaryo["tur"], lat: number, lon: number, p: Record<string, number> = {}): Senaryo {
  const varsayilan: Record<string, Record<string, number>> = { meteor: { cap: 300, hiz: 20, aci: 45, yogunluk: 3000 }, deprem: { mw: 7.4 }, tsunami: { mw: 8.5, derinlik: 4000, mesafe: 3000 }, gunes: { sinif: 4, sayi: 5 }, volkan: { vei: 6 } };
  return { id: `jest-${tur}-${Date.now()}`, ad: `${tur} @ ${lat.toFixed(1)}, ${lon.toFixed(1)}`, tur, lat, lon, parametreler: { ...varsayilan[tur], ...p }, aciklama: "Jest ile oluşturuldu" };
}

export async function senaryolariGetir(taban = ""): Promise<Senaryo[]> {
  const r = await fetch(`${taban}/api/senaryolar`);
  return r.ok ? ((await r.json()) as Senaryo[]) : [];
}

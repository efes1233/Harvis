// Görsel efekt motoru (DOM'dan bağımsız). Koordinatlar normalize: (0,0) sol-üst, (1,1) sağ-alt.
import type { EfektAdi } from "../../../shared/film.ts";

export type Parcacik = { x: number; y: number; vx: number; vy: number; omur: number; max: number; boyut: number; renk: string; g: number };
export type Simsek = { pts: { x: number; y: number }[]; omur: number };
export type SokDalgasi = { x: number; y: number; t: number; siddet: number };
export type Kuyruklu = { x: number; y: number; vx: number; vy: number; omur: number };
export type Nokta = { x: number; y: number };

export class Efektler {
  sarsinti = 0; glitch = 0; parlama = 0;
  aurora = 0.18;            // taban parıltı; efektle yükselir
  tarama = -1;              // -1 = kapalı, 0..1 = tarama çizgisi konumu
  yagmur = 0;               // kalan saniye
  parcaciklar: Parcacik[] = []; simsekler: Simsek[] = []; sokDalgalari: SokDalgasi[] = []; kuyruklular: Kuyruklu[] = [];
  zaman = 0;
  private sonKuyruklu = 0;
  rastgele: () => number;
  constructor(rastgele: () => number = Math.random) { this.rastgele = rastgele; }

  private r(a: number, b: number) { return a + (b - a) * this.rastgele(); }

  tetikle(ad: EfektAdi, siddet = 1, hedef: Nokta = { x: 0.5, y: 0.5 }) {
    const s = Math.max(0.1, Math.min(2, siddet));
    switch (ad) {
      case "sarsinti": this.sarsinti = Math.max(this.sarsinti, Math.min(1.6, s)); break;
      case "parlama": this.parlama = Math.max(this.parlama, Math.min(1, s)); break;
      case "glitch": this.glitch = Math.max(this.glitch, s); break;
      case "aurora": this.aurora = Math.min(2, Math.max(this.aurora, s)); break;
      case "tarama": this.tarama = 0; break;
      case "yagmur": this.yagmur = 6 * s; break;
      case "sok_dalgasi": this.sokDalgalari.push({ x: hedef.x, y: hedef.y, t: 0, siddet: s }); break;
      case "kivilcim": {
        const n = Math.round(70 * s);
        for (let i = 0; i < n; i++) { const a = this.r(0, 6.2832), v = this.r(0.1, 0.65) * s; this.ekle({ x: hedef.x, y: hedef.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, omur: 0, max: this.r(0.5, 1.4), boyut: this.r(1, 2.6), renk: this.rastgele() > 0.5 ? "#ffd166" : "#ff7b00", g: 0 }); }
        break;
      }
      case "kor": {
        const n = Math.round(45 * s);
        for (let i = 0; i < n; i++) { const a = this.r(-2.6, -0.5), v = this.r(0.15, 0.5) * s; this.ekle({ x: hedef.x, y: hedef.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, omur: 0, max: this.r(1.4, 3), boyut: this.r(1.5, 3.8), renk: this.rastgele() > 0.4 ? "#ff4d2e" : "#ffb703", g: 0.55 }); }
        break;
      }
      case "simsek": {
        const n = 1 + Math.round(s);
        for (let k = 0; k < n; k++) {
          const bx = this.r(0.1, 0.9), pts: Nokta[] = [{ x: bx, y: 0 }], ty = hedef.y, adim = 9;
          for (let i = 1; i <= adim; i++) pts.push({ x: bx + (hedef.x - bx) * (i / adim) + (i < adim ? this.r(-0.05, 0.05) : 0), y: (ty * i) / adim });
          this.simsekler.push({ pts, omur: 0.35 });
        }
        this.parlama = Math.max(this.parlama, 0.35);
        break;
      }
      case "kuyruklu": this.kuyrukluEkle(); break;
    }
  }

  private ekle(p: Parcacik) { if (this.parcaciklar.length < 1200) this.parcaciklar.push(p); }
  private kuyrukluEkle() {
    const sol = this.rastgele() > 0.5, y = this.r(0.02, 0.35);
    this.kuyruklular.push({ x: sol ? -0.05 : 1.05, y, vx: (sol ? 1 : -1) * this.r(0.25, 0.4), vy: this.r(0.05, 0.16), omur: 3.5 });
  }

  adim(dt: number) {
    dt = Math.min(0.1, Math.max(0, dt)); this.zaman += dt;
    this.sarsinti *= Math.exp(-dt * 2.4); if (this.sarsinti < 0.005) this.sarsinti = 0;
    this.glitch = Math.max(0, this.glitch - dt * 1.8); this.parlama = Math.max(0, this.parlama - dt * 1.6);
    this.aurora += (0.18 - this.aurora) * Math.min(1, dt * 0.18);
    if (this.tarama >= 0) { this.tarama += dt / 2; if (this.tarama > 1) this.tarama = -1; }
    this.yagmur = Math.max(0, this.yagmur - dt);
    for (const p of this.parcaciklar) { p.omur += dt; p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 1 - dt * 0.6; }
    this.parcaciklar = this.parcaciklar.filter((p) => p.omur < p.max);
    for (const s of this.simsekler) s.omur -= dt; this.simsekler = this.simsekler.filter((s) => s.omur > 0);
    for (const d of this.sokDalgalari) d.t += dt; this.sokDalgalari = this.sokDalgalari.filter((d) => d.t < 2.2);
    for (const k of this.kuyruklular) { k.x += k.vx * dt; k.y += k.vy * dt; k.omur -= dt; } this.kuyruklular = this.kuyruklular.filter((k) => k.omur > 0);
    // Canlılık: ara sıra kendiliğinden kuyruklu yıldız
    if (this.zaman - this.sonKuyruklu > 22 && this.rastgele() < dt * 0.05) { this.kuyrukluEkle(); this.sonKuyruklu = this.zaman; }
  }

  /** Ekran sarsıntısı piksel ofseti. */
  sarsintiOfset(piksel = 10): Nokta {
    if (!this.sarsinti) return { x: 0, y: 0 };
    const k = this.sarsinti * piksel;
    return { x: Math.sin(this.zaman * 83) * k, y: Math.cos(this.zaman * 71) * k * 0.8 };
  }
  get aktifSayisi() { return this.parcaciklar.length + this.simsekler.length + this.sokDalgalari.length + this.kuyruklular.length; }
}

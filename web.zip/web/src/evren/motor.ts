// Evren motoru: kamera (yörünge), animasyon zaman çizelgesi ve küre geometrisi. DOM'dan bağımsız (Node'da test edilir).
import type { Senaryo } from "../../../shared/types.ts";
import { senaryoEtkisi, type Etki } from "../../../shared/fizik.ts";
import { Efektler, type Nokta } from "./efektler.ts";

export const RAD = Math.PI / 180;
export const DUNYA_KM = 6371;
export type Halka = { yaricapKm: number; alfa: number; renk: string };

export class Motor {
  lon = 35 * RAD;      // kamera merkezi boylamı
  lat = 25 * RAD;      // kamera merkezi enlemi
  zoom = 1;
  hedefZoom = 1;
  velLon = 0.04;       // otomatik dönüş (rad/s)
  velLat = 0;
  otoDonus = true;
  tutuyor = false;
  senaryo: Senaryo | null = null;
  etki: Etki | null = null;
  t = 0;               // senaryo zamanı (sn)
  odakHedef: { lat: number; lon: number } | null = null;
  parlama = 0;
  olaylar: string[] = [];
  efekt = new Efektler();
  yakinlasZoom = { min: 0.6, max: 4.5 };

  // ---- Kamera komutları ----
  yakinlas(f = 1.35) { this.hedefZoom = Math.min(this.yakinlasZoom.max, this.hedefZoom * f); }
  uzaklas(f = 1.35) { this.hedefZoom = Math.max(this.yakinlasZoom.min, this.hedefZoom / f); }
  zoomOran(o: number) { this.hedefZoom = Math.min(this.yakinlasZoom.max, Math.max(this.yakinlasZoom.min, this.hedefZoom * o)); }
  sifirla() { this.hedefZoom = 1; this.odakHedef = null; this.senaryo = null; this.etki = null; this.otoDonus = true; this.velLon = 0.04; this.velLat = 0; this.lat = 25 * RAD; this.parlama = 0; }
  dondur(velRad = 0.5) { this.velLon += velRad; this.otoDonus = true; }
  surukle(dLon: number, dLat: number) { this.lon -= dLon; this.lat = clamp(this.lat + dLat, -85 * RAD, 85 * RAD); this.odakHedef = null; }
  durdur() { this.velLon = 0; this.velLat = 0; this.otoDonus = false; }
  odaklan(latDeg: number, lonDeg: number, zoom = 2) { this.odakHedef = { lat: latDeg * RAD, lon: lonDeg * RAD }; this.hedefZoom = zoom; this.velLon = 0; this.otoDonus = false; }

  senaryoBaslat(s: Senaryo) {
    this.senaryo = s; this.etki = senaryoEtkisi(s.tur, s.parametreler); this.t = 0; this.parlama = 0;
    this.olaylar = [`basla:${s.tur}`];
    if (s.lat || s.lon) this.odaklan(s.lat, s.lon, clamp(7.2 - 1.9 * Math.log10(this.etki.etkiYaricapKm + 1), 1.4, 4.4));
  }

  /** Senaryo evresi: 0 yaklaşma, 1 çarpma/yayılma, 2 sönüm */
  get evre(): 0 | 1 | 2 | -1 {
    if (!this.senaryo) return -1;
    return this.t < 3 ? 0 : this.t < 12 ? 1 : 2;
  }
  get yaklasmaOrani() { return Math.min(1, this.t / 3); }

  halkalar(): Halka[] {
    if (!this.senaryo || !this.etki || this.t < 3) return [];
    const k = this.t - 3, maxR = this.etki.etkiYaricapKm;
    const renkler = this.senaryo.tur === "gunes" ? ["#ffd166", "#ff9f1c", "#ff5400"] : this.senaryo.tur === "tsunami" ? ["#4cc9f0", "#4895ef", "#4361ee"] : ["#ff4d4d", "#ff9f1c", "#ffd166"];
    return [1, 0.62, 0.3].map((f, i) => {
      const gecikme = i * 0.6, p = Math.min(1, Math.max(0, (k - gecikme) / 7));
      const ease = 1 - (1 - p) ** 3;
      return { yaricapKm: maxR * f * ease, alfa: Math.max(0, 1 - Math.max(0, k - 7) / 9) * (p > 0 ? 1 : 0), renk: renkler[i] };
    }).filter((h) => h.yaricapKm > 0 && h.alfa > 0);
  }

  adim(dt: number) {
    dt = Math.min(0.1, Math.max(0, dt));
    this.zoom += (this.hedefZoom - this.zoom) * Math.min(1, dt * 5);
    if (this.odakHedef) {
      let dl = this.odakHedef.lon - this.lon; dl = Math.atan2(Math.sin(dl), Math.cos(dl));
      this.lon += dl * Math.min(1, dt * 3.5); this.lat += (this.odakHedef.lat - this.lat) * Math.min(1, dt * 3.5);
    } else if (!this.tutuyor) {
      this.lon += this.velLon * dt; this.lat = clamp(this.lat + this.velLat * dt, -85 * RAD, 85 * RAD);
      if (!this.otoDonus) { this.velLon *= 1 - Math.min(1, dt * 1.5); this.velLat *= 1 - Math.min(1, dt * 1.5); }
      else this.velLon += (0.04 - this.velLon) * Math.min(1, dt * 0.5);
    }
    if (this.senaryo) {
      const onceki = this.t; this.t += dt;
      if (onceki < 3 && this.t >= 3) { this.parlama = 1; this.olaylar.push("carpma"); this.carpmaEfektleri(this.senaryo.tur); }
      if (this.t > 22) { this.olaylar.push("bitti"); this.senaryo = null; this.etki = null; this.t = 0; }
    }
    this.parlama = Math.max(0, this.parlama - dt * 1.6);
    this.efekt.adim(dt);
  }

  /** Senaryo hedefinin (yoksa merkezin) normalize tuval konumu. */
  hedefNorm(): Nokta {
    if (!this.senaryo) return { x: 0.5, y: 0.5 };
    const p = this.projekte(this.senaryo.lat * RAD, this.senaryo.lon * RAD);
    return { x: 0.5 + p.x * 0.36 * this.zoom, y: 0.5 - p.y * 0.36 * this.zoom };
  }
  private carpmaEfektleri(tur: string) {
    const h = this.hedefNorm(), e = this.efekt;
    switch (tur) {
      case "meteor": e.tetikle("sarsinti", 1.2); e.tetikle("parlama", 1); e.tetikle("sok_dalgasi", 1.2, h); e.tetikle("kivilcim", 1.2, h); e.tetikle("kor", 1, h); break;
      case "deprem": e.tetikle("sarsinti", 1.6); e.tetikle("sok_dalgasi", 1, h); e.tetikle("kor", 0.8, h); e.tetikle("glitch", 0.5); break;
      case "gunes": e.tetikle("aurora", 2); e.tetikle("simsek", 1.5, h); e.tetikle("parlama", 0.8); e.tetikle("glitch", 0.7); break;
      case "tsunami": e.tetikle("sok_dalgasi", 1.5, h); e.tetikle("sarsinti", 0.7); e.tetikle("yagmur", 0.6); break;
      case "volkan": e.tetikle("sarsinti", 0.9); e.tetikle("parlama", 0.7); e.tetikle("kivilcim", 1.4, h); e.tetikle("kor", 1.6, h); break;
    }
  }

  // ---- Küre geometrisi ----
  /** (lat,lon) -> görünüm koordinatı {x,y,z} birim küre; z>0 ise görünür. */
  projekte(lat: number, lon: number) {
    const dl = lon - this.lon, c = Math.cos(lat);
    const x = c * Math.sin(dl), y0 = Math.sin(lat), z0 = c * Math.cos(dl);
    const cp = Math.cos(this.lat), sp = Math.sin(this.lat);
    return { x, y: y0 * cp - z0 * sp, z: y0 * sp + z0 * cp };
  }
  /** Birim küre görünüm koordinatı (nx, ny) -> lat/lon; küre dışındaysa null. */
  ekrandan(nx: number, ny: number) {
    const d2 = nx * nx + ny * ny; if (d2 > 1) return null;
    const nz = Math.sqrt(1 - d2), cp = Math.cos(this.lat), sp = Math.sin(this.lat);
    const yy = ny * cp + nz * sp, zz = -ny * sp + nz * cp;
    return { lat: Math.asin(Math.max(-1, Math.min(1, yy))), lon: Math.atan2(nx, zz) + this.lon };
  }
}

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** (lat,lon) merkezli, açısal yarıçapı km cinsinden verilen çemberin noktaları. */
export function daireNoktalari(latDeg: number, lonDeg: number, yaricapKm: number, n = 96): { lat: number; lon: number }[] {
  const d = Math.min(yaricapKm / DUNYA_KM, Math.PI), la = latDeg * RAD, lo = lonDeg * RAD, pts = [];
  for (let i = 0; i <= n; i++) {
    const b = (i / n) * 2 * Math.PI;
    const lat2 = Math.asin(Math.sin(la) * Math.cos(d) + Math.cos(la) * Math.sin(d) * Math.cos(b));
    const lon2 = lo + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(la), Math.cos(d) - Math.sin(la) * Math.sin(lat2));
    pts.push({ lat: lat2, lon: lon2 });
  }
  return pts;
}

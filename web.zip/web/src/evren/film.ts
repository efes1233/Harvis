// Film oynatıcı: yapay zekâların yazdığı zaman çizelgesini motor üzerinde oynatır.
import type { Film, FilmOlay } from "../../../shared/film.ts";
import type { Motor } from "./motor.ts";
import { senaryoKurIstemci } from "./senaryo.ts";

export type FilmHedef = { motor: Motor; anlat: (m: string) => void; tema: (t: "mavi" | "kirmizi") => void; bitti?: () => void };
const YAKLASMA_SN = 3; // motorda çarpma, senaryo başlangıcından 3 sn sonradır

/** Senaryo olayı "çarpma anı" kabul edilir; yaklaşma evresi için 3 sn erken başlatılır. */
export function zamanla(film: Film): FilmOlay[] {
  return film.olaylar.map((o) => (o.tip === "senaryo" ? { ...o, t: Math.max(0, o.t - YAKLASMA_SN) } : o)).sort((a, b) => a.t - b.t);
}

export class FilmOynatici {
  film: Film | null = null; t = 0; calisiyor = false;
  private olaylar: FilmOlay[] = []; private i = 0;
  baslat(f: Film) { this.film = f; this.olaylar = zamanla(f); this.i = 0; this.t = 0; this.calisiyor = true; }
  durdur() { this.calisiyor = false; }
  get oran() { return this.film ? Math.min(1, this.t / this.film.sure) : 0; }

  adim(dt: number, h: FilmHedef) {
    if (!this.calisiyor || !this.film) return;
    this.t += dt;
    while (this.i < this.olaylar.length && this.olaylar[this.i].t <= this.t) this.uygula(this.olaylar[this.i++], h);
    if (this.t >= this.film.sure) { this.calisiyor = false; h.bitti?.(); }
  }

  private uygula(o: FilmOlay, { motor, anlat, tema }: FilmHedef) {
    switch (o.tip) {
      case "anlat": anlat(o.metin); break;
      case "kamera": motor.odaklan(o.lat, o.lon, o.zoom); break;
      case "senaryo": motor.senaryoBaslat(senaryoKurIstemci(o.tur, o.lat, o.lon, o.parametreler)); break;
      case "efekt": motor.efekt.tetikle(o.ad, o.siddet, motor.hedefNorm()); break;
      case "tema": tema(o.tema); break;
    }
  }
}

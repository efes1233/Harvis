import React from "react";
import { createRoot } from "react-dom/client";
import Mark2 from "./mark2/Mark2.tsx";
import "./mark2/mark2.css";

createRoot(document.getElementById("kok")!).render(<Mark2 />);

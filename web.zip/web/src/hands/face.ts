// Yüz takibi: kullanıcının ekrana bakışını/konumunu (paralaks için) MediaPipe FaceDetector ile izler.
const SURUM = "0.10.14";
const CDN = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${SURUM}`;
const MODEL = "https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite";

export type YuzDurumu = { var: boolean; x: number; y: number; boyut: number };
export const YUZ_YOK: YuzDurumu = { var: false, x: 0.5, y: 0.5, boyut: 0 };

/** Algılayıcı çıktısındaki sınırlayıcı kutuyu normalize merkez/boyuta çevirir. */
export function kutuyuDurumaCevir(kutu: { originX: number; originY: number; width: number; height: number }, vw: number, vh: number): YuzDurumu {
  return { var: true, x: (kutu.originX + kutu.width / 2) / vw, y: (kutu.originY + kutu.height / 2) / vh, boyut: kutu.width / vw };
}

export class YuzTakipci {
  private det: { detectForVideo(v: HTMLVideoElement, t: number): { detections: { boundingBox?: { originX: number; originY: number; width: number; height: number } }[] }; close(): void } | null = null;
  durum: YuzDurumu = YUZ_YOK;
  async baslat() {
    const mod = await import(/* @vite-ignore */ `${CDN}/vision_bundle.mjs`);
    const vision = await mod.FilesetResolver.forVisionTasks(`${CDN}/wasm`);
    this.det = await mod.FaceDetector.createFromOptions(vision, { baseOptions: { modelAssetPath: MODEL, delegate: "GPU" }, runningMode: "VIDEO" });
  }
  guncelle(video: HTMLVideoElement): YuzDurumu {
    if (!this.det || video.readyState < 2) return this.durum;
    const r = this.det.detectForVideo(video, performance.now());
    const b = r.detections[0]?.boundingBox;
    this.durum = b ? kutuyuDurumaCevir(b, video.videoWidth, video.videoHeight) : YUZ_YOK;
    return this.durum;
  }
  durdur() { this.det?.close(); this.det = null; }
}

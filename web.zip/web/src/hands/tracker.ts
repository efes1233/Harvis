// Web kamerasından el takibi: MediaPipe Tasks Vision (CDN'den yüklenir; internet gerekir).
import type { El } from "./gestures.ts";

const SURUM = "0.10.14";
const CDN = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${SURUM}`;
const MODEL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

export type TakipSonucu = { eller: El[]; t: number };

export class ElTakipci {
  private video: HTMLVideoElement | null = null;
  private akim: MediaStream | null = null;
  private landmarker: { detectForVideo(v: HTMLVideoElement, t: number): { landmarks: El[] }; close(): void } | null = null;
  private calisiyor = false;
  private dinleyici: (s: TakipSonucu) => void = () => {};
  fps = 0;

  sonuc(cb: (s: TakipSonucu) => void) { this.dinleyici = cb; }
  get aktif() { return this.calisiyor; }

  async baslat(video: HTMLVideoElement): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Bu tarayıcı kamera erişimini desteklemiyor (HTTPS/localhost gerekir).");
    this.akim = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: "user" }, audio: false });
    video.srcObject = this.akim; await video.play(); this.video = video;
    try {
      const mod = await import(/* @vite-ignore */ `${CDN}/vision_bundle.mjs`);
      const vision = await mod.FilesetResolver.forVisionTasks(`${CDN}/wasm`);
      this.landmarker = await mod.HandLandmarker.createFromOptions(vision, { baseOptions: { modelAssetPath: MODEL, delegate: "GPU" }, runningMode: "VIDEO", numHands: 2 });
    } catch (e) {
      this.durdur();
      throw new Error("El takibi modeli yüklenemedi (internet bağlantısı gerekli): " + (e as Error).message);
    }
    this.calisiyor = true; this.dongu();
  }

  private dongu = () => {
    if (!this.calisiyor || !this.video || !this.landmarker) return;
    const t = performance.now();
    if (this.video.readyState >= 2) {
      try { const r = this.landmarker.detectForVideo(this.video, t); this.dinleyici({ eller: r.landmarks as El[], t }); } catch { /* kare atla */ }
      this.fps = Math.round(1000 / Math.max(1, performance.now() - t + 16));
    }
    requestAnimationFrame(this.dongu);
  };

  durdur() {
    this.calisiyor = false;
    this.landmarker?.close(); this.landmarker = null;
    this.akim?.getTracks().forEach((t) => t.stop()); this.akim = null;
    if (this.video) this.video.srcObject = null;
  }
}

/** MediaPipe el iskeleti bağlantıları (çizim için). */
export const EL_BAGLANTILARI: [number, number][] = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]];

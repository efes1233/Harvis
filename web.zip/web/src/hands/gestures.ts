// Jest sınıflandırma: MediaPipe 21 nokta el iskeleti -> pinch / grab / open / swipe / push.
export type Nokta = { x: number; y: number; z?: number };
export type El = Nokta[]; // 21 nokta
export type Poz = "pinch" | "grab" | "open" | "point" | "none";
export type JestOlayi =
  | { tip: "pinch_basla" | "pinch_bitir" | "grab_basla" | "grab_birak" }
  | { tip: "swipe"; yon: "sol" | "sag" | "yukari" | "asagi" }
  | { tip: "it" | "cek"; yumruk: boolean }
  | { tip: "surukle"; dx: number; dy: number }
  | { tip: "yakinlastir"; oran: number };

export const dist = (a: Nokta, b: Nokta) => Math.hypot(a.x - b.x, a.y - b.y);
export const elOlcegi = (e: El) => Math.max(1e-6, dist(e[0], e[9]));
export const avucMerkezi = (e: El): Nokta => ({ x: (e[0].x + e[5].x + e[9].x + e[13].x + e[17].x) / 5, y: (e[0].y + e[5].y + e[9].y + e[13].y + e[17].y) / 5 });

export function parmakAcik(e: El, tip: 8 | 12 | 16 | 20): boolean {
  return dist(e[tip], e[0]) > dist(e[tip - 2], e[0]) * 1.08;
}
export function pinchOrani(e: El): number { return dist(e[4], e[8]) / elOlcegi(e); }

export function pozSinifla(e: El, oncekiPinch = false): Poz {
  const o = pinchOrani(e);
  if (o < (oncekiPinch ? 0.45 : 0.3)) return "pinch";
  const acik = ([8, 12, 16, 20] as const).filter((t) => parmakAcik(e, t)).length;
  if (acik === 0) return "grab";
  if (acik === 4) return "open";
  if (acik === 1 && parmakAcik(e, 8)) return "point";
  return "none";
}

export class JestMotoru {
  private poz: Poz = "none";
  private gecmis: { t: number; c: Nokta; s: number }[] = [];
  private sonSwipe = -1e9;
  private sonItme = -1e9;
  private oncekiMerkez: Nokta | null = null;
  swipeEsik = 0.3;
  itmeOrani = 1.3;

  get mevcutPoz() { return this.poz; }
  sifirla() { this.poz = "none"; this.gecmis = []; this.oncekiMerkez = null; }

  /** Tek el güncellemesi. t: milisaniye. */
  guncelle(e: El | null, t: number): JestOlayi[] {
    const out: JestOlayi[] = [];
    if (!e) { this.kapat(out); this.gecmis = []; this.oncekiMerkez = null; return out; }
    const yeni = pozSinifla(e, this.poz === "pinch");
    const c = avucMerkezi(e), s = elOlcegi(e);
    this.gecmis.push({ t, c, s });
    while (this.gecmis.length && t - this.gecmis[0].t > 450) this.gecmis.shift();

    if (yeni !== this.poz) {
      this.kapat(out);
      if (yeni === "pinch") out.push({ tip: "pinch_basla" });
      if (yeni === "grab") out.push({ tip: "grab_basla" });
      this.poz = yeni;
      this.oncekiMerkez = c;
    }
    if ((this.poz === "grab" || this.poz === "pinch") && this.oncekiMerkez) {
      const dx = c.x - this.oncekiMerkez.x, dy = c.y - this.oncekiMerkez.y;
      if (Math.abs(dx) + Math.abs(dy) > 1e-4) out.push({ tip: "surukle", dx, dy });
      this.oncekiMerkez = c;
    }
    if (this.gecmis.length >= 3) {
      const ilk = this.gecmis[0], son = this.gecmis[this.gecmis.length - 1];
      const dx = son.c.x - ilk.c.x, dy = son.c.y - ilk.c.y;
      if (this.poz === "open" && t - this.sonSwipe > 700 && Math.max(Math.abs(dx), Math.abs(dy)) > this.swipeEsik) {
        const yatay = Math.abs(dx) >= Math.abs(dy);
        // Ayna görüntüsü: kamera x ekseni kullanıcıya göre ters.
        out.push({ tip: "swipe", yon: yatay ? (dx > 0 ? "sol" : "sag") : dy > 0 ? "asagi" : "yukari" });
        this.sonSwipe = t; this.gecmis = [son];
      }
      const oran = son.s / Math.max(1e-6, ilk.s);
      if ((this.poz === "open" || this.poz === "grab") && t - this.sonItme > 900) {
        if (oran > this.itmeOrani) { out.push({ tip: "it", yumruk: this.poz === "grab" }); this.sonItme = t; this.gecmis = [son]; }
        else if (oran < 1 / this.itmeOrani) { out.push({ tip: "cek", yumruk: this.poz === "grab" }); this.sonItme = t; this.gecmis = [son]; }
      }
    }
    return out;
  }

  private kapat(out: JestOlayi[]) {
    if (this.poz === "pinch") out.push({ tip: "pinch_bitir" });
    if (this.poz === "grab") out.push({ tip: "grab_birak" });
    this.poz = "none";
  }
}

/** İki el pinch iken aradaki mesafe oranıyla yakınlaştır/uzaklaştır. */
export class IkiElZoom {
  private onceki: number | null = null;
  guncelle(a: El | null, b: El | null): JestOlayi | null {
    if (!a || !b || pinchOrani(a) > 0.45 || pinchOrani(b) > 0.45) { this.onceki = null; return null; }
    const d = dist(avucMerkezi(a), avucMerkezi(b));
    const o = this.onceki; this.onceki = d;
    return o && Math.abs(d / o - 1) > 0.005 ? { tip: "yakinlastir", oran: d / o } : null;
  }
}

// ---- Test/simülasyon için sentetik el üretici ----
export function sentetikEl(opts: { cx?: number; cy?: number; olcek?: number; acik?: boolean[]; pinch?: boolean } = {}): El {
  const { cx = 0.5, cy = 0.5, olcek = 0.2, acik = [true, true, true, true], pinch = false } = opts;
  const e: Nokta[] = Array.from({ length: 21 }, () => ({ x: cx, y: cy }));
  const P = (i: number, dx: number, dy: number) => (e[i] = { x: cx + dx * olcek, y: cy + dy * olcek });
  P(0, 0, 0.9); // bilek
  [[5, -0.5], [9, -0.1], [13, 0.3], [17, 0.7]].forEach(([i, dx], k) => {
    P(i, dx, -0.1); // MCP: bileğe uzaklık ~1 (9 numara)
    const a = acik[k];
    P(i + 1, dx, a ? -0.6 : -0.15); P(i + 2, dx, a ? -0.9 : -0.05); P(i + 3, dx, a ? -1.2 : 0.1);
  });
  P(1, -0.6, 0.6); P(2, -0.8, 0.4); P(3, -0.95, 0.2);
  if (pinch) { P(4, -0.52, -0.3); e[8] = { x: e[4].x + 0.005, y: e[4].y + 0.005 }; } else P(4, -1.3, 0.0);
  return e;
}

import React, { forwardRef, useEffect, useRef } from "react";
import { EL_BAGLANTILARI } from "./tracker.ts";
import type { El } from "./gestures.ts";

export type OnizlemeAPI = { cizEller(e: El[]): void };

/** Kamera önizlemesi + el iskeleti bindirmesi (ayna görüntü). */
const Onizleme = forwardRef<HTMLVideoElement, { aktif: boolean; eller: El[]; poz: string }>(({ aktif, eller, poz }, vref) => {
  const cv = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = cv.current; if (!c) return; const x = c.getContext("2d")!; x.clearRect(0, 0, c.width, c.height);
    x.strokeStyle = "#00e5ff"; x.fillStyle = "#ffd166"; x.lineWidth = 2;
    for (const e of eller) {
      for (const [a, b] of EL_BAGLANTILARI) { x.beginPath(); x.moveTo((1 - e[a].x) * c.width, e[a].y * c.height); x.lineTo((1 - e[b].x) * c.width, e[b].y * c.height); x.stroke(); }
      for (const p of e) { x.beginPath(); x.arc((1 - p.x) * c.width, p.y * c.height, 3, 0, 7); x.fill(); }
    }
  }, [eller]);
  return (
    <div className={`onizleme ${aktif ? "acik" : ""}`}>
      <video ref={vref} playsInline muted />
      <canvas ref={cv} width={320} height={240} />
      <span className="rozet">{aktif ? `EL: ${poz.toUpperCase()}` : "KAMERA KAPALI"}</span>
    </div>
  );
});
export default Onizleme;

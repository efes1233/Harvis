# cevir_aci_radyan_grad

aci: radyan ↔ grad çevirir

- **Anahtar sözcükler:** `radyan`, `grad`, `çevir`
- **Örnek girdi:** `10 radyan kaç grad çevir`
- **Beklenen çıktı içerir:** `636.6198`

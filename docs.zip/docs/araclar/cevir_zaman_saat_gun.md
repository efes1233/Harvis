# cevir_zaman_saat_gun

zaman: saat ↔ gün çevirir

- **Anahtar sözcükler:** `saat`, `gün`, `çevir`
- **Örnek girdi:** `10 saat kaç gün çevir`
- **Beklenen çıktı içerir:** `0.4166667`

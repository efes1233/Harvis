# cevir_basinc_kpa_mmhg

basinc: kilopascal ↔ mmHg çevirir

- **Anahtar sözcükler:** `kilopascal`, `kpa`, `mmhg`, `cıva`, `çevir`
- **Örnek girdi:** `10 kilopascal kaç mmhg çevir`
- **Beklenen çıktı içerir:** `75.00616`

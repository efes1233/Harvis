# cevir_uzunluk_km_ayak

uzunluk: kilometre ↔ ayak çevirir

- **Anahtar sözcükler:** `kilometre`, `km`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 kilometre kaç ayak çevir`
- **Beklenen çıktı içerir:** `32808.4`

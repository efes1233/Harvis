# cevir_veri_gb_tb

veri: gigabayt ↔ terabayt çevirir

- **Anahtar sözcükler:** `gigabayt`, `gb`, `terabayt`, `tb`, `çevir`
- **Örnek girdi:** `10 gigabayt kaç terabayt çevir`
- **Beklenen çıktı içerir:** `0.009765625`

# cevir_zaman_saat_hafta

zaman: saat ↔ hafta çevirir

- **Anahtar sözcükler:** `saat`, `hafta`, `çevir`
- **Örnek girdi:** `10 saat kaç hafta çevir`
- **Beklenen çıktı içerir:** `0.05952381`

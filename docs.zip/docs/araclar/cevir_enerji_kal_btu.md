# cevir_enerji_kal_btu

enerji: kalori ↔ BTU çevirir

- **Anahtar sözcükler:** `kalori`, `btu`, `çevir`
- **Örnek girdi:** `10 kalori kaç btu çevir`
- **Beklenen çıktı içerir:** `0.03965667`

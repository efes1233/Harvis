# cevir_hiz_mph_knot

hiz: mil/saat ↔ knot çevirir

- **Anahtar sözcükler:** `mph`, `mil/saat`, `knot`, `düğüm`, `çevir`
- **Örnek girdi:** `10 mph kaç knot çevir`
- **Beklenen çıktı içerir:** `8.689762`

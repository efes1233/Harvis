# cevir_alan_donum_akre

alan: dönüm ↔ akre çevirir

- **Anahtar sözcükler:** `dönüm`, `akre`, `acre`, `çevir`
- **Örnek girdi:** `10 dönüm kaç akre çevir`
- **Beklenen çıktı içerir:** `2.471054`

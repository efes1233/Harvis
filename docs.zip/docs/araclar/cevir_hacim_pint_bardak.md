# cevir_hacim_pint_bardak

hacim: pint ↔ su bardağı çevirir

- **Anahtar sözcükler:** `pint`, `bardak`, `çevir`
- **Örnek girdi:** `10 pint kaç bardak çevir`
- **Beklenen çıktı içerir:** `18.92706`

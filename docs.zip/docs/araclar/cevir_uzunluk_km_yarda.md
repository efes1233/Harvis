# cevir_uzunluk_km_yarda

uzunluk: kilometre ↔ yarda çevirir

- **Anahtar sözcükler:** `kilometre`, `km`, `yarda`, `yard`, `çevir`
- **Örnek girdi:** `10 kilometre kaç yarda çevir`
- **Beklenen çıktı içerir:** `10936.13`

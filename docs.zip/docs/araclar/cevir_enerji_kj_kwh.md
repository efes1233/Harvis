# cevir_enerji_kj_kwh

enerji: kilojoule ↔ kilovatsaat çevirir

- **Anahtar sözcükler:** `kilojoule`, `kj`, `kilovatsaat`, `kwh`, `çevir`
- **Örnek girdi:** `10 kilojoule kaç kilovatsaat çevir`
- **Beklenen çıktı içerir:** `0.002777778`

# karekok

Karekök hesaplar

- **Anahtar sözcükler:** `karekök`, `karekok`
- **Örnek girdi:** `144 karekök`
- **Beklenen çıktı içerir:** `12`

# cevir_basinc_kpa_bar

basinc: kilopascal ↔ bar çevirir

- **Anahtar sözcükler:** `kilopascal`, `kpa`, `bar`, `çevir`
- **Örnek girdi:** `10 kilopascal kaç bar çevir`
- **Beklenen çıktı içerir:** `0.1`

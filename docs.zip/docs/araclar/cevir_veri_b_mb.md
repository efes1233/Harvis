# cevir_veri_b_mb

veri: bayt ↔ megabayt çevirir

- **Anahtar sözcükler:** `bayt`, `byte`, `megabayt`, `mb`, `çevir`
- **Örnek girdi:** `10 bayt kaç megabayt çevir`
- **Beklenen çıktı içerir:** `0.000009536743`

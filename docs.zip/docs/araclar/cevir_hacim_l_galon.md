# cevir_hacim_l_galon

hacim: litre ↔ galon çevirir

- **Anahtar sözcükler:** `litre`, `galon`, `gallon`, `çevir`
- **Örnek girdi:** `10 litre kaç galon çevir`
- **Beklenen çıktı içerir:** `2.641721`

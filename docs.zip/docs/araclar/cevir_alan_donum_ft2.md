# cevir_alan_donum_ft2

alan: dönüm ↔ fitkare çevirir

- **Anahtar sözcükler:** `dönüm`, `fitkare`, `ft2`, `çevir`
- **Örnek girdi:** `10 dönüm kaç fitkare çevir`
- **Beklenen çıktı içerir:** `107639.1`

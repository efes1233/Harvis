# cevir_enerji_j_kcal

enerji: joule ↔ kilokalori çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `kilokalori`, `kcal`, `çevir`
- **Örnek girdi:** `10 joule kaç kilokalori çevir`
- **Beklenen çıktı içerir:** `0.002390057`

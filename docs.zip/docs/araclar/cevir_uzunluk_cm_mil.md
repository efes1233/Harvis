# cevir_uzunluk_cm_mil

uzunluk: santimetre ↔ mil çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `mil`, `mile`, `çevir`
- **Örnek girdi:** `10 santimetre kaç mil çevir`
- **Beklenen çıktı içerir:** `0.00006213712`

# cevir_veri_mb_gb

veri: megabayt ↔ gigabayt çevirir

- **Anahtar sözcükler:** `megabayt`, `mb`, `gigabayt`, `gb`, `çevir`
- **Örnek girdi:** `10 megabayt kaç gigabayt çevir`
- **Beklenen çıktı içerir:** `0.009765625`

# palindrom

Metnin palindrom olup olmadığını söyler

- **Anahtar sözcükler:** `palindrom`
- **Örnek girdi:** `palindrom mu kayak`
- **Beklenen çıktı içerir:** `Evet`

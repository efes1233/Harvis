# cevir_uzunluk_inc_denizmili

uzunluk: inç ↔ deniz mili çevirir

- **Anahtar sözcükler:** `inç`, `inch`, `inc`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 inç kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.000137149`

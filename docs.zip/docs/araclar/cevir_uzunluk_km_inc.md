# cevir_uzunluk_km_inc

uzunluk: kilometre ↔ inç çevirir

- **Anahtar sözcükler:** `kilometre`, `km`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 kilometre kaç inç çevir`
- **Beklenen çıktı içerir:** `393700.8`

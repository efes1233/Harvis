# cevir_uzunluk_m_mil

uzunluk: metre ↔ mil çevirir

- **Anahtar sözcükler:** `metre`, `mil`, `mile`, `çevir`
- **Örnek girdi:** `10 metre kaç mil çevir`
- **Beklenen çıktı içerir:** `0.006213712`

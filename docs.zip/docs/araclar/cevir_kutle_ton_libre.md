# cevir_kutle_ton_libre

kutle: ton ↔ libre çevirir

- **Anahtar sözcükler:** `ton`, `libre`, `pound`, `lb`, `çevir`
- **Örnek girdi:** `10 ton kaç libre çevir`
- **Beklenen çıktı içerir:** `22046.23`

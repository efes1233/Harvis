# cevir_veri_tb_bit

veri: terabayt ↔ bit çevirir

- **Anahtar sözcükler:** `terabayt`, `tb`, `bit`, `çevir`
- **Örnek girdi:** `10 terabayt kaç bit çevir`
- **Beklenen çıktı içerir:** `87960930222080`

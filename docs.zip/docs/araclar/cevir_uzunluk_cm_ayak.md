# cevir_uzunluk_cm_ayak

uzunluk: santimetre ↔ ayak çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 santimetre kaç ayak çevir`
- **Beklenen çıktı içerir:** `0.328084`

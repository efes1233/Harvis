# cevir_zaman_s_yil

zaman: saniye ↔ yıl çevirir

- **Anahtar sözcükler:** `saniye`, `yıl`, `sene`, `çevir`
- **Örnek girdi:** `10 saniye kaç yıl çevir`
- **Beklenen çıktı içerir:** `3.168809e-7`

# saat

Şu anki saati söyler

- **Anahtar sözcükler:** `saat kaç`, `saati söyle`, `saat`
- **Örnek girdi:** `saat kaç`
- **Beklenen çıktı içerir:** `Saat `

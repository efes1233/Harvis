# cevir_uzunluk_mm_mil

uzunluk: milimetre ↔ mil çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `mil`, `mile`, `çevir`
- **Örnek girdi:** `10 milimetre kaç mil çevir`
- **Beklenen çıktı içerir:** `0.000006213712`

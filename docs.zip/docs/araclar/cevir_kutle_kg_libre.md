# cevir_kutle_kg_libre

kutle: kilogram ↔ libre çevirir

- **Anahtar sözcükler:** `kilogram`, `kilo`, `kg`, `libre`, `pound`, `lb`, `çevir`
- **Örnek girdi:** `10 kilogram kaç libre çevir`
- **Beklenen çıktı içerir:** `22.04623`

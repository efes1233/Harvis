# cevir_hacim_ml_galon

hacim: mililitre ↔ galon çevirir

- **Anahtar sözcükler:** `mililitre`, `ml`, `galon`, `gallon`, `çevir`
- **Örnek girdi:** `10 mililitre kaç galon çevir`
- **Beklenen çıktı içerir:** `0.002641721`

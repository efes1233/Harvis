# uuid_uret

Rastgele UUID v4 üretir

- **Anahtar sözcükler:** `uuid`, `benzersiz kimlik`
- **Örnek girdi:** `uuid üret`
- **Beklenen çıktı içerir:** `UUID: `

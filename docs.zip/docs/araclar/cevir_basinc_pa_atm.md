# cevir_basinc_pa_atm

basinc: pascal ↔ atmosfer çevirir

- **Anahtar sözcükler:** `pascal`, `pa`, `atmosfer`, `atm`, `çevir`
- **Örnek girdi:** `10 pascal kaç atmosfer çevir`
- **Beklenen çıktı içerir:** `0.00009869233`

# cevir_uzunluk_mil_denizmili

uzunluk: mil ↔ deniz mili çevirir

- **Anahtar sözcükler:** `mil`, `mile`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 mil kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `8.689762`

# cevir_alan_m2_akre

alan: metrekare ↔ akre çevirir

- **Anahtar sözcükler:** `metrekare`, `m2`, `akre`, `acre`, `çevir`
- **Örnek girdi:** `10 metrekare kaç akre çevir`
- **Beklenen çıktı içerir:** `0.002471054`

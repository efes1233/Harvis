# cevir_sicaklik_c_f

sıcaklık: Santigrat ↔ Fahrenhayt çevirir

- **Anahtar sözcükler:** `santigrat`, `celsius`, `derece`, `fahrenhayt`, `fahrenheit`, `çevir`
- **Örnek girdi:** `100 santigrat kaç fahrenhayt`
- **Beklenen çıktı içerir:** `212`

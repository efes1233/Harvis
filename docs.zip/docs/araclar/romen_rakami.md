# romen_rakami

Sayıyı Roma rakamına çevirir

- **Anahtar sözcükler:** `roma rakamı`, `romen rakamı`, `romen`
- **Örnek girdi:** `1994 roma rakamı`
- **Beklenen çıktı içerir:** `MCMXCIV`

# cevir_sicaklik_c_k

sıcaklık: Santigrat ↔ Kelvin çevirir

- **Anahtar sözcükler:** `santigrat`, `celsius`, `derece`, `kelvin`, `çevir`
- **Örnek girdi:** `0 santigrat kaç kelvin`
- **Beklenen çıktı içerir:** `273.15`

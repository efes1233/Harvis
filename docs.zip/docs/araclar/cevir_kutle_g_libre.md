# cevir_kutle_g_libre

kutle: gram ↔ libre çevirir

- **Anahtar sözcükler:** `gram`, `libre`, `pound`, `lb`, `çevir`
- **Örnek girdi:** `10 gram kaç libre çevir`
- **Beklenen çıktı içerir:** `0.02204623`

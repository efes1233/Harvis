# buyuk_harf

Metni büyük harfe çevirir (Türkçe uyumlu)

- **Anahtar sözcükler:** `büyük harf`, `büyük yaz`
- **Örnek girdi:** `büyük harf çevir istanbul`
- **Beklenen çıktı içerir:** `İSTANBUL`

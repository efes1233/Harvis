# cevir_veri_kb_mb

veri: kilobayt ↔ megabayt çevirir

- **Anahtar sözcükler:** `kilobayt`, `kb`, `megabayt`, `mb`, `çevir`
- **Örnek girdi:** `10 kilobayt kaç megabayt çevir`
- **Beklenen çıktı içerir:** `0.009765625`

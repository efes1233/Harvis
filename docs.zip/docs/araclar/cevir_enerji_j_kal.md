# cevir_enerji_j_kal

enerji: joule ↔ kalori çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `kalori`, `çevir`
- **Örnek girdi:** `10 joule kaç kalori çevir`
- **Beklenen çıktı içerir:** `2.390057`

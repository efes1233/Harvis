# cevir_guc_w_hp

guc: watt ↔ beygir gücü çevirir

- **Anahtar sözcükler:** `watt`, `vat`, `beygir`, `hp`, `çevir`
- **Örnek girdi:** `10 watt kaç beygir çevir`
- **Beklenen çıktı içerir:** `0.01359622`

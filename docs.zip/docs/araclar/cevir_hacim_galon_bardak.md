# cevir_hacim_galon_bardak

hacim: galon ↔ su bardağı çevirir

- **Anahtar sözcükler:** `galon`, `gallon`, `bardak`, `çevir`
- **Örnek girdi:** `10 galon kaç bardak çevir`
- **Beklenen çıktı içerir:** `151.4165`

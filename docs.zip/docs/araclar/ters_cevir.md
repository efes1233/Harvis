# ters_cevir

Metni tersine çevirir

- **Anahtar sözcükler:** `ters çevir`, `tersini yaz`
- **Örnek girdi:** `ters çevir abc`
- **Beklenen çıktı içerir:** `cba`

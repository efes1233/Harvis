# yazi_tura

Yazı tura atar

- **Anahtar sözcükler:** `yazı tura`, `yazi tura`, `para at`
- **Örnek girdi:** `yazı tura at`
- **Beklenen çıktı içerir:** ``

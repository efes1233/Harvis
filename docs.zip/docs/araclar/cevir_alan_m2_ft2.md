# cevir_alan_m2_ft2

alan: metrekare ↔ fitkare çevirir

- **Anahtar sözcükler:** `metrekare`, `m2`, `fitkare`, `ft2`, `çevir`
- **Örnek girdi:** `10 metrekare kaç fitkare çevir`
- **Beklenen çıktı içerir:** `107.6391`

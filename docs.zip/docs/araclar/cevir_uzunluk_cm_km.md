# cevir_uzunluk_cm_km

uzunluk: santimetre ↔ kilometre çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `kilometre`, `km`, `çevir`
- **Örnek girdi:** `10 santimetre kaç kilometre çevir`
- **Beklenen çıktı içerir:** `0.0001`

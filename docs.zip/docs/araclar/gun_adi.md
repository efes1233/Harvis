# gun_adi

Tarihin haftanın hangi günü olduğunu söyler

- **Anahtar sözcükler:** `hangi gün`, `gün adı`
- **Örnek girdi:** `hangi gün 29.10.2023`
- **Beklenen çıktı içerir:** `Pazar`

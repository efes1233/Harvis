# cevir_hiz_knot_mach

hiz: knot ↔ mach çevirir

- **Anahtar sözcükler:** `knot`, `düğüm`, `mach`, `çevir`
- **Örnek girdi:** `10 knot kaç mach çevir`
- **Beklenen çıktı içerir:** `0.01499838`

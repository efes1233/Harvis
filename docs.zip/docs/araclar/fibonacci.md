# fibonacci

N. Fibonacci sayısını verir

- **Anahtar sözcükler:** `fibonacci`
- **Örnek girdi:** `fibonacci 20`
- **Beklenen çıktı içerir:** `6765`

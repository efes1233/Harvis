# cevir_enerji_j_btu

enerji: joule ↔ BTU çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `btu`, `çevir`
- **Örnek girdi:** `10 joule kaç btu çevir`
- **Beklenen çıktı içerir:** `0.009478171`

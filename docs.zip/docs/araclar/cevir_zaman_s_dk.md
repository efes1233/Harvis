# cevir_zaman_s_dk

zaman: saniye ↔ dakika çevirir

- **Anahtar sözcükler:** `saniye`, `dakika`, `dk`, `çevir`
- **Örnek girdi:** `10 saniye kaç dakika çevir`
- **Beklenen çıktı içerir:** `0.1666667`

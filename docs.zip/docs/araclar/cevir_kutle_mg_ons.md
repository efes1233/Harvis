# cevir_kutle_mg_ons

kutle: miligram ↔ ons çevirir

- **Anahtar sözcükler:** `miligram`, `mg`, `ons`, `ounce`, `oz`, `çevir`
- **Örnek girdi:** `10 miligram kaç ons çevir`
- **Beklenen çıktı içerir:** `0.0003527396`

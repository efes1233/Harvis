# cevir_veri_kb_tb

veri: kilobayt ↔ terabayt çevirir

- **Anahtar sözcükler:** `kilobayt`, `kb`, `terabayt`, `tb`, `çevir`
- **Örnek girdi:** `10 kilobayt kaç terabayt çevir`
- **Beklenen çıktı içerir:** `9.313226e-9`

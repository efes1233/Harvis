# cevir_zaman_s_saat

zaman: saniye ↔ saat çevirir

- **Anahtar sözcükler:** `saniye`, `saat`, `çevir`
- **Örnek girdi:** `10 saniye kaç saat çevir`
- **Beklenen çıktı içerir:** `0.002777778`

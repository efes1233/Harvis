# cevir_kutle_kg_ons

kutle: kilogram ↔ ons çevirir

- **Anahtar sözcükler:** `kilogram`, `kilo`, `kg`, `ons`, `ounce`, `oz`, `çevir`
- **Örnek girdi:** `10 kilogram kaç ons çevir`
- **Beklenen çıktı içerir:** `352.7396`

# cevir_hiz_kmh_knot

hiz: km/s ↔ knot çevirir

- **Anahtar sözcükler:** `km/s`, `km/h`, `kilometre/saat`, `knot`, `düğüm`, `çevir`
- **Örnek girdi:** `10 km/s kaç knot çevir`
- **Beklenen çıktı içerir:** `5.399568`

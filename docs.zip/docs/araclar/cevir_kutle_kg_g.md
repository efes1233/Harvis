# cevir_kutle_kg_g

kutle: kilogram ↔ gram çevirir

- **Anahtar sözcükler:** `kilogram`, `kilo`, `kg`, `gram`, `çevir`
- **Örnek girdi:** `10 kilogram kaç gram çevir`
- **Beklenen çıktı içerir:** `10000`

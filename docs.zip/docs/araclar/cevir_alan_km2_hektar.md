# cevir_alan_km2_hektar

alan: kilometrekare ↔ hektar çevirir

- **Anahtar sözcükler:** `kilometrekare`, `km2`, `hektar`, `çevir`
- **Örnek girdi:** `10 kilometrekare kaç hektar çevir`
- **Beklenen çıktı içerir:** `1000`

# cevir_basinc_kpa_atm

basinc: kilopascal ↔ atmosfer çevirir

- **Anahtar sözcükler:** `kilopascal`, `kpa`, `atmosfer`, `atm`, `çevir`
- **Örnek girdi:** `10 kilopascal kaç atmosfer çevir`
- **Beklenen çıktı içerir:** `0.09869233`

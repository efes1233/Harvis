# cevir_zaman_dk_hafta

zaman: dakika ↔ hafta çevirir

- **Anahtar sözcükler:** `dakika`, `dk`, `hafta`, `çevir`
- **Örnek girdi:** `10 dakika kaç hafta çevir`
- **Beklenen çıktı içerir:** `0.0009920635`

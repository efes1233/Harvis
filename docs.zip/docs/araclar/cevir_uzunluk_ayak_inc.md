# cevir_uzunluk_ayak_inc

uzunluk: ayak ↔ inç çevirir

- **Anahtar sözcükler:** `ayak`, `feet`, `ft`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 ayak kaç inç çevir`
- **Beklenen çıktı içerir:** `120`

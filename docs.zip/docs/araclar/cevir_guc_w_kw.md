# cevir_guc_w_kw

guc: watt ↔ kilowatt çevirir

- **Anahtar sözcükler:** `watt`, `vat`, `kilowatt`, `kw`, `çevir`
- **Örnek girdi:** `10 watt kaç kilowatt çevir`
- **Beklenen çıktı içerir:** `0.01`

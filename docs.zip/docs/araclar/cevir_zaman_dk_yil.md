# cevir_zaman_dk_yil

zaman: dakika ↔ yıl çevirir

- **Anahtar sözcükler:** `dakika`, `dk`, `yıl`, `sene`, `çevir`
- **Örnek girdi:** `10 dakika kaç yıl çevir`
- **Beklenen çıktı içerir:** `0.00001901285`

# cevir_veri_b_tb

veri: bayt ↔ terabayt çevirir

- **Anahtar sözcükler:** `bayt`, `byte`, `terabayt`, `tb`, `çevir`
- **Örnek girdi:** `10 bayt kaç terabayt çevir`
- **Beklenen çıktı içerir:** `9.094947e-12`

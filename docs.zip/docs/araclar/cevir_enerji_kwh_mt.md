# cevir_enerji_kwh_mt

enerji: kilovatsaat ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `kilovatsaat`, `kwh`, `megaton`, `çevir`
- **Örnek girdi:** `10 kilovatsaat kaç megaton çevir`
- **Beklenen çıktı içerir:** `8.604207e-9`

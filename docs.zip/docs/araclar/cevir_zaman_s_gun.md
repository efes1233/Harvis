# cevir_zaman_s_gun

zaman: saniye ↔ gün çevirir

- **Anahtar sözcükler:** `saniye`, `gün`, `çevir`
- **Örnek girdi:** `10 saniye kaç gün çevir`
- **Beklenen çıktı içerir:** `0.0001157407`

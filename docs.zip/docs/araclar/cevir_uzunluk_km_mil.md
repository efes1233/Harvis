# cevir_uzunluk_km_mil

uzunluk: kilometre ↔ mil çevirir

- **Anahtar sözcükler:** `kilometre`, `km`, `mil`, `mile`, `çevir`
- **Örnek girdi:** `10 kilometre kaç mil çevir`
- **Beklenen çıktı içerir:** `6.213712`

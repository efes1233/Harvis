# cevir_kutle_mg_libre

kutle: miligram ↔ libre çevirir

- **Anahtar sözcükler:** `miligram`, `mg`, `libre`, `pound`, `lb`, `çevir`
- **Örnek girdi:** `10 miligram kaç libre çevir`
- **Beklenen çıktı içerir:** `0.00002204623`

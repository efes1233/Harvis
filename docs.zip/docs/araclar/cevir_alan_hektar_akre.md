# cevir_alan_hektar_akre

alan: hektar ↔ akre çevirir

- **Anahtar sözcükler:** `hektar`, `akre`, `acre`, `çevir`
- **Örnek girdi:** `10 hektar kaç akre çevir`
- **Beklenen çıktı içerir:** `24.71054`

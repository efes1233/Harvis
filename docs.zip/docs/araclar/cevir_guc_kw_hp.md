# cevir_guc_kw_hp

guc: kilowatt ↔ beygir gücü çevirir

- **Anahtar sözcükler:** `kilowatt`, `kw`, `beygir`, `hp`, `çevir`
- **Örnek girdi:** `10 kilowatt kaç beygir çevir`
- **Beklenen çıktı içerir:** `13.59622`

# cevir_hiz_ms_kmh

hiz: m/s ↔ km/s çevirir

- **Anahtar sözcükler:** `m/s`, `metre/saniye`, `km/s`, `km/h`, `kilometre/saat`, `çevir`
- **Örnek girdi:** `10 m/s kaç km/s çevir`
- **Beklenen çıktı içerir:** `36`

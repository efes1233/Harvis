# cevir_aci_derece_grad

aci: derece ↔ grad çevirir

- **Anahtar sözcükler:** `derece`, `grad`, `çevir`
- **Örnek girdi:** `10 derece kaç grad çevir`
- **Beklenen çıktı içerir:** `11.11111`

# cevir_basinc_pa_bar

basinc: pascal ↔ bar çevirir

- **Anahtar sözcükler:** `pascal`, `pa`, `bar`, `çevir`
- **Örnek girdi:** `10 pascal kaç bar çevir`
- **Beklenen çıktı içerir:** `0.0001`

# cevir_uzunluk_m_denizmili

uzunluk: metre ↔ deniz mili çevirir

- **Anahtar sözcükler:** `metre`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 metre kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.005399568`

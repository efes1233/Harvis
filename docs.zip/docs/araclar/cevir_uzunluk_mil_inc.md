# cevir_uzunluk_mil_inc

uzunluk: mil ↔ inç çevirir

- **Anahtar sözcükler:** `mil`, `mile`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 mil kaç inç çevir`
- **Beklenen çıktı içerir:** `633600`

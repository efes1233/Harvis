# ikilik_taban

Sayıyı ikilik ve onaltılık tabana çevirir

- **Anahtar sözcükler:** `ikilik`, `binary`, `onaltılık`, `hex`
- **Örnek girdi:** `255 binary hex`
- **Beklenen çıktı içerir:** `0b11111111 = 0xFF`

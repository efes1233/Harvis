# faktoriyel

Faktöriyel hesaplar (BigInt)

- **Anahtar sözcükler:** `faktöriyel`, `faktoriyel`
- **Örnek girdi:** `10 faktöriyel`
- **Beklenen çıktı içerir:** `3628800`

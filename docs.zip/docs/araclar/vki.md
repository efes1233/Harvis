# vki

Beden kitle indeksi (boy cm, kilo kg)

- **Anahtar sözcükler:** `vki`, `beden kitle`, `bmi`
- **Örnek girdi:** `vki boy 180 kilo 81`
- **Beklenen çıktı içerir:** `VKİ 25.0`

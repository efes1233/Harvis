# cevir_alan_hektar_ft2

alan: hektar ↔ fitkare çevirir

- **Anahtar sözcükler:** `hektar`, `fitkare`, `ft2`, `çevir`
- **Örnek girdi:** `10 hektar kaç fitkare çevir`
- **Beklenen çıktı içerir:** `1076391`

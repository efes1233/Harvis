# cevir_alan_akre_ft2

alan: akre ↔ fitkare çevirir

- **Anahtar sözcükler:** `akre`, `acre`, `fitkare`, `ft2`, `çevir`
- **Örnek girdi:** `10 akre kaç fitkare çevir`
- **Beklenen çıktı içerir:** `435600`

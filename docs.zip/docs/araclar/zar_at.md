# zar_at

Zar atar (varsayılan 6 yüzlü)

- **Anahtar sözcükler:** `zar at`, `zar`
- **Örnek girdi:** `zar at`
- **Beklenen çıktı içerir:** `Zar: `

# ebob_ekok

İki sayının EBOB ve EKOK değerini verir

- **Anahtar sözcükler:** `ebob`, `ekok`
- **Örnek girdi:** `12 ve 18 ebob ekok`
- **Beklenen çıktı içerir:** `EBOB 6, EKOK 36`

# cevir_basinc_pa_psi

basinc: pascal ↔ psi çevirir

- **Anahtar sözcükler:** `pascal`, `pa`, `psi`, `çevir`
- **Örnek girdi:** `10 pascal kaç psi çevir`
- **Beklenen çıktı içerir:** `0.001450377`

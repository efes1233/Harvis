# cevir_veri_b_kb

veri: bayt ↔ kilobayt çevirir

- **Anahtar sözcükler:** `bayt`, `byte`, `kilobayt`, `kb`, `çevir`
- **Örnek girdi:** `10 bayt kaç kilobayt çevir`
- **Beklenen çıktı içerir:** `0.009765625`

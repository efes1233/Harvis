# cevir_enerji_kal_mt

enerji: kalori ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `kalori`, `megaton`, `çevir`
- **Örnek girdi:** `10 kalori kaç megaton çevir`
- **Beklenen çıktı içerir:** `1e-14`

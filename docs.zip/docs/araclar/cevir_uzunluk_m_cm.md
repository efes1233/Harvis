# cevir_uzunluk_m_cm

uzunluk: metre ↔ santimetre çevirir

- **Anahtar sözcükler:** `metre`, `santimetre`, `cm`, `çevir`
- **Örnek girdi:** `10 metre kaç santimetre çevir`
- **Beklenen çıktı içerir:** `1000`

# ortalama

Sayıların ortalamasını verir

- **Anahtar sözcükler:** `ortalama`
- **Örnek girdi:** `ortalama 4 8 15 16 23 42`
- **Beklenen çıktı içerir:** `18`

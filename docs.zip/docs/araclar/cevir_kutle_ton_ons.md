# cevir_kutle_ton_ons

kutle: ton ↔ ons çevirir

- **Anahtar sözcükler:** `ton`, `ons`, `ounce`, `oz`, `çevir`
- **Örnek girdi:** `10 ton kaç ons çevir`
- **Beklenen çıktı içerir:** `352739.6`

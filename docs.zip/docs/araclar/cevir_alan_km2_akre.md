# cevir_alan_km2_akre

alan: kilometrekare ↔ akre çevirir

- **Anahtar sözcükler:** `kilometrekare`, `km2`, `akre`, `acre`, `çevir`
- **Örnek girdi:** `10 kilometrekare kaç akre çevir`
- **Beklenen çıktı içerir:** `2471.054`

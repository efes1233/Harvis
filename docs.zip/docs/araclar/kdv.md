# kdv

KDV hesaplar (varsayılan %20)

- **Anahtar sözcükler:** `kdv`
- **Örnek girdi:** `kdv 100 20`
- **Beklenen çıktı içerir:** `KDV 20.00, toplam 120.00`

# cevir_hacim_l_bardak

hacim: litre ↔ su bardağı çevirir

- **Anahtar sözcükler:** `litre`, `bardak`, `çevir`
- **Örnek girdi:** `10 litre kaç bardak çevir`
- **Beklenen çıktı içerir:** `40`

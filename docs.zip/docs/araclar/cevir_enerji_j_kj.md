# cevir_enerji_j_kj

enerji: joule ↔ kilojoule çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `kilojoule`, `kj`, `çevir`
- **Örnek girdi:** `10 joule kaç kilojoule çevir`
- **Beklenen çıktı içerir:** `0.01`

# cevir_hacim_m3_pint

hacim: metreküp ↔ pint çevirir

- **Anahtar sözcükler:** `metreküp`, `m3`, `pint`, `çevir`
- **Örnek girdi:** `10 metreküp kaç pint çevir`
- **Beklenen çıktı içerir:** `21133.76`

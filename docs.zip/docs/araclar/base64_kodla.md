# base64_kodla

Metni Base64'e kodlar

- **Anahtar sözcükler:** `base64 kodla`, `base64'e çevir`, `base64 encode`
- **Örnek girdi:** `base64 kodla merhaba`
- **Beklenen çıktı içerir:** `bWVyaGFiYQ==`

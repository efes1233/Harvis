# cevir_kutle_g_ons

kutle: gram ↔ ons çevirir

- **Anahtar sözcükler:** `gram`, `ons`, `ounce`, `oz`, `çevir`
- **Örnek girdi:** `10 gram kaç ons çevir`
- **Beklenen çıktı içerir:** `0.3527396`

# asal_mi

Sayının asal olup olmadığını söyler

- **Anahtar sözcükler:** `asal mı`, `asal mi`, `asal`
- **Örnek girdi:** `97 asal mı`
- **Beklenen çıktı içerir:** `asaldır`

# cevir_uzunluk_yarda_ayak

uzunluk: yarda ↔ ayak çevirir

- **Anahtar sözcükler:** `yarda`, `yard`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 yarda kaç ayak çevir`
- **Beklenen çıktı içerir:** `30`

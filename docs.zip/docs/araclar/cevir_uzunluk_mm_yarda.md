# cevir_uzunluk_mm_yarda

uzunluk: milimetre ↔ yarda çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `yarda`, `yard`, `çevir`
- **Örnek girdi:** `10 milimetre kaç yarda çevir`
- **Beklenen çıktı içerir:** `0.01093613`

# cevir_veri_b_bit

veri: bayt ↔ bit çevirir

- **Anahtar sözcükler:** `bayt`, `byte`, `bit`, `çevir`
- **Örnek girdi:** `10 bayt kaç bit çevir`
- **Beklenen çıktı içerir:** `80`

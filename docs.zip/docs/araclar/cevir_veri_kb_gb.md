# cevir_veri_kb_gb

veri: kilobayt ↔ gigabayt çevirir

- **Anahtar sözcükler:** `kilobayt`, `kb`, `gigabayt`, `gb`, `çevir`
- **Örnek girdi:** `10 kilobayt kaç gigabayt çevir`
- **Beklenen çıktı içerir:** `0.000009536743`

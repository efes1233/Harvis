# tarih

Bugünün tarihini söyler

- **Anahtar sözcükler:** `tarih`, `bugün ne`, `günlerden ne`, `bugün günlerden`
- **Örnek girdi:** `bugün günlerden ne`
- **Beklenen çıktı içerir:** `Bugün `

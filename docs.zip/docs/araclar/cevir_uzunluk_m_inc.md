# cevir_uzunluk_m_inc

uzunluk: metre ↔ inç çevirir

- **Anahtar sözcükler:** `metre`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 metre kaç inç çevir`
- **Beklenen çıktı içerir:** `393.7008`

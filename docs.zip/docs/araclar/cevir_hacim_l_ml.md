# cevir_hacim_l_ml

hacim: litre ↔ mililitre çevirir

- **Anahtar sözcükler:** `litre`, `mililitre`, `ml`, `çevir`
- **Örnek girdi:** `10 litre kaç mililitre çevir`
- **Beklenen çıktı içerir:** `10000`

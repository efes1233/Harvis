# cevir_guc_hp_btuh

guc: beygir gücü ↔ BTU/saat çevirir

- **Anahtar sözcükler:** `beygir`, `hp`, `btu/saat`, `çevir`
- **Örnek girdi:** `10 beygir kaç btu/saat çevir`
- **Beklenen çıktı içerir:** `25096.26`

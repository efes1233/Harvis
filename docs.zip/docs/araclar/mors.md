# mors

Metni Mors koduna çevirir

- **Anahtar sözcükler:** `mors`
- **Örnek girdi:** `mors sos`
- **Beklenen çıktı içerir:** `... --- ...`

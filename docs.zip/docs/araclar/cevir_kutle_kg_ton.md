# cevir_kutle_kg_ton

kutle: kilogram ↔ ton çevirir

- **Anahtar sözcükler:** `kilogram`, `kilo`, `kg`, `ton`, `çevir`
- **Örnek girdi:** `10 kilogram kaç ton çevir`
- **Beklenen çıktı içerir:** `0.01`

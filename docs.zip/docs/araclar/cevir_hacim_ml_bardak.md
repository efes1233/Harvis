# cevir_hacim_ml_bardak

hacim: mililitre ↔ su bardağı çevirir

- **Anahtar sözcükler:** `mililitre`, `ml`, `bardak`, `çevir`
- **Örnek girdi:** `10 mililitre kaç bardak çevir`
- **Beklenen çıktı içerir:** `0.04`

# cevir_basinc_atm_psi

basinc: atmosfer ↔ psi çevirir

- **Anahtar sözcükler:** `atmosfer`, `atm`, `psi`, `çevir`
- **Örnek girdi:** `10 atmosfer kaç psi çevir`
- **Beklenen çıktı içerir:** `146.9595`

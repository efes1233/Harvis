# cevir_enerji_j_kwh

enerji: joule ↔ kilovatsaat çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `kilovatsaat`, `kwh`, `çevir`
- **Örnek girdi:** `10 joule kaç kilovatsaat çevir`
- **Beklenen çıktı içerir:** `0.000002777778`

# cevir_basinc_atm_mmhg

basinc: atmosfer ↔ mmHg çevirir

- **Anahtar sözcükler:** `atmosfer`, `atm`, `mmhg`, `cıva`, `çevir`
- **Örnek girdi:** `10 atmosfer kaç mmhg çevir`
- **Beklenen çıktı içerir:** `7599.999`

# cevir_uzunluk_mm_denizmili

uzunluk: milimetre ↔ deniz mili çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 milimetre kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.000005399568`

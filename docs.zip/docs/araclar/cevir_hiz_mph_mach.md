# cevir_hiz_mph_mach

hiz: mil/saat ↔ mach çevirir

- **Anahtar sözcükler:** `mph`, `mil/saat`, `mach`, `çevir`
- **Örnek girdi:** `10 mph kaç mach çevir`
- **Beklenen çıktı içerir:** `0.01303324`

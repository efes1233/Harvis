# cevir_alan_km2_donum

alan: kilometrekare ↔ dönüm çevirir

- **Anahtar sözcükler:** `kilometrekare`, `km2`, `dönüm`, `çevir`
- **Örnek girdi:** `10 kilometrekare kaç dönüm çevir`
- **Beklenen çıktı içerir:** `10000`

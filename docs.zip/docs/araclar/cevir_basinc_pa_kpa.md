# cevir_basinc_pa_kpa

basinc: pascal ↔ kilopascal çevirir

- **Anahtar sözcükler:** `pascal`, `pa`, `kilopascal`, `kpa`, `çevir`
- **Örnek girdi:** `10 pascal kaç kilopascal çevir`
- **Beklenen çıktı içerir:** `0.01`

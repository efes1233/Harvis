# cevir_kutle_libre_ons

kutle: libre ↔ ons çevirir

- **Anahtar sözcükler:** `libre`, `pound`, `lb`, `ons`, `ounce`, `oz`, `çevir`
- **Örnek girdi:** `10 libre kaç ons çevir`
- **Beklenen çıktı içerir:** `160`

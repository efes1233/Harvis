# cevir_alan_m2_km2

alan: metrekare ↔ kilometrekare çevirir

- **Anahtar sözcükler:** `metrekare`, `m2`, `kilometrekare`, `km2`, `çevir`
- **Örnek girdi:** `10 metrekare kaç kilometrekare çevir`
- **Beklenen çıktı içerir:** `0.00001`

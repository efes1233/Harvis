# cevir_veri_kb_bit

veri: kilobayt ↔ bit çevirir

- **Anahtar sözcükler:** `kilobayt`, `kb`, `bit`, `çevir`
- **Örnek girdi:** `10 kilobayt kaç bit çevir`
- **Beklenen çıktı içerir:** `81920`

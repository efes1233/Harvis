# kucuk_harf

Metni küçük harfe çevirir (Türkçe uyumlu)

- **Anahtar sözcükler:** `küçük harf`, `küçük yaz`
- **Örnek girdi:** `küçük harf çevir ISPARTA`
- **Beklenen çıktı içerir:** `ısparta`

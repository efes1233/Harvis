# cevir_uzunluk_yarda_denizmili

uzunluk: yarda ↔ deniz mili çevirir

- **Anahtar sözcükler:** `yarda`, `yard`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 yarda kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.004937365`

# cevir_kutle_mg_ton

kutle: miligram ↔ ton çevirir

- **Anahtar sözcükler:** `miligram`, `mg`, `ton`, `çevir`
- **Örnek girdi:** `10 miligram kaç ton çevir`
- **Beklenen çıktı içerir:** `1e-8`

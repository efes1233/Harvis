# cevir_hiz_ms_knot

hiz: m/s ↔ knot çevirir

- **Anahtar sözcükler:** `m/s`, `metre/saniye`, `knot`, `düğüm`, `çevir`
- **Örnek girdi:** `10 m/s kaç knot çevir`
- **Beklenen çıktı içerir:** `19.43844`

# cevir_hiz_kmh_mach

hiz: km/s ↔ mach çevirir

- **Anahtar sözcükler:** `km/s`, `km/h`, `kilometre/saat`, `mach`, `çevir`
- **Örnek girdi:** `10 km/s kaç mach çevir`
- **Beklenen çıktı içerir:** `0.008098477`

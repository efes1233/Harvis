# cevir_basinc_bar_atm

basinc: bar ↔ atmosfer çevirir

- **Anahtar sözcükler:** `bar`, `atmosfer`, `atm`, `çevir`
- **Örnek girdi:** `10 bar kaç atmosfer çevir`
- **Beklenen çıktı içerir:** `9.869233`

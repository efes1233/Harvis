# cevir_kutle_g_ton

kutle: gram ↔ ton çevirir

- **Anahtar sözcükler:** `gram`, `ton`, `çevir`
- **Örnek girdi:** `10 gram kaç ton çevir`
- **Beklenen çıktı içerir:** `0.00001`

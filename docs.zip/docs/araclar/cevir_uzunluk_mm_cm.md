# cevir_uzunluk_mm_cm

uzunluk: milimetre ↔ santimetre çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `santimetre`, `cm`, `çevir`
- **Örnek girdi:** `10 milimetre kaç santimetre çevir`
- **Beklenen çıktı içerir:** `1`

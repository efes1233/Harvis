# cevir_hiz_ms_mach

hiz: m/s ↔ mach çevirir

- **Anahtar sözcükler:** `m/s`, `metre/saniye`, `mach`, `çevir`
- **Örnek girdi:** `10 m/s kaç mach çevir`
- **Beklenen çıktı içerir:** `0.02915452`

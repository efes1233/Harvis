# cevir_basinc_kpa_psi

basinc: kilopascal ↔ psi çevirir

- **Anahtar sözcükler:** `kilopascal`, `kpa`, `psi`, `çevir`
- **Örnek girdi:** `10 kilopascal kaç psi çevir`
- **Beklenen çıktı içerir:** `1.450377`

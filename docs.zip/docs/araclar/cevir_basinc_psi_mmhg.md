# cevir_basinc_psi_mmhg

basinc: psi ↔ mmHg çevirir

- **Anahtar sözcükler:** `psi`, `mmhg`, `cıva`, `çevir`
- **Örnek girdi:** `10 psi kaç mmhg çevir`
- **Beklenen çıktı içerir:** `517.1493`

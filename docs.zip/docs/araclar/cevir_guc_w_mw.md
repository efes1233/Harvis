# cevir_guc_w_mw

guc: watt ↔ megawatt çevirir

- **Anahtar sözcükler:** `watt`, `vat`, `megawatt`, `mw`, `çevir`
- **Örnek girdi:** `10 watt kaç megawatt çevir`
- **Beklenen çıktı içerir:** `0.00001`

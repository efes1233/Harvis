# cevir_uzunluk_km_denizmili

uzunluk: kilometre ↔ deniz mili çevirir

- **Anahtar sözcükler:** `kilometre`, `km`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 kilometre kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `5.399568`

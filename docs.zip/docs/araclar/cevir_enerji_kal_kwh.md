# cevir_enerji_kal_kwh

enerji: kalori ↔ kilovatsaat çevirir

- **Anahtar sözcükler:** `kalori`, `kilovatsaat`, `kwh`, `çevir`
- **Örnek girdi:** `10 kalori kaç kilovatsaat çevir`
- **Beklenen çıktı içerir:** `0.00001162222`

# cevir_zaman_dk_gun

zaman: dakika ↔ gün çevirir

- **Anahtar sözcükler:** `dakika`, `dk`, `gün`, `çevir`
- **Örnek girdi:** `10 dakika kaç gün çevir`
- **Beklenen çıktı içerir:** `0.006944444`

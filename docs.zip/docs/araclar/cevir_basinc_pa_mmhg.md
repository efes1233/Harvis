# cevir_basinc_pa_mmhg

basinc: pascal ↔ mmHg çevirir

- **Anahtar sözcükler:** `pascal`, `pa`, `mmhg`, `cıva`, `çevir`
- **Örnek girdi:** `10 pascal kaç mmhg çevir`
- **Beklenen çıktı içerir:** `0.07500616`

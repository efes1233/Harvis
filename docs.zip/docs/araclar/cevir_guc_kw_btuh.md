# cevir_guc_kw_btuh

guc: kilowatt ↔ BTU/saat çevirir

- **Anahtar sözcükler:** `kilowatt`, `kw`, `btu/saat`, `çevir`
- **Örnek girdi:** `10 kilowatt kaç btu/saat çevir`
- **Beklenen çıktı içerir:** `34121.42`

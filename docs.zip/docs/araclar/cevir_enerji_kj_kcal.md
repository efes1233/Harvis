# cevir_enerji_kj_kcal

enerji: kilojoule ↔ kilokalori çevirir

- **Anahtar sözcükler:** `kilojoule`, `kj`, `kilokalori`, `kcal`, `çevir`
- **Örnek girdi:** `10 kilojoule kaç kilokalori çevir`
- **Beklenen çıktı içerir:** `2.390057`

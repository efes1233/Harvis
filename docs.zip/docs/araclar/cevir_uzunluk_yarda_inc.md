# cevir_uzunluk_yarda_inc

uzunluk: yarda ↔ inç çevirir

- **Anahtar sözcükler:** `yarda`, `yard`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 yarda kaç inç çevir`
- **Beklenen çıktı içerir:** `360`

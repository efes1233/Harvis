# carpim_tablosu

Bir sayının çarpım tablosunu verir

- **Anahtar sözcükler:** `çarpım tablosu`, `carpim tablosu`
- **Örnek girdi:** `7 çarpım tablosu`
- **Beklenen çıktı içerir:** `7x10=70`

# cevir_veri_mb_tb

veri: megabayt ↔ terabayt çevirir

- **Anahtar sözcükler:** `megabayt`, `mb`, `terabayt`, `tb`, `çevir`
- **Örnek girdi:** `10 megabayt kaç terabayt çevir`
- **Beklenen çıktı içerir:** `0.000009536743`

# cevir_enerji_kcal_btu

enerji: kilokalori ↔ BTU çevirir

- **Anahtar sözcükler:** `kilokalori`, `kcal`, `btu`, `çevir`
- **Örnek girdi:** `10 kilokalori kaç btu çevir`
- **Beklenen çıktı içerir:** `39.65667`

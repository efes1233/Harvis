# cevir_hacim_ml_pint

hacim: mililitre ↔ pint çevirir

- **Anahtar sözcükler:** `mililitre`, `ml`, `pint`, `çevir`
- **Örnek girdi:** `10 mililitre kaç pint çevir`
- **Beklenen çıktı içerir:** `0.02113376`

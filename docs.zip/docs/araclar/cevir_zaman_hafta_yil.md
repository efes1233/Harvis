# cevir_zaman_hafta_yil

zaman: hafta ↔ yıl çevirir

- **Anahtar sözcükler:** `hafta`, `yıl`, `sene`, `çevir`
- **Örnek girdi:** `10 hafta kaç yıl çevir`
- **Beklenen çıktı içerir:** `0.1916496`

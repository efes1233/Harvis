# cevir_kutle_g_mg

kutle: gram ↔ miligram çevirir

- **Anahtar sözcükler:** `gram`, `miligram`, `mg`, `çevir`
- **Örnek girdi:** `10 gram kaç miligram çevir`
- **Beklenen çıktı içerir:** `10000`

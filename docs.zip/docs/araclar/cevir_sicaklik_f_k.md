# cevir_sicaklik_f_k

sıcaklık: Fahrenhayt ↔ Kelvin çevirir

- **Anahtar sözcükler:** `fahrenhayt`, `fahrenheit`, `kelvin`, `çevir`
- **Örnek girdi:** `32 fahrenhayt kaç kelvin`
- **Beklenen çıktı içerir:** `273.15`

# cevir_hiz_kmh_mph

hiz: km/s ↔ mil/saat çevirir

- **Anahtar sözcükler:** `km/s`, `km/h`, `kilometre/saat`, `mph`, `mil/saat`, `çevir`
- **Örnek girdi:** `10 km/s kaç mph çevir`
- **Beklenen çıktı içerir:** `6.213712`

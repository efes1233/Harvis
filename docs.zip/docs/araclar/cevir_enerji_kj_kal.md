# cevir_enerji_kj_kal

enerji: kilojoule ↔ kalori çevirir

- **Anahtar sözcükler:** `kilojoule`, `kj`, `kalori`, `çevir`
- **Örnek girdi:** `10 kilojoule kaç kalori çevir`
- **Beklenen çıktı içerir:** `2390.057`

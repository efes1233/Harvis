# cevir_enerji_kwh_btu

enerji: kilovatsaat ↔ BTU çevirir

- **Anahtar sözcükler:** `kilovatsaat`, `kwh`, `btu`, `çevir`
- **Örnek girdi:** `10 kilovatsaat kaç btu çevir`
- **Beklenen çıktı içerir:** `34121.42`

# cevir_alan_m2_hektar

alan: metrekare ↔ hektar çevirir

- **Anahtar sözcükler:** `metrekare`, `m2`, `hektar`, `çevir`
- **Örnek girdi:** `10 metrekare kaç hektar çevir`
- **Beklenen çıktı içerir:** `0.001`

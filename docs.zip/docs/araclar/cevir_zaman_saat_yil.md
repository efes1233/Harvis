# cevir_zaman_saat_yil

zaman: saat ↔ yıl çevirir

- **Anahtar sözcükler:** `saat`, `yıl`, `sene`, `çevir`
- **Örnek girdi:** `10 saat kaç yıl çevir`
- **Beklenen çıktı içerir:** `0.001140771`

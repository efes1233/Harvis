# cevir_enerji_j_mt

enerji: joule ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `joule`, `jul`, `megaton`, `çevir`
- **Örnek girdi:** `10 joule kaç megaton çevir`
- **Beklenen çıktı içerir:** `2.390057e-15`

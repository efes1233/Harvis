# cevir_enerji_btu_mt

enerji: BTU ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `btu`, `megaton`, `çevir`
- **Örnek girdi:** `10 btu kaç megaton çevir`
- **Beklenen çıktı içerir:** `2.521644e-12`

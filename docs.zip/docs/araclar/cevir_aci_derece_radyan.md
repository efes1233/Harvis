# cevir_aci_derece_radyan

aci: derece ↔ radyan çevirir

- **Anahtar sözcükler:** `derece`, `radyan`, `çevir`
- **Örnek girdi:** `10 derece kaç radyan çevir`
- **Beklenen çıktı içerir:** `0.1745329`

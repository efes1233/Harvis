# cevir_uzunluk_m_mm

uzunluk: metre ↔ milimetre çevirir

- **Anahtar sözcükler:** `metre`, `milimetre`, `mm`, `çevir`
- **Örnek girdi:** `10 metre kaç milimetre çevir`
- **Beklenen çıktı içerir:** `10000`

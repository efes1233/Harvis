# cevir_uzunluk_mil_yarda

uzunluk: mil ↔ yarda çevirir

- **Anahtar sözcükler:** `mil`, `mile`, `yarda`, `yard`, `çevir`
- **Örnek girdi:** `10 mil kaç yarda çevir`
- **Beklenen çıktı içerir:** `17600`

# cevir_alan_km2_ft2

alan: kilometrekare ↔ fitkare çevirir

- **Anahtar sözcükler:** `kilometrekare`, `km2`, `fitkare`, `ft2`, `çevir`
- **Örnek girdi:** `10 kilometrekare kaç fitkare çevir`
- **Beklenen çıktı içerir:** `107639100`

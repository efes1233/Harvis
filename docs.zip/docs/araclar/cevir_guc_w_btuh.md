# cevir_guc_w_btuh

guc: watt ↔ BTU/saat çevirir

- **Anahtar sözcükler:** `watt`, `vat`, `btu/saat`, `çevir`
- **Örnek girdi:** `10 watt kaç btu/saat çevir`
- **Beklenen çıktı içerir:** `34.12142`

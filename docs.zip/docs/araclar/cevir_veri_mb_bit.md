# cevir_veri_mb_bit

veri: megabayt ↔ bit çevirir

- **Anahtar sözcükler:** `megabayt`, `mb`, `bit`, `çevir`
- **Örnek girdi:** `10 megabayt kaç bit çevir`
- **Beklenen çıktı içerir:** `83886080`

# cevir_enerji_kj_btu

enerji: kilojoule ↔ BTU çevirir

- **Anahtar sözcükler:** `kilojoule`, `kj`, `btu`, `çevir`
- **Örnek girdi:** `10 kilojoule kaç btu çevir`
- **Beklenen çıktı içerir:** `9.478171`

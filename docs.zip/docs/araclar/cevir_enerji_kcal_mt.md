# cevir_enerji_kcal_mt

enerji: kilokalori ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `kilokalori`, `kcal`, `megaton`, `çevir`
- **Örnek girdi:** `10 kilokalori kaç megaton çevir`
- **Beklenen çıktı içerir:** `1e-11`

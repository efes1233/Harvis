# cevir_uzunluk_m_km

uzunluk: metre ↔ kilometre çevirir

- **Anahtar sözcükler:** `metre`, `kilometre`, `km`, `çevir`
- **Örnek girdi:** `10 metre kaç kilometre çevir`
- **Beklenen çıktı içerir:** `0.01`

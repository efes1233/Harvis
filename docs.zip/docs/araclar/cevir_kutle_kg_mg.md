# cevir_kutle_kg_mg

kutle: kilogram ↔ miligram çevirir

- **Anahtar sözcükler:** `kilogram`, `kilo`, `kg`, `miligram`, `mg`, `çevir`
- **Örnek girdi:** `10 kilogram kaç miligram çevir`
- **Beklenen çıktı içerir:** `10000000`

# cevir_uzunluk_mil_ayak

uzunluk: mil ↔ ayak çevirir

- **Anahtar sözcükler:** `mil`, `mile`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 mil kaç ayak çevir`
- **Beklenen çıktı içerir:** `52800`

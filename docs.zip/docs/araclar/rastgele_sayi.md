# rastgele_sayi

Aralıkta rastgele sayı seçer

- **Anahtar sözcükler:** `rastgele sayı`, `rastgele say`
- **Örnek girdi:** `1 ile 10 arası rastgele sayı`
- **Beklenen çıktı içerir:** `Sayı: `

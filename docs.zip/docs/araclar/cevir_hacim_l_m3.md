# cevir_hacim_l_m3

hacim: litre ↔ metreküp çevirir

- **Anahtar sözcükler:** `litre`, `metreküp`, `m3`, `çevir`
- **Örnek girdi:** `10 litre kaç metreküp çevir`
- **Beklenen çıktı içerir:** `0.01`

# cevir_hiz_ms_mph

hiz: m/s ↔ mil/saat çevirir

- **Anahtar sözcükler:** `m/s`, `metre/saniye`, `mph`, `mil/saat`, `çevir`
- **Örnek girdi:** `10 m/s kaç mph çevir`
- **Beklenen çıktı içerir:** `22.36936`

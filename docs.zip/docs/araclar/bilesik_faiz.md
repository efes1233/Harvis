# bilesik_faiz

Bileşik faiz: anapara, yıllık %, yıl

- **Anahtar sözcükler:** `bileşik faiz`, `bilesik faiz`
- **Örnek girdi:** `bileşik faiz 1000 10 2`
- **Beklenen çıktı içerir:** `1210.00`

# cevir_uzunluk_cm_denizmili

uzunluk: santimetre ↔ deniz mili çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 santimetre kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.00005399568`

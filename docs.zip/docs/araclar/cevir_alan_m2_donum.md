# cevir_alan_m2_donum

alan: metrekare ↔ dönüm çevirir

- **Anahtar sözcükler:** `metrekare`, `m2`, `dönüm`, `çevir`
- **Örnek girdi:** `10 metrekare kaç dönüm çevir`
- **Beklenen çıktı içerir:** `0.01`

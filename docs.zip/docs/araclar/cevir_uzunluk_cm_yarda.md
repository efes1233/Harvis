# cevir_uzunluk_cm_yarda

uzunluk: santimetre ↔ yarda çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `yarda`, `yard`, `çevir`
- **Örnek girdi:** `10 santimetre kaç yarda çevir`
- **Beklenen çıktı içerir:** `0.1093613`

# cevir_zaman_gun_hafta

zaman: gün ↔ hafta çevirir

- **Anahtar sözcükler:** `gün`, `hafta`, `çevir`
- **Örnek girdi:** `10 gün kaç hafta çevir`
- **Beklenen çıktı içerir:** `1.428571`

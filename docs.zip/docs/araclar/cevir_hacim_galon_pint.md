# cevir_hacim_galon_pint

hacim: galon ↔ pint çevirir

- **Anahtar sözcükler:** `galon`, `gallon`, `pint`, `çevir`
- **Örnek girdi:** `10 galon kaç pint çevir`
- **Beklenen çıktı içerir:** `80`

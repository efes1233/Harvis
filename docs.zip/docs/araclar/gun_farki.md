# gun_farki

İki tarih (GG.AA.YYYY) arasındaki gün sayısı

- **Anahtar sözcükler:** `gün farkı`, `kaç gün var`, `gun farki`
- **Örnek girdi:** `gün farkı 01.01.2024 ile 01.03.2024`
- **Beklenen çıktı içerir:** `60 gün`

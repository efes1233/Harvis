# cevir_uzunluk_mm_inc

uzunluk: milimetre ↔ inç çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 milimetre kaç inç çevir`
- **Beklenen çıktı içerir:** `0.3937008`

# cevir_uzunluk_ayak_denizmili

uzunluk: ayak ↔ deniz mili çevirir

- **Anahtar sözcükler:** `ayak`, `feet`, `ft`, `deniz mili`, `çevir`
- **Örnek girdi:** `10 ayak kaç deniz mili çevir`
- **Beklenen çıktı içerir:** `0.001645788`

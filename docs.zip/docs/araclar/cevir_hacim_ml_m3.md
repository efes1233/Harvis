# cevir_hacim_ml_m3

hacim: mililitre ↔ metreküp çevirir

- **Anahtar sözcükler:** `mililitre`, `ml`, `metreküp`, `m3`, `çevir`
- **Örnek girdi:** `10 mililitre kaç metreküp çevir`
- **Beklenen çıktı içerir:** `0.00001`

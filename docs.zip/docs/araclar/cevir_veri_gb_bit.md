# cevir_veri_gb_bit

veri: gigabayt ↔ bit çevirir

- **Anahtar sözcükler:** `gigabayt`, `gb`, `bit`, `çevir`
- **Örnek girdi:** `10 gigabayt kaç bit çevir`
- **Beklenen çıktı içerir:** `85899345920`

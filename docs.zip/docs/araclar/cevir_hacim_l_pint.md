# cevir_hacim_l_pint

hacim: litre ↔ pint çevirir

- **Anahtar sözcükler:** `litre`, `pint`, `çevir`
- **Örnek girdi:** `10 litre kaç pint çevir`
- **Beklenen çıktı içerir:** `21.13376`

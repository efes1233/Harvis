# kelime_say

Metindeki kelime sayısını verir

- **Anahtar sözcükler:** `kelime say`, `kaç kelime`
- **Örnek girdi:** `kelime say bir iki üç dört`
- **Beklenen çıktı içerir:** `Kelime sayısı: 4`

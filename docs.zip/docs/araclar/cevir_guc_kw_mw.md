# cevir_guc_kw_mw

guc: kilowatt ↔ megawatt çevirir

- **Anahtar sözcükler:** `kilowatt`, `kw`, `megawatt`, `mw`, `çevir`
- **Örnek girdi:** `10 kilowatt kaç megawatt çevir`
- **Beklenen çıktı içerir:** `0.01`

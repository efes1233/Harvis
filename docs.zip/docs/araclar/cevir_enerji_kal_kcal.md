# cevir_enerji_kal_kcal

enerji: kalori ↔ kilokalori çevirir

- **Anahtar sözcükler:** `kalori`, `kilokalori`, `kcal`, `çevir`
- **Örnek girdi:** `10 kalori kaç kilokalori çevir`
- **Beklenen çıktı içerir:** `0.01`

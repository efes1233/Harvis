# cevir_zaman_gun_yil

zaman: gün ↔ yıl çevirir

- **Anahtar sözcükler:** `gün`, `yıl`, `sene`, `çevir`
- **Örnek girdi:** `10 gün kaç yıl çevir`
- **Beklenen çıktı içerir:** `0.02737851`

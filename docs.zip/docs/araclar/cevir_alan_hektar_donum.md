# cevir_alan_hektar_donum

alan: hektar ↔ dönüm çevirir

- **Anahtar sözcükler:** `hektar`, `dönüm`, `çevir`
- **Örnek girdi:** `10 hektar kaç dönüm çevir`
- **Beklenen çıktı içerir:** `100`

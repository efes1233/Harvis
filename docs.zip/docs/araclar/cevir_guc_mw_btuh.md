# cevir_guc_mw_btuh

guc: megawatt ↔ BTU/saat çevirir

- **Anahtar sözcükler:** `megawatt`, `mw`, `btu/saat`, `çevir`
- **Örnek girdi:** `10 megawatt kaç btu/saat çevir`
- **Beklenen çıktı içerir:** `34121420`

# cevir_basinc_bar_psi

basinc: bar ↔ psi çevirir

- **Anahtar sözcükler:** `bar`, `psi`, `çevir`
- **Örnek girdi:** `10 bar kaç psi çevir`
- **Beklenen çıktı içerir:** `145.0377`

# cevir_enerji_kj_mt

enerji: kilojoule ↔ megaton TNT çevirir

- **Anahtar sözcükler:** `kilojoule`, `kj`, `megaton`, `çevir`
- **Örnek girdi:** `10 kilojoule kaç megaton çevir`
- **Beklenen çıktı içerir:** `2.390057e-12`

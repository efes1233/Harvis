# cevir_guc_mw_hp

guc: megawatt ↔ beygir gücü çevirir

- **Anahtar sözcükler:** `megawatt`, `mw`, `beygir`, `hp`, `çevir`
- **Örnek girdi:** `10 megawatt kaç beygir çevir`
- **Beklenen çıktı içerir:** `13596.22`

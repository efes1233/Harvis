# cevir_uzunluk_mm_km

uzunluk: milimetre ↔ kilometre çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `kilometre`, `km`, `çevir`
- **Örnek girdi:** `10 milimetre kaç kilometre çevir`
- **Beklenen çıktı içerir:** `0.00001`

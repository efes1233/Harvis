# cevir_hacim_m3_bardak

hacim: metreküp ↔ su bardağı çevirir

- **Anahtar sözcükler:** `metreküp`, `m3`, `bardak`, `çevir`
- **Örnek girdi:** `10 metreküp kaç bardak çevir`
- **Beklenen çıktı içerir:** `40000`

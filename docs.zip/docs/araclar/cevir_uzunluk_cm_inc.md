# cevir_uzunluk_cm_inc

uzunluk: santimetre ↔ inç çevirir

- **Anahtar sözcükler:** `santimetre`, `cm`, `inç`, `inch`, `inc`, `çevir`
- **Örnek girdi:** `10 santimetre kaç inç çevir`
- **Beklenen çıktı içerir:** `3.937008`

# cevir_uzunluk_m_yarda

uzunluk: metre ↔ yarda çevirir

- **Anahtar sözcükler:** `metre`, `yarda`, `yard`, `çevir`
- **Örnek girdi:** `10 metre kaç yarda çevir`
- **Beklenen çıktı içerir:** `10.93613`

# cevir_enerji_kcal_kwh

enerji: kilokalori ↔ kilovatsaat çevirir

- **Anahtar sözcükler:** `kilokalori`, `kcal`, `kilovatsaat`, `kwh`, `çevir`
- **Örnek girdi:** `10 kilokalori kaç kilovatsaat çevir`
- **Beklenen çıktı içerir:** `0.01162222`

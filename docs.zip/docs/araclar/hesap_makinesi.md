# hesap_makinesi

Aritmetik ifadeleri hesaplar (+ - * / ^ % parantez, 'artı', 'çarpı' vb.)

- **Anahtar sözcükler:** `hesapla`, `kaç eder`, `artı`, `çarpı`, `bölü`, `eksi`
- **Örnek girdi:** `hesapla 12 çarpı (3 artı 4)`
- **Beklenen çıktı içerir:** `84`

# yuzde

Yüzde hesaplar: 'A sayısının yüzde B'si'

- **Anahtar sözcükler:** `yüzde`, `yuzde`
- **Örnek girdi:** `200 sayısının yüzde 15 i`
- **Beklenen çıktı içerir:** `30`

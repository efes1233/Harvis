# cevir_zaman_s_hafta

zaman: saniye ↔ hafta çevirir

- **Anahtar sözcükler:** `saniye`, `hafta`, `çevir`
- **Örnek girdi:** `10 saniye kaç hafta çevir`
- **Beklenen çıktı içerir:** `0.00001653439`

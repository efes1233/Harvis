# cevir_basinc_bar_mmhg

basinc: bar ↔ mmHg çevirir

- **Anahtar sözcükler:** `bar`, `mmhg`, `cıva`, `çevir`
- **Örnek girdi:** `10 bar kaç mmhg çevir`
- **Beklenen çıktı içerir:** `7500.616`

# cevir_zaman_dk_saat

zaman: dakika ↔ saat çevirir

- **Anahtar sözcükler:** `dakika`, `dk`, `saat`, `çevir`
- **Örnek girdi:** `10 dakika kaç saat çevir`
- **Beklenen çıktı içerir:** `0.1666667`

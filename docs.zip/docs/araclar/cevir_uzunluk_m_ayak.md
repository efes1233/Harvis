# cevir_uzunluk_m_ayak

uzunluk: metre ↔ ayak çevirir

- **Anahtar sözcükler:** `metre`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 metre kaç ayak çevir`
- **Beklenen çıktı içerir:** `32.8084`

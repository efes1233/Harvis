# base64_coz

Base64 metni çözer

- **Anahtar sözcükler:** `base64 çöz`, `base64 decode`
- **Örnek girdi:** `base64 çöz bWVyaGFiYQ==`
- **Beklenen çıktı içerir:** `merhaba`

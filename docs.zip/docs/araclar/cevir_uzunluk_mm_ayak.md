# cevir_uzunluk_mm_ayak

uzunluk: milimetre ↔ ayak çevirir

- **Anahtar sözcükler:** `milimetre`, `mm`, `ayak`, `feet`, `ft`, `çevir`
- **Örnek girdi:** `10 milimetre kaç ayak çevir`
- **Beklenen çıktı içerir:** `0.0328084`

# cevir_veri_b_gb

veri: bayt ↔ gigabayt çevirir

- **Anahtar sözcükler:** `bayt`, `byte`, `gigabayt`, `gb`, `çevir`
- **Örnek girdi:** `10 bayt kaç gigabayt çevir`
- **Beklenen çıktı içerir:** `9.313226e-9`

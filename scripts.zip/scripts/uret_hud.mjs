import { writeFileSync, mkdirSync } from "node:fs";
mkdirSync("web/src/hud", { recursive: true });
const S = {
  Gauge: [["CpuGauge","CPU","%","#00e5ff"],["GpuGauge","GPU","%","#4cc9f0"],["RamGauge","RAM","%","#7df9ff"],["DiskGauge","DİSK","%","#80ffdb"],["AgGauge","AĞ","%","#00b4d8"],["IsiGauge","ISI","°","#ffd166"],["PilGauge","PİL","%","#06d6a0"],["SinyalGauge","SİNYAL","%","#48cae4"],["GucGauge","GÜÇ","%","#ff9f1c"],["BasincGauge","BASINÇ","%","#90e0ef"]],
  Radar: [["YakinRadar","YAKIN"],["UzakRadar","UZAK"],["HavaRadar","HAVA"],["UyduRadar","UYDU"],["SonarRadar","SONAR"],["GokRadar","GÖK"],["TrafikRadar","TRAFİK"],["TehditRadar","TEHDİT"],["DronRadar","DRON"],["DenizRadar","DENİZ"]],
  Spektrum: [["SesSpektrum","SES"],["MikrofonSpektrum","MİKROFON"],["TitresimSpektrum","TİTREŞİM"],["KozmikSpektrum","KOZMİK"],["RadyoSpektrum","RADYO"],["SismikSpektrum","SİSMİK"],["KalpSpektrum","KALP"],["MotorSpektrum","MOTOR"],["FrekansSpektrum","FREKANS"],["DalgaSpektrum","DALGA"]],
  Cizgi: [["EnerjiCizgi","ENERJİ"],["GecikmeCizgi","GECİKME"],["HizCizgi","HIZ"],["IrtifaCizgi","İRTİFA"],["NemCizgi","NEM"],["VoltajCizgi","VOLTAJ"],["AkimCizgi","AKIM"],["YukCizgi","YÜK"],["PaketCizgi","PAKET"],["OksijenCizgi","OKSİJEN"]],
  Altigen: [["KalkanAltigen","KALKAN"],["ZirhAltigen","ZIRH"],["HucreAltigen","HÜCRE"],["AgAltigen","AĞ"],["ModulAltigen","MODÜL"],["CekirdekAltigen","ÇEKİRDEK"],["YamaAltigen","YAMA"],["SensorAltigen","SENSÖR"],["BolgeAltigen","BÖLGE"],["MatrisAltigen","MATRİS"]],
  Halka: [["ReaktorHalka","REAKTÖR"],["DonuHalka","DÖNÜ"],["KilitHalka","KİLİT"],["HedefHalka","HEDEF"],["YorungeHalka","YÖRÜNGE"],["OdakHalka","ODAK"],["CemberHalka","ÇEMBER"],["ArcHalka","ARC"],["AlanHalka","ALAN"],["OrbitHalka","ORBİT"]],
};
const adlar = []; let seed = 7;
for (const [tur, liste] of Object.entries(S)) for (const l of liste) {
  const [ad, etiket, birim, renk] = l; seed += 13;
  const props = tur === "Gauge" ? `etiket=${JSON.stringify(etiket)} birim=${JSON.stringify(birim)} deger={p.deger ?? ${30 + (seed % 60)}} renk={p.renk ?? ${JSON.stringify(renk)}}` : `etiket=${JSON.stringify(etiket)} seed={${seed}} renk={p.renk}`;
  writeFileSync(`web/src/hud/${ad}.tsx`, `import React from "react";\nimport { ${tur}, type Ortak } from "./_sablon.tsx";\n\nexport const ETIKET = ${JSON.stringify(etiket)};\nexport default function ${ad}(p: Ortak) {\n  return <${tur} ${props} />;\n}\n`);
  adlar.push(ad);
}
writeFileSync("web/src/hud/index.ts", `// Otomatik üretildi: scripts/uret_hud.mjs\n${adlar.map((a) => `import ${a} from "./${a}.tsx";`).join("\n")}\nexport const TUM_WIDGETLAR = { ${adlar.join(", ")} } as const;\nexport type WidgetAdi = keyof typeof TUM_WIDGETLAR;\n`);
console.log("widget:", adlar.length);

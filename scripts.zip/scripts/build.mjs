// Web arayüzünü derler: web/src/main.tsx -> web/dist/app.js + app.css
import { mkdirSync, copyFileSync } from "node:fs";
import { execSync } from "node:child_process";
import { createRequire } from "node:module";

const aday = [process.env.ESBUILD_PATH, "esbuild", "/opt/npm-tools/node_modules/esbuild"].filter(Boolean);
let esbuild; for (const a of aday) { try { esbuild = createRequire(import.meta.url)(a); break; } catch { /* sıradaki */ } }
if (!esbuild) { console.error("esbuild bulunamadı. `npm i` çalıştırın."); process.exit(1); }
let global = ""; try { global = execSync("npm root -g", { encoding: "utf-8" }).trim(); } catch { /* yok */ }

mkdirSync("web/dist", { recursive: true });
await esbuild.build({
  entryPoints: { app: "web/src/main.tsx" }, outdir: "web/dist", bundle: true, format: "esm", target: "es2022", minify: true, sourcemap: false,
  jsx: "automatic", nodePaths: [global, process.env.NODE_PATH].filter(Boolean), define: { "process.env.NODE_ENV": '"production"' }, logLevel: "info", loader: { ".css": "css" },
});
copyFileSync("web/index.html", "web/dist/index.html");
console.log("Derleme tamam: web/dist");

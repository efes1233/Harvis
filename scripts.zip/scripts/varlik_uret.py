import numpy as np, json, wave, struct, math, random
from PIL import Image
rng = np.random.default_rng(1138)

# ---- Dünya dokusu: fraktal gürültüyle kıta/okyanus, 4096x2048 ----
W,H = 4096,2048
def fbm(w,h,octaves=7):
    out = np.zeros((h,w),dtype=np.float32); amp=1.0; tot=0
    for o in range(octaves):
        gw,gh = 4*2**o, 2*2**o
        g = rng.random((gh+1,gw+1)).astype(np.float32)
        im = Image.fromarray((g*255).astype(np.uint8)).resize((w,h),Image.BICUBIC)
        out += amp*np.asarray(im,dtype=np.float32)/255.0; tot+=amp; amp*=0.5
    return out/tot
n = fbm(W,H)
lat = np.linspace(90,-90,H)[:,None]
n = (n-n.min())/(n.max()-n.min())
kara = n > 0.52
img = np.zeros((H,W,3),dtype=np.float32)
derin = np.clip((0.52-n)/0.25,0,1)[...,None]
ok = np.array([8,40,90])*(1-derin)+np.array([2,12,40])*derin
yuk = np.clip((n-0.52)/0.3,0,1)[...,None]
kr = np.array([20,110,60])*(1-yuk)+np.array([150,130,90])*yuk
img = np.where(kara[...,None],kr,ok)
kutup = (np.abs(lat)>72)|((np.abs(lat)>62)&(n>0.62))
img = np.where(kutup[...,None]&np.ones((1,W,1),bool),np.array([235,242,250]),img)
img += rng.normal(0,6,img.shape)
Image.fromarray(np.clip(img,0,255).astype(np.uint8)).save("assets/textures/dunya_4k.png",optimize=False,compress_level=1)

# Gece ışıkları dokusu (kara üzerinde parlak noktalar) 4096x2048
gece = np.zeros((H,W,3),dtype=np.uint8)
pts = np.argwhere(kara & (rng.random((H,W))>0.9985))
for y,x in pts:
    gece[max(0,y-1):y+2,max(0,x-1):x+2]=[255,200,110]
gece = np.clip(gece.astype(np.int16)+rng.integers(0,12,(H,W,1)),0,255).astype(np.uint8)
Image.fromarray(gece).save("assets/textures/dunya_gece_4k.png",compress_level=1)

# Bulut dokusu 2048x1024
c = fbm(2048,1024,6); c = np.clip((c-0.5)*4,0,1)
bulut = np.dstack([np.full_like(c,255),np.full_like(c,255),np.full_like(c,255),c*255]).astype(np.uint8)
Image.fromarray(bulut,"RGBA").save("assets/textures/bulutlar_2k.png",compress_level=1)

# ---- Ses efektleri (gerçek sentez) 44.1kHz 16-bit ----
SR=44100
def yaz(ad,x):
    x = np.clip(x,-1,1); d=(x*32767).astype(np.int16)
    with wave.open(f"assets/sounds/{ad}.wav","wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())
def t(s): return np.linspace(0,s,int(SR*s),endpoint=False)
def zarf(x,a=0.01,r=0.2):
    n=len(x); e=np.ones(n); na=int(a*SR); nr=int(r*SR)
    e[:na]=np.linspace(0,1,na); e[-nr:]=np.linspace(1,0,nr); return x*e
tt=t(3.0)
baslangic = sum(0.18*np.sin(2*np.pi*f*tt*(1+0.1*tt)) for f in (110,220,330,440,660))
baslangic = zarf(baslangic*np.exp(-tt*0.4),0.3,1.0)+0.02*rng.normal(size=len(tt))*np.exp(-tt)
yaz("baslangic",baslangic)
tt=t(0.15); yaz("bip",zarf(0.5*np.sin(2*np.pi*1200*tt),0.005,0.05))
tt=t(0.6); yaz("uyanma",zarf(0.4*np.sin(2*np.pi*(500+900*tt/0.6)*tt),0.02,0.2))
tt=t(0.4); yaz("pinch",zarf(0.4*np.sin(2*np.pi*(900-300*tt)*tt),0.01,0.1))
tt=t(4.0); yaz("meteor_carpma",zarf(np.sin(2*np.pi*(60-10*tt)*tt)*np.exp(-tt*1.2)*0.8+rng.normal(size=len(tt))*np.exp(-tt*2.5)*0.5,0.005,0.5))
tt=t(8.0); yaz("hud_ambient",zarf(0.12*np.sin(2*np.pi*55*tt)+0.06*np.sin(2*np.pi*82.5*tt+np.sin(tt))+0.02*rng.normal(size=len(tt)),1.0,1.0))
tt=t(2.0); yaz("tarama",zarf(0.3*np.sin(2*np.pi*(300+2000*(tt/2))*tt),0.05,0.3))

# ---- Veri setleri ----
sehirler = [("İstanbul",41.01,28.98,15.5),("Ankara",39.93,32.86,5.7),("İzmir",38.42,27.14,4.4),("New York",40.71,-74.0,8.3),
("Londra",51.51,-0.13,9.0),("Paris",48.86,2.35,2.1),("Tokyo",35.68,139.69,37.4),("Pekin",39.9,116.4,21.5),("Delhi",28.61,77.21,32.9),
("Kahire",30.04,31.24,21.3),("Moskova",55.76,37.62,12.6),("São Paulo",-23.55,-46.63,22.4),("Sidney",-33.87,151.21,5.3),
("Los Angeles",34.05,-118.24,12.5),("Berlin",52.52,13.4,3.7),("Roma",41.9,12.5,4.3),("Madrid",40.42,-3.7,6.7),("Dubai",25.2,55.27,3.6),
("Singapur",1.35,103.82,5.9),("Seul",37.57,126.98,9.9),("Mexico City",19.43,-99.13,21.8),("Lagos",6.52,3.38,15.4),("Cape Town",-33.92,18.42,4.6),
("Buenos Aires",-34.6,-58.38,15.2),("Toronto",43.65,-79.38,6.3),("Bangkok",13.76,100.5,10.5),("Cakarta",-6.2,106.85,10.6),("Tahran",35.69,51.39,9.0),
("Riyad",24.71,46.68,7.7),("Nairobi",-1.29,36.82,4.7)]
json.dump([{"ad":a,"lat":b,"lon":c,"nufusMilyon":d} for a,b,c,d in sehirler],open("assets/data/sehirler.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
# Yıldız kataloğu: 60000 yıldız (ra, dec, parlaklık, renk sıcaklığı)
ys = [{"ra":round(float(rng.uniform(0,360)),4),"dec":round(float(math.degrees(math.asin(rng.uniform(-1,1)))),4),
       "mag":round(float(rng.gamma(2.2,1.6)),2),"k":int(rng.choice([3500,4500,5800,7500,10000,20000],p=[.3,.2,.2,.15,.1,.05]))} for _ in range(60000)]
json.dump(ys,open("assets/data/yildizlar.json","w"),separators=(",",":"))
print("ok")

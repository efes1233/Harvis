import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
mkdirSync("assets/senaryolar", { recursive: true }); mkdirSync("tests/senaryolar", { recursive: true });
const sehirler = JSON.parse(readFileSync("assets/data/sehirler.json", "utf-8"));
const slug = (s) => s.toLowerCase().replace(/ı/g,"i").replace(/ş/g,"s").replace(/ğ/g,"g").replace(/ü/g,"u").replace(/ö/g,"o").replace(/ç/g,"c").replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"");
let n = 0;
function yaz(id, ad, tur, lat, lon, parametreler, aciklama) {
  writeFileSync(`assets/senaryolar/${id}.json`, JSON.stringify({ id, ad, tur, lat, lon, parametreler, aciklama }, null, 1));
  writeFileSync(`tests/senaryolar/${id}.test.ts`, `import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { senaryoEtkisi, haversineKm } from "../../shared/fizik.ts";
const s = JSON.parse(readFileSync(new URL("../../assets/senaryolar/${id}.json", import.meta.url), "utf-8"));
assert.equal(s.id, "${id}");
assert.ok(s.lat >= -90 && s.lat <= 90 && s.lon >= -180 && s.lon <= 180, "koordinat aralığı");
const e = senaryoEtkisi(s.tur, s.parametreler);
assert.ok(Number.isFinite(e.enerjiJoule) && e.enerjiJoule > 0, "enerji pozitif olmalı");
assert.ok(Number.isFinite(e.etkiYaricapKm) && e.etkiYaricapKm > 0, "yarıçap pozitif olmalı");
assert.ok(e.satirlar.length >= 2, "özet satırları");
assert.ok(haversineKm(s.lat, s.lon, s.lat, s.lon) === 0);
console.log("ok ${id}");
`);
  n++;
}
const boyutlar = [["kucuk", 50, "Chelyabinsk sınıfı küçük cisim"], ["orta", 300, "Şehir ölçeğinde yıkım"], ["buyuk", 1000, "Bölgesel felaket"]];
for (const s of sehirler) for (const [ad, cap, ac] of boyutlar)
  yaz(`meteor_${slug(s.ad)}_${ad}`, `Meteor çarpması – ${s.ad} (${cap} m)`, "meteor", s.lat, s.lon, { cap, hiz: 20, aci: 45, yogunluk: 3000 }, `${ac}. Kaya cisim, 20 km/s, 45°.`);
sehirler.forEach((s, i) => yaz(`deprem_${slug(s.ad)}`, `Deprem – ${s.ad} (Mw ${(6.5 + (i % 8) * 0.3).toFixed(1)})`, "deprem", s.lat, s.lon, { mw: +(6.5 + (i % 8) * 0.3).toFixed(1) }, "Sığ odaklı levha içi deprem senaryosu."));
const volkanlar = [["Vezüv",40.82,14.43,5],["Etna",37.75,14.99,4],["Krakatau",-6.1,105.42,6],["Fuji",35.36,138.73,5],["Yellowstone",44.43,-110.67,8],["Erciyes",38.53,35.45,5],["Ağrı",39.7,44.3,4],["Pinatubo",15.13,120.35,6],["Tambora",-8.25,118.0,7],["St. Helens",46.2,-122.18,5]];
for (const [a, lat, lon, vei] of volkanlar) yaz(`volkan_${slug(a)}`, `Volkanik patlama – ${a} (VEI ${vei})`, "volkan", lat, lon, { vei }, "Plinian patlama senaryosu.");
const tsu = [["Japon Hendeği",38.3,142.4,8.9,6000,2500],["Sumatra Açıkları",3.3,95.9,9.1,4500,3000],["Şili Hendeği",-36.1,-72.9,8.8,5000,4000],["Doğu Akdeniz",34.5,26.0,7.9,3000,800],["Marmara Denizi",40.8,28.2,7.4,1000,150],["Alaska Körfezi",60.9,-147.3,8.5,4000,3500],["Kuzey Atlantik",36.0,-10.0,8.7,4000,2000],["Cascadia",45.0,-125.5,9.0,2500,1500],["Hint Okyanusu",-5.0,90.0,8.6,4500,3500],["Karayipler",19.0,-67.0,8.1,4000,1000]];
for (const [a, lat, lon, mw, derinlik, mesafe] of tsu) yaz(`tsunami_${slug(a)}`, `Tsunami – ${a} (Mw ${mw})`, "tsunami", lat, lon, { mw, derinlik, mesafe }, "Deniz tabanı kırılması kaynaklı tsunami.");
const gunes = [["C",3,"Hafif C sınıfı"],["M",3,"Orta M sınıfı"],["M",8,"Güçlü M sınıfı"],["X",5,"X sınıfı"],["X",28,"Carrington benzeri aşırı fırtına"]];
gunes.forEach(([c, sayi, ac], i) => yaz(`gunes_patlamasi_${i + 1}`, `Güneş patlaması – ${c}${sayi}`, "gunes", 0, 0, { sinif: c === "X" ? 4 : c === "M" ? 3 : 2, sayi }, ac));
console.log("senaryo:", n);

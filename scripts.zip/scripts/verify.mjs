// Tüm projeyi doğrular: her .ts modülü yüklenir, her .json çözülür, tüm testler çalışır.
import { readdirSync, statSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";

const topla = (d, ext) => readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? (f === "node_modules" ? [] : topla(p, ext)) : ext.some((e) => p.endsWith(e)) ? [p] : []; });
let hata = 0;
const rapor = (ad, ok, ek = "") => { console.log(`${ok ? "✔" : "✘"} ${ad} ${ek}`); if (!ok) hata++; };

// 1) Sunucu/paylaşılan TS modülleri yüklenebilir mi
const mods = [...topla("server/src", [".ts"]), ...topla("shared", [".ts"]), ...topla("web/src/hands", [".ts"]), ...topla("web/src/evren", [".ts"]).filter((f) => !f.endsWith("ciz.ts"))];
let yuklenen = 0;
for (const m of mods) { try { await import(pathToFileURL(join(process.cwd(), m)).href); yuklenen++; } catch (e) { rapor("modül " + m, false, e.message); } }
rapor("TS modülleri yüklendi", yuklenen === mods.length, `${yuklenen}/${mods.length}`);

// 2) JSON dosyaları
const jsons = topla(".", [".json"]); let jok = 0;
for (const j of jsons) { try { JSON.parse(readFileSync(j, "utf-8")); jok++; } catch (e) { rapor("json " + j, false, e.message); } }
rapor("JSON dosyaları geçerli", jok === jsons.length, `${jok}/${jsons.length}`);

// 3) Testler
for (const k of ["tests/araclar", "tests/senaryolar", "tests/server"]) {
  const r = spawnSync(process.execPath, ["scripts/test_calistir.mjs", k], { encoding: "utf-8" });
  rapor(k, r.status === 0, r.stdout.trim().split("\n")[0]);
  if (r.status) console.log(r.stdout);
}
for (const t of ["tests/web/gestures.test.ts", "tests/web/motor.test.ts", "tests/web/efektler.test.ts", "tests/assets/varliklar.test.ts"]) {
  const r = spawnSync(process.execPath, ["--experimental-strip-types", "--no-warnings", t], { encoding: "utf-8" });
  rapor(t, r.status === 0, r.stderr.split("\n").slice(0, 4).join(" "));
}
const h = spawnSync(process.execPath, ["tests/web/hud.test.mjs"], { encoding: "utf-8", env: { ...process.env } });
rapor("tests/web/hud.test.mjs (60 widget render)", h.status === 0, h.status ? "esbuild+react gerekli: npm i" : "");
console.log(hata ? `\n${hata} doğrulama BAŞARISIZ` : "\nTÜM DOĞRULAMALAR GEÇTİ");
process.exit(hata ? 1 : 0);

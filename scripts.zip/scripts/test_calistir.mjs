// Verilen klasördeki tüm *.test.ts dosyalarını ayrı süreçte çalıştırır.
import { readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
const kok = process.argv[2] ?? "tests";
function topla(d) { return readdirSync(d).flatMap((f) => { const p = join(d, f); return statSync(p).isDirectory() ? topla(p) : p.endsWith(".test.ts") ? [p] : []; }); }
const dosyalar = topla(kok).sort(); let gecen = 0; const hatalar = [];
for (const f of dosyalar) {
  const r = spawnSync(process.execPath, ["--experimental-strip-types", "--no-warnings", f], { encoding: "utf-8" });
  if (r.status === 0) gecen++; else hatalar.push(f + "\n" + (r.stderr || r.stdout).split("\n").slice(0, 6).join("\n"));
}
console.log(`${gecen}/${dosyalar.length} test geçti`);
if (hatalar.length) { console.log(hatalar.slice(0, 15).join("\n---\n")); process.exit(1); }

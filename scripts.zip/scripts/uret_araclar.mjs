import { writeFileSync, mkdirSync } from "node:fs";
const D = "server/src/araclar", T = "tests/araclar", DOC = "docs/araclar";
for (const d of [D, T, DOC]) mkdirSync(d, { recursive: true });
const tum = [];

function yaz(ad, aciklama, anahtarlar, govde, girdi, beklenen, ekImport = "") {
  const kod = `import type { Arac } from "../../../shared/types.ts";
import { sayilar, fmt, hesapla, tokenler } from "./_yardimci.ts";
${ekImport}
void [sayilar, fmt, hesapla, tokenler];
const arac: Arac = {
  ad: ${JSON.stringify(ad)},
  aciklama: ${JSON.stringify(aciklama)},
  anahtarlar: ${JSON.stringify(anahtarlar)},
  calistir: (girdi) => {
${govde}
  },
  ornek: { girdi: ${JSON.stringify(girdi)}, beklenen: ${JSON.stringify(beklenen)} },
};
export default arac;
`;
  writeFileSync(`${D}/${ad}.ts`, kod);
  writeFileSync(`${T}/${ad}.test.ts`, `import assert from "node:assert/strict";
import arac from "../../server/src/araclar/${ad}.ts";
const r = await arac.calistir(arac.ornek.girdi, {});
assert.equal(r.ok, true, "ok olmalı: " + r.metin);
assert.ok(r.metin.includes(arac.ornek.beklenen), \`beklenen "\${arac.ornek.beklenen}" sonuçta yok: \${r.metin}\`);
console.log("ok ${ad}");
`);
  writeFileSync(`${DOC}/${ad}.md`, `# ${ad}\n\n${aciklama}\n\n- **Anahtar sözcükler:** ${anahtarlar.map((k) => "\`" + k + "\`").join(", ")}\n- **Örnek girdi:** \`${girdi}\`\n- **Beklenen çıktı içerir:** \`${beklenen}\`\n`);
  tum.push(ad);
}

// ---------- Elle tanımlı araçlar ----------
const el = [
 ["hesap_makinesi","Aritmetik ifadeleri hesaplar (+ - * / ^ % parantez, 'artı', 'çarpı' vb.)",["hesapla","kaç eder","artı","çarpı","bölü","eksi"],
  `    const r = hesapla(girdi.replace(/hesapla|kaç eder|=/gi, ""));\n    return { ok: true, metin: "Sonuç " + fmt(r), veri: r };`,"hesapla 12 çarpı (3 artı 4)","84"],
 ["saat","Şu anki saati söyler",["saat kaç","saati söyle","saat"],
  `    const d = new Date();\n    return { ok: true, metin: "Saat " + d.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) };`,"saat kaç","Saat "],
 ["tarih","Bugünün tarihini söyler",["tarih","bugün ne","günlerden ne","bugün günlerden"],
  `    const d = new Date();\n    return { ok: true, metin: "Bugün " + d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) };`,"bugün günlerden ne","Bugün "],
 ["uuid_uret","Rastgele UUID v4 üretir",["uuid","benzersiz kimlik"],
  `    return { ok: true, metin: "UUID: " + crypto.randomUUID() };`,"uuid üret","UUID: "],
 ["base64_kodla","Metni Base64'e kodlar",["base64 kodla","base64'e çevir","base64 encode"],
  `    const m = girdi.replace(/base64[^\\s]*\\s*(kodla|encode|çevir)?/gi, "").trim();\n    return { ok: true, metin: "Base64: " + Buffer.from(m, "utf-8").toString("base64") };`,"base64 kodla merhaba","bWVyaGFiYQ=="],
 ["base64_coz","Base64 metni çözer",["base64 çöz","base64 decode"],
  `    const m = girdi.replace(/base64\\s*(çöz|decode)/gi, "").trim();\n    return { ok: true, metin: "Metin: " + Buffer.from(m, "base64").toString("utf-8") };`,"base64 çöz bWVyaGFiYQ==","merhaba"],
 ["sha256","Metnin SHA-256 özetini hesaplar",["sha256","özet hesapla","hash"],
  `    const m = girdi.replace(/sha256|hash|özet hesapla/gi, "").trim();\n    return { ok: true, metin: "SHA-256: " + createHash("sha256").update(m).digest("hex") };`,"sha256 abc","ba7816bf8f01cfea414140de5dae2223","import { createHash } from \"node:crypto\";"],
 ["sifre_uret","Güçlü rastgele parola üretir",["şifre üret","parola üret","şifre oluştur"],
  `    const n = Math.min(64, Math.max(8, sayilar(girdi)[0] ?? 16));\n    const cs = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*";\n    const b = randomBytes(n); let s = "";\n    for (let i = 0; i < n; i++) s += cs[b[i] % cs.length];\n    return { ok: true, metin: "Parola: " + s, veri: s };`,"16 karakterli şifre üret","Parola: ","import { randomBytes } from \"node:crypto\";"],
 ["zar_at","Zar atar (varsayılan 6 yüzlü)",["zar at","zar"],
  `    const y = Math.max(2, sayilar(girdi)[0] ?? 6);\n    return { ok: true, metin: "Zar: " + (1 + randomInt(y)) };`,"zar at","Zar: ","import { randomInt } from \"node:crypto\";"],
 ["yazi_tura","Yazı tura atar",["yazı tura","yazi tura","para at"],
  `    return { ok: true, metin: randomInt(2) ? "Yazı" : "Tura" };`,"yazı tura at","","import { randomInt } from \"node:crypto\";"],
 ["rastgele_sayi","Aralıkta rastgele sayı seçer",["rastgele sayı","rastgele say"],
  `    const [a = 1, b = 100] = sayilar(girdi); const lo = Math.min(a, b), hi = Math.max(a, b);\n    return { ok: true, metin: "Sayı: " + (lo + randomInt(hi - lo + 1)) };`,"1 ile 10 arası rastgele sayı","Sayı: ","import { randomInt } from \"node:crypto\";"],
 ["kelime_say","Metindeki kelime sayısını verir",["kelime say","kaç kelime"],
  `    const m = girdi.replace(/kelime say|kaç kelime/gi, "").trim();\n    return { ok: true, metin: "Kelime sayısı: " + (m ? m.split(/\\s+/).length : 0) };`,"kelime say bir iki üç dört","Kelime sayısı: 4"],
 ["ters_cevir","Metni tersine çevirir",["ters çevir","tersini yaz"],
  `    const m = girdi.replace(/ters çevir|tersini yaz/gi, "").trim();\n    return { ok: true, metin: [...m].reverse().join("") };`,"ters çevir abc","cba"],
 ["buyuk_harf","Metni büyük harfe çevirir (Türkçe uyumlu)",["büyük harf","büyük yaz"],
  `    const m = girdi.replace(/büyük harf(e)?( çevir)?|büyük yaz/gi, "").trim();\n    return { ok: true, metin: m.toLocaleUpperCase("tr-TR") };`,"büyük harf çevir istanbul","İSTANBUL"],
 ["kucuk_harf","Metni küçük harfe çevirir (Türkçe uyumlu)",["küçük harf","küçük yaz"],
  `    const m = girdi.replace(/küçük harf(e)?( çevir)?|küçük yaz/gi, "").trim();\n    return { ok: true, metin: m.toLocaleLowerCase("tr-TR") };`,"küçük harf çevir ISPARTA","ısparta"],
 ["palindrom","Metnin palindrom olup olmadığını söyler",["palindrom"],
  `    const m = girdi.replace(/palindrom( mu)?/gi, "").toLocaleLowerCase("tr-TR").replace(/[^\\p{L}\\p{N}]/gu, "");\n    return { ok: true, metin: m === [...m].reverse().join("") ? "Evet, palindrom." : "Hayır, palindrom değil." };`,"palindrom mu kayak","Evet"],
 ["asal_mi","Sayının asal olup olmadığını söyler",["asal mı","asal mi","asal"],
  `    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 2) return { ok: true, metin: n + " asal değildir." };\n    for (let i = 2; i * i <= n; i++) if (n % i === 0) return { ok: true, metin: n + " asal değildir; " + i + " ile bölünür." };\n    return { ok: true, metin: n + " asaldır." };`,"97 asal mı","asaldır"],
 ["faktoriyel","Faktöriyel hesaplar (BigInt)",["faktöriyel","faktoriyel"],
  `    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0 || n > 500) return { ok: false, metin: "0-500 arası tam sayı verin." };\n    let r = 1n; for (let i = 2n; i <= BigInt(n); i++) r *= i;\n    return { ok: true, metin: n + "! = " + r };`,"10 faktöriyel","3628800"],
 ["fibonacci","N. Fibonacci sayısını verir",["fibonacci"],
  `    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0 || n > 1000) return { ok: false, metin: "0-1000 arası tam sayı verin." };\n    let a = 0n, b = 1n; for (let i = 0; i < n; i++) [a, b] = [b, a + b];\n    return { ok: true, metin: "F(" + n + ") = " + a };`,"fibonacci 20","6765"],
 ["ebob_ekok","İki sayının EBOB ve EKOK değerini verir",["ebob","ekok"],
  `    const [a, b] = sayilar(girdi); if (!a || !b) return { ok: false, metin: "İki sayı verin." };\n    const g = (x: number, y: number): number => (y ? g(y, x % y) : x); const e = g(Math.abs(a), Math.abs(b));\n    return { ok: true, metin: "EBOB " + e + ", EKOK " + Math.abs(a * b) / e };`,"12 ve 18 ebob ekok","EBOB 6, EKOK 36"],
 ["yuzde","Yüzde hesaplar: 'A sayısının yüzde B'si'",["yüzde","yuzde"],
  `    const [a, b] = sayilar(girdi); if (a === undefined || b === undefined) return { ok: false, metin: "İki sayı verin." };\n    return { ok: true, metin: fmt(a) + " sayısının %" + fmt(b) + "'si " + fmt((a * b) / 100) };`,"200 sayısının yüzde 15 i","30"],
 ["vki","Beden kitle indeksi (boy cm, kilo kg)",["vki","beden kitle","bmi"],
  `    const [b, k] = sayilar(girdi); if (!b || !k) return { ok: false, metin: "Boy (cm) ve kilo (kg) verin." };\n    const v = k / (b / 100) ** 2; const d = v < 18.5 ? "zayıf" : v < 25 ? "normal" : v < 30 ? "fazla kilolu" : "obez";\n    return { ok: true, metin: "VKİ " + v.toFixed(1) + " (" + d + ")" };`,"vki boy 180 kilo 81","VKİ 25.0"],
 ["bilesik_faiz","Bileşik faiz: anapara, yıllık %, yıl",["bileşik faiz","bilesik faiz"],
  `    const [p, r, y] = sayilar(girdi); if (!p || r === undefined || !y) return { ok: false, metin: "Anapara, oran ve yıl verin." };\n    return { ok: true, metin: "Gelecek değer " + (p * (1 + r / 100) ** y).toFixed(2) };`,"bileşik faiz 1000 10 2","1210.00"],
 ["kdv","KDV hesaplar (varsayılan %20)",["kdv"],
  `    const [t, o = 20] = sayilar(girdi); if (t === undefined) return { ok: false, metin: "Tutar verin." };\n    return { ok: true, metin: "KDV " + (t * o / 100).toFixed(2) + ", toplam " + (t * (1 + o / 100)).toFixed(2) };`,"kdv 100 20","KDV 20.00, toplam 120.00"],
 ["gun_farki","İki tarih (GG.AA.YYYY) arasındaki gün sayısı",["gün farkı","kaç gün var","gun farki"],
  `    const t = girdi.match(/(\\d{1,2})[./](\\d{1,2})[./](\\d{4})/g); if (!t || t.length < 2) return { ok: false, metin: "İki tarih verin (GG.AA.YYYY)." };\n    const p = (s: string) => { const [g, a, y] = s.split(/[./]/).map(Number); return Date.UTC(y, a - 1, g); };\n    return { ok: true, metin: Math.round(Math.abs(p(t[1]) - p(t[0])) / 864e5) + " gün" };`,"gün farkı 01.01.2024 ile 01.03.2024","60 gün"],
 ["gun_adi","Tarihin haftanın hangi günü olduğunu söyler",["hangi gün","gün adı"],
  `    const t = girdi.match(/(\\d{1,2})[./](\\d{1,2})[./](\\d{4})/); if (!t) return { ok: false, metin: "Tarih verin (GG.AA.YYYY)." };\n    const d = new Date(Date.UTC(+t[3], +t[2] - 1, +t[1]));\n    return { ok: true, metin: d.toLocaleDateString("tr-TR", { weekday: "long", timeZone: "UTC" }) };`,"hangi gün 29.10.2023","Pazar"],
 ["romen_rakami","Sayıyı Roma rakamına çevirir",["roma rakamı","romen rakamı","romen"],
  `    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 1 || n > 3999) return { ok: false, metin: "1-3999 arası sayı verin." };\n    const t: [number, string][] = [[1000,"M"],[900,"CM"],[500,"D"],[400,"CD"],[100,"C"],[90,"XC"],[50,"L"],[40,"XL"],[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];\n    let k = n, s = ""; for (const [v, r] of t) while (k >= v) { s += r; k -= v; }\n    return { ok: true, metin: n + " = " + s };`,"1994 roma rakamı","MCMXCIV"],
 ["ikilik_taban","Sayıyı ikilik ve onaltılık tabana çevirir",["ikilik","binary","onaltılık","hex"],
  `    const n = sayilar(girdi)[0]; if (!Number.isInteger(n) || n < 0) return { ok: false, metin: "Pozitif tam sayı verin." };\n    return { ok: true, metin: n + " = 0b" + n.toString(2) + " = 0x" + n.toString(16).toUpperCase() };`,"255 binary hex","0b11111111 = 0xFF"],
 ["mors","Metni Mors koduna çevirir",["mors"],
  `    const M: Record<string, string> = { a:".-",b:"-...",c:"-.-.",d:"-..",e:".",f:"..-.",g:"--.",h:"....",i:"..",j:".---",k:"-.-",l:".-..",m:"--",n:"-.",o:"---",p:".--.",q:"--.-",r:".-.",s:"...",t:"-",u:"..-",v:"...-",w:".--",x:"-..-",y:"-.--",z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----." };\n    const m = girdi.replace(/mors( koduna)?( çevir)?/gi, "").toLowerCase().replace(/ı/g,"i").replace(/ş/g,"s").replace(/ç/g,"c").replace(/ğ/g,"g").replace(/ö/g,"o").replace(/ü/g,"u");\n    return { ok: true, metin: [...m].map((c) => (c === " " ? "/" : M[c] ?? "")).filter(Boolean).join(" ") };`,"mors sos","... --- ..."],
 ["carpim_tablosu","Bir sayının çarpım tablosunu verir",["çarpım tablosu","carpim tablosu"],
  `    const n = sayilar(girdi)[0]; if (n === undefined) return { ok: false, metin: "Sayı verin." };\n    return { ok: true, metin: Array.from({ length: 10 }, (_, i) => n + "x" + (i + 1) + "=" + fmt(n * (i + 1))).join(", ") };`,"7 çarpım tablosu","7x10=70"],
 ["ortalama","Sayıların ortalamasını verir",["ortalama"],
  `    const s = sayilar(girdi); if (!s.length) return { ok: false, metin: "Sayı verin." };\n    return { ok: true, metin: "Ortalama " + fmt(s.reduce((a, b) => a + b, 0) / s.length) };`,"ortalama 4 8 15 16 23 42","18"],
 ["karekok","Karekök hesaplar",["karekök","karekok"],
  `    const n = sayilar(girdi)[0]; if (n === undefined || n < 0) return { ok: false, metin: "Negatif olmayan sayı verin." };\n    return { ok: true, metin: "√" + fmt(n) + " = " + fmt(Math.sqrt(n)) };`,"144 karekök","12"],
];
for (const e of el) yaz(...e);

// ---------- Birim çeviriciler ----------
const KAT = {
 uzunluk: { m: ["metre", ["metre"], 1], mm: ["milimetre", ["milimetre", "mm"], 0.001], cm: ["santimetre", ["santimetre", "cm"], 0.01], km: ["kilometre", ["kilometre", "km"], 1000], mil: ["mil", ["mil", "mile"], 1609.344], yarda: ["yarda", ["yarda", "yard"], 0.9144], ayak: ["ayak", ["ayak", "feet", "ft"], 0.3048], inc: ["inç", ["inç", "inch", "inc"], 0.0254], denizmili: ["deniz mili", ["deniz mili"], 1852] },
 kutle: { kg: ["kilogram", ["kilogram", "kilo", "kg"], 1], g: ["gram", ["gram"], 0.001], mg: ["miligram", ["miligram", "mg"], 1e-6], ton: ["ton", ["ton"], 1000], libre: ["libre", ["libre", "pound", "lb"], 0.45359237], ons: ["ons", ["ons", "ounce", "oz"], 0.028349523125] },
 hacim: { l: ["litre", ["litre"], 1], ml: ["mililitre", ["mililitre", "ml"], 0.001], m3: ["metreküp", ["metreküp", "m3"], 1000], galon: ["galon", ["galon", "gallon"], 3.785411784], pint: ["pint", ["pint"], 0.473176473], bardak: ["su bardağı", ["bardak"], 0.25] },
 alan: { m2: ["metrekare", ["metrekare", "m2"], 1], km2: ["kilometrekare", ["kilometrekare", "km2"], 1e6], hektar: ["hektar", ["hektar"], 1e4], donum: ["dönüm", ["dönüm"], 1000], akre: ["akre", ["akre", "acre"], 4046.8564224], ft2: ["fitkare", ["fitkare", "ft2"], 0.09290304] },
 hiz: { ms: ["m/s", ["m/s", "metre/saniye"], 1], kmh: ["km/s", ["km/s", "km/h", "kilometre/saat"], 1 / 3.6], mph: ["mil/saat", ["mph", "mil/saat"], 0.44704], knot: ["knot", ["knot", "düğüm"], 1852 / 3600], mach: ["mach", ["mach"], 343] },
 enerji: { j: ["joule", ["joule", "jul"], 1], kj: ["kilojoule", ["kilojoule", "kj"], 1000], kal: ["kalori", ["kalori"], 4.184], kcal: ["kilokalori", ["kilokalori", "kcal"], 4184], kwh: ["kilovatsaat", ["kilovatsaat", "kwh"], 3.6e6], btu: ["BTU", ["btu"], 1055.05585262], mt: ["megaton TNT", ["megaton"], 4.184e15] },
 basinc: { pa: ["pascal", ["pascal", "pa"], 1], kpa: ["kilopascal", ["kilopascal", "kpa"], 1000], bar: ["bar", ["bar"], 1e5], atm: ["atmosfer", ["atmosfer", "atm"], 101325], psi: ["psi", ["psi"], 6894.757293168], mmhg: ["mmHg", ["mmhg", "cıva"], 133.322387415] },
 veri: { b: ["bayt", ["bayt", "byte"], 1], kb: ["kilobayt", ["kilobayt", "kb"], 1024], mb: ["megabayt", ["megabayt", "mb"], 1024 ** 2], gb: ["gigabayt", ["gigabayt", "gb"], 1024 ** 3], tb: ["terabayt", ["terabayt", "tb"], 1024 ** 4], bit: ["bit", ["bit"], 0.125] },
 zaman: { s: ["saniye", ["saniye"], 1], dk: ["dakika", ["dakika", "dk"], 60], saat: ["saat", ["saat"], 3600], gun: ["gün", ["gün"], 86400], hafta: ["hafta", ["hafta"], 604800], yil: ["yıl", ["yıl", "sene"], 31557600] },
 guc: { w: ["watt", ["watt", "vat"], 1], kw: ["kilowatt", ["kilowatt", "kw"], 1000], mw: ["megawatt", ["megawatt", "mw"], 1e6], hp: ["beygir gücü", ["beygir", "hp"], 735.49875], btuh: ["BTU/saat", ["btu/saat"], 0.29307107] },
 aci: { derece: ["derece", ["derece"], 1], radyan: ["radyan", ["radyan"], 180 / Math.PI], grad: ["grad", ["grad"], 0.9] },
};
const ascii = (s) => s.toLowerCase().replace(/ı/g,"i").replace(/ş/g,"s").replace(/ğ/g,"g").replace(/ü/g,"u").replace(/ö/g,"o").replace(/ç/g,"c").replace(/[^a-z0-9]/g,"");
for (const [kat, birimler] of Object.entries(KAT)) {
  const ks = Object.keys(birimler);
  for (let i = 0; i < ks.length; i++) for (let j = i + 1; j < ks.length; j++) {
    const [ka, kb] = [ks[i], ks[j]]; const A = birimler[ka], B = birimler[kb];
    const ad = `cevir_${kat}_${ka}_${kb}`;
    const body = `    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((a) => t === a || (a.length >= 4 && t.startsWith(a)))); return k < 0 ? 1e9 : k; };
    const ters = idx(${JSON.stringify(B[1])}) < idx(${JSON.stringify(A[1])});
    const fa = ${A[2]}, fb = ${B[2]};
    const [kaynak, hedef, f1, f2] = ters ? [${JSON.stringify(B[0])}, ${JSON.stringify(A[0])}, fb, fa] : [${JSON.stringify(A[0])}, ${JSON.stringify(B[0])}, fa, fb];
    const sonuc = (n * f1) / f2;
    return { ok: true, metin: fmt(n) + " " + kaynak + " = " + fmt(sonuc) + " " + hedef, veri: sonuc };`;
    const kelimeler = [...A[1], ...B[1], "çevir"];
    const f = (x) => (Number.isInteger(x) && Math.abs(x) < 1e15 ? String(x) : String(Number(x.toPrecision(7))));
    const bek = f((10 * A[2]) / B[2]);
    yaz(ad, `${kat}: ${A[0]} ↔ ${B[0]} çevirir`, kelimeler, body, `10 ${A[1][0]} kaç ${B[1][0]} çevir`, bek);
  }
}
// Sıcaklık (afin dönüşümler)
const SIC = [["c","f","Santigrat","Fahrenhayt",["santigrat","celsius","derece"],["fahrenhayt","fahrenheit"],"n * 9 / 5 + 32","(n - 32) * 5 / 9",100,"212"],
             ["c","k","Santigrat","Kelvin",["santigrat","celsius","derece"],["kelvin"],"n + 273.15","n - 273.15",0,"273.15"],
             ["f","k","Fahrenhayt","Kelvin",["fahrenhayt","fahrenheit"],["kelvin"],"(n - 32) * 5 / 9 + 273.15","(n - 273.15) * 9 / 5 + 32",32,"273.15"]];
for (const [a,b,an,bn,aw,bw,ab,ba,ornek,bek] of SIC) {
  const body = `    const n = sayilar(girdi)[0];
    if (n === undefined) return { ok: false, metin: "Bir sayı verin." };
    const tok = tokenler(girdi);
    const idx = (adlar: string[]) => { const k = tok.findIndex((t) => adlar.some((x) => t.startsWith(x))); return k < 0 ? 1e9 : k; };
    const ters = idx(${JSON.stringify(bw)}) < idx(${JSON.stringify(aw)});
    const sonuc = ters ? ${ba} : ${ab};
    return { ok: true, metin: fmt(n) + " " + (ters ? ${JSON.stringify(bn)} : ${JSON.stringify(an)}) + " = " + fmt(Number(sonuc.toFixed(4))) + " " + (ters ? ${JSON.stringify(an)} : ${JSON.stringify(bn)}), veri: sonuc };`;
  yaz(`cevir_sicaklik_${a}_${b}`, `sıcaklık: ${an} ↔ ${bn} çevirir`, [...aw, ...bw, "çevir"], body, `${ornek} ${aw[0]} kaç ${bw[0]}`, bek);
}

// ---------- Kayıt dosyası ----------
const imp = tum.map((a, i) => `import a${i} from "./${a}.ts";`).join("\n");
writeFileSync(`${D}/_index.ts`, `// Otomatik üretildi: scripts/uret_araclar.mjs\nimport type { Arac } from "../../../shared/types.ts";\n${imp}\nexport const TUM_ARACLAR: Arac[] = [${tum.map((_, i) => "a" + i).join(", ")}];\n`);
console.log("araç sayısı:", tum.length);
